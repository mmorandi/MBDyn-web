E = 210.e+9;
NU = 0.3;
G = E/(2*(1 + NU));

A = .005*.005;
J = A^2/12;

L = 1.;
RHO_A = .1;

m1 = L/2*RHO_A;
k1 = m1*(pi/L*sqrt(E*A/RHO_A))^2;

m2 = L/2*RHO_A;
k2 = m2*((pi/L)^2*sqrt(E*J/RHO_A))^2;

m3 = L/2*RHO_A;
k3 = m3*((2*pi/L)^2*sqrt(E*J/RHO_A))^2;

m = diag([m1 m2 m3]);
k = diag([k1 k2 k3]);

