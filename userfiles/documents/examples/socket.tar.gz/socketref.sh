#!/bin/sh

# Set to your build path
BLDPATH=/home/masarati/Lavoro/mbdyn/mbdyn-devel
PATH="$BLDPATH/mbdyn:$BLDPATH/utils:$PATH"

echo -n "*** Starting MBDyn... "
mbdyn -f socketref -o output > output.txt 2>&1 &
PID=$!
echo "PID=$PID; sleeping 2 seconds..."
sleep 2

echo "*** Starting test..."
test_strext_socket \
	-c 3 \
	-r \
	-f 0.,0.,1.,0.,0.,0. \
	-N 1 \
	-p 0.,0.,1.,0.,0.,0. \
	-R mat \
	-s 0 \
	-x \
	-H local:///tmp/mbdyn.sock

wait $PID
echo "*** Done"


