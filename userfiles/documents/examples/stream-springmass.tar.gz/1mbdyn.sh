#!/bin/sh

echo "starting body"
nohup mbdyn -o 1b body > 1b.txt 2>&1 &
PIDS=$!

echo -n "waiting for body to start... "
sleep 1
echo "done"

echo "starting spring"
python spring.py

echo -n "waiting for body to complete... "
wait $PIDS
echo "done"

echo "when done: rm 1b.* *.echo"

