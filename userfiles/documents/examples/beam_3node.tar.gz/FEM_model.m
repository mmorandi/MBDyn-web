#######################################################################################
##   DEMO 6
#######################################################################################
##
## Viertelkreistr�ger nach Dubel C24 33b
##
#######################################################################################

       
  clear all;
  close all;
  format short g;
  source('multibody.m');
  source('wire_mesh2.m');

  E = 210000e6;
  G = 81500e6;
  roh = 7850;
  d = 12e-3;
  R = 5000e-3;
  Phi = pi/2;

  Iy = d^4 * pi / 64;
  A = d^2 * pi / 4;

  F1 = 1e-3;

  p1 = [0;-F1;0;0;0;0];

  number_of_nodes = 100;
  number_of_eigenmodes = 10;

  Phi_i = Phi * ( number_of_nodes-1:-1:0 ) / ( number_of_nodes - 1 );
  s1_nodes = R * [ -cos(Phi_i); sin(Phi_i); zeros(1,number_of_nodes) ];

  locked = { "s1:end.x","s1:end.y","s1:end.z","s1:end.Phix","s1:end.Phiy","s1:end.Phiz" };

  sys = system_wire_mesh2(s1_nodes,d,0,E,G,roh,"s1");

  locked = name_to_dof_index(sys.bodies,locked);

  s1_idx = name_to_body_index(sys.bodies,{"s1:1"});

  S = system_stiffness_matrix(sys);

 M = system_mass_matrix(sys);

  Tp_s1 = system_load_transformation_matrix_body(sys,s1_idx);

  N = length(S);

  p = Tp_s1.' * p1;

  [M,free] = remove_dof(M,locked);
  [S,free] = remove_dof(S,locked);
  [p,free] = remove_dof(p,locked);

  u = S \ p;

  u = add_dof(u,free,N);

  u_ = F1 * R^3 / ( 2 * E * Iy ) * ( sin(Phi_i) - Phi_i .* cos(Phi_i) );
  w_ = F1 * R^3 / ( 2 * E * Iy ) * Phi_i .* sin(Phi_i);

  ux_a = u_ .* sin(Phi_i) + w_ .* cos(Phi_i);
  uy_a = u_ .* cos(Phi_i) - w_ .* sin(Phi_i);

  u_a = zeros(N,1);

  u_a([1:6:end]) = ux_a;
  u_a([2:6:end]) = uy_a;

  err = ((u./u_a)(sort([1:6:end-6,2:6:end-6]))-1)*100;

 [U,lambda,f] = undamped_eigenmode(M,S,:,number_of_eigenmodes);
 U = add_dof(U,free,N);
 
 for i=1:columns(U)
    U(:,i) /= max(abs(U([1:6:end,2:6:end,3:6:end],i)));
 endfor

  fflush(stdout);

  scale = 1;
  limits = plot_system(sys,:,[1,0,0],[0,0,1],N<100,N<100,[-0.01,0.01,-0.01,0.01,-0.01,0.01],0.01,1e3);
  limits = plot_system(sys,u*scale,[1,0.5,0],[0,0.5,1],false,false,limits,0.01,1e3);
  limits = plot_system(sys,u_a*scale,[1,0.7,0],[0,0.7,1],false,false,limits,0.01,1e3);
  title(sprintf("Viertelkreistr�ger Dubel C24 33b: Fehler x=%g%% Fehler y=%g%%",err(1),err(2)));
  xlabel("x [mm]");
  ylabel("y [mm]");
  zlabel("z [mm]");
  view(0,90);
  grid("on");
  box("off");       
  drawnow();  
  for i=1:columns(U)
      figure();
      hold on;
      limits = plot_system(sys,:,[1,0,0],[0,0,1],N<100,N<100,[-0.01,0.01,-0.01,0.01,-0.01,0.01],0.01,1e3);
      limits = plot_system(sys,U(:,i)*scale,[1,0.5,0],[0,0.5,1],false,false,limits,0.01,1e3);
      title(sprintf("Eigenform %d %gHz",i,f(i)));
      xlabel("x [mm]");
      ylabel("y [mm]");
      zlabel("z [mm]");
      view(0,90);
      grid("on");
      box("off");       
      drawnow(); 
 endfor