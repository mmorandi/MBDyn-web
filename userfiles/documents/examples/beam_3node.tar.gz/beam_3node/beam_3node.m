# This model demonstrates the use of three node beam elements for curved beam structures
#
# The model consists of one curved beam with an arc with radius R and angle Phi as centerline
# One end of the curved beam is clamped and the other end is loaded by the force -F1 in z direction

# This example is taken from Dubbel Taschenbuch f�r Maschinenbau page C24 33b

# This model is intended to compute eighter the static equilibrium point and compare it by the analytical solution,
# or to compute the eigenvalues and eigenvectors.

# Run beam_3node.m to generate the mesh and run MBDyn


close all;
clear all;

#####################################
# BEGIN: INPUT SECTION
#####################################

R = 5;                          # radius of the centerline of the beam [m]
d = 0.012;                      # diameter of the cross circular section [m]
E = 210000e6;           # elastic modulus [N/m^2]
G = 81500e6;            # shear modulus [N/m^2]
roh = 7850;             # density of the beam [kg/m^3]

# geometrical momentum of inertia of the circular cross section
Iy = d^4 * pi / 64.;    
Iz = Iy;
Ip = Iy + Iz;

# cross sectional area
A = d^2 * pi / 4;

# effective shear cross sectional area for circular cross sections
As = 9./10. * A;

# force at the end of the beam
F1 = 1e-3;

# end angle of the circular arc
Phi = pi / 2;

# damping ratio (proportional viscoelastic damping)
damping_ratio = 0;

# time const (F1 is applied by an exponential function)
tau = 1;

# number of 3 node beam elements
number_of_elements = 50;

# number of eigenmodes to display
number_of_eigenmodes = 15;

######################################
# END: INPUT SECTION
######################################

number_of_nodes = number_of_elements * 2 + 1;

number_of_points = number_of_nodes;

Phi_i = Phi * ( 0:number_of_points-1 ) / ( number_of_points - 1 );

# analytical solution of the static problem according to Dubbel  C24 33b

u = F1 * R^3 / ( 2 * E * Iy ) * ( sin(Phi_i) - Phi_i .* cos(Phi_i) );
w = F1 * R^3 / ( 2 * E * Iy ) * Phi_i .* sin(Phi_i);

Rx_a = -R * cos(Phi_i);
Ry_a = R * sin(Phi_i);
Rz_a = zeros(1,length(Phi_i));

ux_a = u .* sin(Phi_i) + w .* cos(Phi_i);
uy_a = u .* cos(Phi_i) - w .* sin(Phi_i);
uz_a = zeros(1,length(ux_a));

rx_a = Rx_a + ux_a;
ry_a = Ry_a + uy_a;
rz_a = Rz_a + uz_a;

param_file = "beam_param.set";
frame_file = "beam_frames.ref";
frame_gauss_file = "beam_frames_gauss.ref";
nodes_file = "beam_nodes.nod";
elements_file  = "beam_elements.elm";

#############################################
# PARAMETER FILE
#############################################

[fout,errmsg] = fopen(param_file,"wt");

if ( -1 == fout )
	error("could not open file \"%s\": %s",param_file,errmsg);
endif

unwind_protect

fprintf(fout,"\
set: real R = %g;\n\
set: real d = %g;\n\
set: real E = %g;\n\
set: real G = %g;\n\
set: real roh = %g;\n\
set: real Iy = %g;\n\
set: real Iz = %g;\n\
set: real Ip = %g;\n\
set: real A = %g;\n\
set: real As = %g;\n\
set: real F1 = %g;\n\
set: integer number_of_elements = %d;\n\
set: integer number_of_nodes = %d;\n\
set: real Phi_max = %g;\n\
set: real damping_ratio = %g;\n\
", R, d, E, G, roh, Iy, Iz, Ip, A, As, F1, number_of_elements,number_of_nodes, Phi,damping_ratio);

fprintf(fout,"set: real tau=%g;\n",tau);

unwind_protect_cleanup
	fclose(fout);
end_unwind_protect

###############################################
# FRAME FILE
###############################################

[fout,errmsg] = fopen(frame_file,"wt");

if ( -1 == fout )
  error("could not open file \"%s\":%s",frame_file,errmsg);
endif

unwind_protect
      for i=1:number_of_nodes
          fprintf(fout,"\
set: i = %d;\n\
include: \"beam_frame_i.ref\";\n\n",i);
      endfor
unwind_protect_cleanup
      fclose(fout);
end_unwind_protect

###############################################
# FRAME GAUSS FILE
###############################################

[fout,errmsg] = fopen(frame_gauss_file,"wt");

if ( -1 == fout )
  error("could not open file \"%s\":%s",frame_gauss_file,errmsg);
endif

unwind_protect
      for i=1:number_of_elements
          fprintf(fout,"\
set: i = %d;\n\
include: \"beam_frame_gauss_i.ref\";\n\n",i);
      endfor
unwind_protect_cleanup
      fclose(fout);
end_unwind_protect

###############################################
# NODES FILE
###############################################

[fout,errmsg] = fopen(nodes_file,"wt");

if ( -1 == fout )
  error("could not open file \"%s\":%s",nodes_file,errmsg);
endif

unwind_protect
      for i=1:number_of_nodes
          fprintf(fout,"\
set: i = %d;\n\
include: \"beam_node_i.nod\";\n\n",i);
      endfor
unwind_protect_cleanup
      fclose(fout);
end_unwind_protect

###############################################
# ELEMENTS FILE
###############################################

[fout,errmsg] = fopen(elements_file,"wt");

if ( -1 == fout )
  error("could not open file \"%s\":%s",elements_file,errmsg);
endif

unwind_protect
      for i=1:number_of_elements
          fprintf(fout,"\
set: i = %d;\n\
include: \"beam_i.elm\";\n\n",i);
      endfor
      for i=1:number_of_nodes
          fprintf(fout,"\
set: i = %d;\n\
include: \"body_i.elm\";\n\n",i);
      endfor
unwind_protect_cleanup
      fclose(fout);
end_unwind_protect

###############################################
# COMMAND EXECUTION
###############################################

command = "mbdyn -f beam_3node.mbdyn";

if ( 0 != system(command) )
	error("command \"%s\" failed!",command);
endif

command = "mbdyn2easyanim.sh -v showAll=1 -v every=10 beam_3node";

if ( 0 != system(command) )
	error("command \"%s\" failed!",command);
endif

###############################################
# DATA IMPORT
###############################################

tic();

# read the trajectory
data = load("beam_3node.mov");

number_of_nodes = 0;

node1 = data(1,1);

for i=2:rows(data)
	if ( data(i,1) == node1 )
		number_of_nodes = i - 1;
		break;
	endif
endfor

nodes = data(1:number_of_nodes,1);

for i=1:number_of_nodes
	trajectory{i} = data(i:number_of_nodes:end,2:end);
	deformation{i} = trajectory{i} - repmat(trajectory{i}(1,:),rows(trajectory{i}),1);
endfor

# read the time axis
out_file = "beam_3node.out";

[fid,errmsg] = fopen(out_file,"rt");

if ( fid == -1 )
	error("could not open file \"%s\": %s",out_file,errmsg);
endif

t = zeros(rows(trajectory{1}),1);

unwind_protect
	do
		line = fgets(fid);
	until ( strncmp("Step",line,length("Step")) && !feof(fid) )
	
	for i=1:rows(t)
		[Step, Time, TStep, NIter, ResErr, SolErr, SolConv,Count] = sscanf(line,"Step %d %g %g %d %g %g %g\n","C");
		
		if ( Count != 7 )
			error("could not read file \"%s\"!",out_file);
		endif
		
		t(i) = Time;
		
		if ( feof(fid) )
			break;
		endif
		
		line = fgets(fid);
	endfor
unwind_protect_cleanup
	fclose(fid);
end_unwind_protect

undeformed = zeros(number_of_nodes,3);
deformed = zeros(number_of_nodes,3);

for i=1:number_of_nodes
	undeformed(i,:) = trajectory{i}(1,1:3).';
	deformed(i,:) = trajectory{i}(end,1:3).';
endfor

###############################################
# POST PROCESSING
###############################################

toc();

figure();
hold on;
set(plot3(undeformed(:,1),undeformed(:,2),undeformed(:,3),'-'),'color',[1,0,0]);
set(plot3(undeformed(:,1),undeformed(:,2),undeformed(:,3),'x'),'color',[1,0,0]);
set(plot3(deformed(:,1),deformed(:,2),deformed(:,3),'-'),'color',[0,0,1]);
set(plot3(deformed(:,1),deformed(:,2),deformed(:,3),'x'),'color',[0,0,1]);
set(plot3(Rx_a,Ry_a,Rz_a,'-o'),'color',[1,1,0]);
set(plot3(rx_a,ry_a,rz_a,'-o'),'color',[0,1,1]);

def = deformed - undeformed;
def_a = [ ux_a.', uy_a.', uz_a.' ];

err = 1 - def ./ def_a;

disp("deformation (static equilibrium point):");
disp(def);

disp("analytic deformation (static equilibrium point):");
disp(def_a);

disp("error [%]:");
disp(err*100);

for i=1:number_of_nodes
	set(text(undeformed(i,1),undeformed(i,2),undeformed(i,3),sprintf("%d",nodes(i))),'color',[1,0,0]);
	set(text(deformed(i,1),deformed(i,2),deformed(i,3),sprintf("%d",nodes(i))),'color',[0,0,1]);
endfor

for i=1:number_of_nodes
	set(plot3(trajectory{i}(:,1),trajectory{i}(:,2),trajectory{i}(:,3),'--'),'color',[0,1,0]);
endfor

xlabel('x [m]');
ylabel('y [m]');
zlabel('z [m]');
title('deformed and undeformed geometry (static equilibrium point)');
grid on;
grid minor;
view(0,90);

for i=number_of_nodes
	figure();
	plot(t,deformation{i}(:,1:3));
	title(sprintf("node %d",nodes(i)));
	legend({"x","y","z"});
	xlabel('t [s]');
	ylabel('u [m]');
	grid on;
	grid minor;
endfor
      
source("beam_3node.mbdyn.m");      

LAMBDA = ( alpha(:,1) + 1j * alpha(:,2)  ) ./ alpha(:,3); 
lambda = 1/dCoef * (LAMBDA - 1)./(LAMBDA + 1);
f = imag(lambda) / ( 2 * pi );
phase = 0;

printf("Eigenvalues f [Hz]:\n");
f

for i=1:min(columns(VR),number_of_eigenmodes)
  figure();
  hold on;
  set(plot3(X0(1:6:end),X0(2:6:end),X0(3:6:end),'-;X0;1'),'linewidth',3);
  set(plot3(X0(1:6:end)+real(VR(idx+1,i)*exp(1j*phase)),X0(2:6:end)+real(VR(idx+2,i)*exp(1j*phase)),X0(3:6:end)+real(VR(idx+3,i)*exp(1j*phase)),sprintf('-;mode %d %gHz;3',i,f(i))),'linewidth',2);
  xlabel('x [m]');
  ylabel('y [m]');
  zlabel('z [m]');
  title(sprintf('eigenmode %d %gHz',i,f(i)));
  grid on;
  grid minor;
endfor