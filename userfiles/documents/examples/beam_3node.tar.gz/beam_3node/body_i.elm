	body: body_id_1 + i - 1, node_id_1 +  i - 1,
		roh*A*R*delta_Phi,
		null,
		diag, roh*Ip*R*delta_Phi, roh*Iy*R*delta_Phi, roh*Iz*R*delta_Phi,
                inertial,reference,ref_node_1 + i - 1,eye;