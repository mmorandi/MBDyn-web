% MBDyn (C) is a multibody analysis code. 
% http://www.mbdyn.org
% 
% Copyright (C) 1996-2006
% 
% Pierangelo Masarati	<masarati@aero.polimi.it>
% Paolo Mantegazza	<mantegazza@aero.polimi.it>
% 
% Dipartimento di Ingegneria Aerospaziale - Politecnico di Milano
% via La Masa, 34 - 20156 Milano, Italy
% http://www.aero.polimi.it
% 
% Changing this copyright notice is forbidden.
% 
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation (version 2 of the License).
% 
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

% This is part of the MBDyn model of the AS330 Puma described in
%
% William G. Bousman, Colin Young, Francois Toulmay, Neil E. Gilbert,
% Roger C. Strawn, Judith V. Miller, Thomas H. Maier, Michel Costes,
% Philippe Beaumier: "A Comparison of Lifting-Line and CFD Methods
% with Flight Test Data from a Research Puma Helicopter",
% NASA TM 110421, October 1996

% edit data at will

blade = 'u';
% blade = 's';
% number of three-node beams
nbeams = 0;
%%%nbeams = 5;
blade_damp = 1.e-4;
% do_plots = 'y';
do_plots = 'n';

%%% THERE SHOULD BE NO NEED TO EDIT BELOW THIS LINE

global l_blade_radius blade_data BLADE_STATION BLADE_TWIST BLADE_MASS BLADE_CG BLADE_EA BLADE_EJF BLADE_EJC BLADE_GJ BLADE_J 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Unmodified
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

l_blade_radius_u = 7.490;	% m

blade_twist_u = [
% Radial location	Twist
% r			Theta_u(nmodified)
% m			deg
0.280			 0.000
0.760			 0.000
0.760			 0.000
1.757			 0.000
1.757			 0.000
2.007			-0.100
2.007			-0.100
2.257			-0.300
2.257			-0.300
2.507			-0.617
2.507			-0.617
2.757			-0.983
2.757			-0.983
3.007			-1.283
3.007			-1.283
3.257			-1.600
3.257			-1.600
3.507			-1.867
3.507			-1.867
6.257			-4.800
6.257			-4.800
7.490			-6.117
];

blade_mass_u = [
% Radial location	Running mass
% r			m_u(nmodified)
% m			kg/m
0.280			58.400
0.610			58.400
0.610			50.000
0.730			50.000
0.730			16.175
0.754			16.175
0.754			53.333
0.760			53.333
0.760			24.949
0.800			24.949
0.800			33.100
0.840			33.100
0.840			22.400
1.040			22.400
1.040			17.110
1.110			17.110
1.110			11.225
1.260			11.225
1.260			 7.150
1.770			 7.150
1.770			 7.150
1.887			 8.929
1.887			 8.929
7.070			 8.929
7.070			12.754
7.390			12.754
7.390			34.600
7.402			34.600
7.402			 6.930
7.490			 6.930
];

blade_cg_offset_u = [
% Radial location	C.G. offset (wrt. quarter chord, positive forward)
% r			(x/c)_u(nmodified)
% m			adim.
0.280			 0.000
1.887			 0.000
1.887			-0.010
7.070			-0.010
7.070			 0.030
7.390			 0.030
7.390			 0.147
7.402			 0.147
7.402			 0.000
7.490			 0.000
];

blade_extensional_stiffness_u = [
% Radial location	Extensional stiffness
% r			(EA)_u(nmodified)
% m			N
0.280			5.69e8
0.760			5.69e8
0.760			5.63e8
0.820			5.63e8
0.820			3.77e8
0.873			3.77e8
0.873			5.69e8
0.965			5.69e8
0.965			5.50e8
1.040			5.50e8
1.040			4.74e8
1.111			4.74e8
1.111			3.74e8
1.260			3.74e8
1.260			1.70e8
1.697			1.69e8
1.697			1.69e8
1.757			1.65e8
1.757			1.65e8
1.880			1.71e8
1.880			1.71e8
2.128			1.70e8
2.128			1.70e8
2.278			1.51e8
2.278			1.51e8
5.250			1.45e8
5.250			1.45e8
5.800			1.44e8
5.800			1.44e8
6.110			1.43e8
6.110			1.43e8
7.350			1.43e8
7.350			1.61e8
7.382			1.61e8
7.382			1.16e8
7.490			1.16e8
];

blade_flap_chord_stiffness_u = [
% Radial location	Flap stiffness		Chord stiffness
% r			(EI_f)_u(nmodified)	(EI_c)_u(nmodified)
% m			Nm^2			Nm^2
0.280			178.00e4		178.00e4
0.600			178.00e4		178.00e4
0.600			178.00e4		178.00e4
0.610			137.00e4		137.00e4
0.610			137.00e4		137.00e4
0.800			137.00e4		137.00e4
0.800			137.00e4		137.00e4
0.810			 41.20e4		178.00e4
0.810			 41.20e4		178.00e4
1.240			 41.00e4		178.00e4
1.240			 41.00e4		178.00e4
1.250			  8.10e4		153.00e4
1.250			  8.10e4		153.00e4
7.300			  8.10e4		144.00e4
7.300			  8.10e4		144.00e4
7.310			  8.20e4		 71.50e4
7.310			  8.20e4		 71.50e4
7.490			  8.20e4		 71.50e4
];

blade_torsional_stiffness_u = [
% Radial location	Torsional stiffness
% r			(GJ)_u(nmodified)
% m			Nm^2
0.280			 84.00e4
0.725			 84.00e4
0.725			226.00e4
0.828			226.00e4
0.828			 50.50e4
1.017			 50.50e4
1.017			  8.50e4
7.241			  8.50e4
7.241			  8.70e4
7.490			  8.70e4
];

blade_torsional_inertia_u = [
% Radial location	Torsional inertia
% r			(I_Theta)_u(nmodified)
% m			kg m
0.280			0.000
0.604			0.000
0.604			0.192
0.610			0.192
0.610			0.164
0.730			0.178
0.730			0.116
0.754			0.130
0.754			0.427
0.760			0.438
0.760			0.205
0.800			0.240
0.800			0.318
0.836			0.359
0.836			0.359
0.837			0.120
0.837			0.120
0.840			0.121
0.840			0.082
1.017			0.121
1.017			0.121
1.040			0.098
1.040			0.075
1.085			0.040
1.085			0.040
1.110			0.040
1.110			0.026
1.260			0.026
1.260			0.017
1.770			0.037
1.770			0.087
1.887			0.109
1.887			0.109
7.070			0.109
7.070			0.156
7.390			0.156
7.390			0.337
7.402			0.067
7.402			0.067
7.434			0.067
7.434			0.118
7.490			0.118
];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Swept-tip
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

l_blade_radius_s = 7.536;	% m

blade_twist_s = [
% Radial location	Twist
% r			Theta_s(wept-tip)
% m			deg
0.280			 0.000
0.760			 0.000
0.760			 0.000
1.757			 0.000
1.757			 0.000
2.007			-0.100
2.007			-0.100
2.257			-0.300
2.257			-0.300
2.507			-0.617
2.507			-0.617
2.757			-0.983
2.757			-0.983
3.007			-1.283
3.007			-1.283
3.257			-1.600
3.257			-1.600
3.507			-1.867
3.507			-1.867
6.257			-4.800
6.257			-4.800
6.296			-4.838
6.296			-4.838
6.360			-4.906
6.360			-4.906
6.467			-5.021
6.467			-5.021
6.531			-5.089
6.531			-5.089
6.574			-5.137
6.574			-5.137
6.629			-5.191
6.629			-5.191
6.682			-5.252
6.682			-5.252
6.736			-5.307
6.736			-5.307
6.779			-5.354
6.779			-5.354
6.843			-5.422
6.843			-5.422
6.897			-5.476
6.897			-5.476
6.950			-5.537
6.950			-5.537
7.005			-5.592
7.005			-5.592
7.058			-5.653
7.058			-5.653
7.112			-5.707
7.112			-5.707
7.165			-5.768
7.165			-5.768
7.182			-5.776
7.182			-5.776
7.219			-5.823
7.219			-5.823
7.273			-5.884
7.273			-5.884
7.326			-5.938
7.326			-5.938
7.380			-5.998
7.380			-5.998
7.434			-6.053
7.434			-6.053
7.488			-6.108
7.488			-6.108
7.514			-6.138
7.514			-6.138
7.536			-6.159
];

blade_mass_s = [
% Radial location	Running mass
% r			m_s(wept-tip)
% m			kg/m
0.280			58.400
0.610			58.400
0.610			50.000
0.730			50.000
0.730			16.175
0.754			16.175
0.754			53.333
0.760			53.333
0.760			24.949
0.800			24.949
0.800			33.100
0.840			33.100
0.840			22.400
1.040			22.400
1.040			17.110
1.110			17.110
1.110			11.225
1.260			11.225
1.260			 7.150
1.770			 7.150
1.770			 7.150
1.887			 8.929
1.887			 8.929
6.707			 8.929
6.707			13.429
6.758			13.429
6.758			23.429
7.000			23.429
7.000			46.079
7.020			46.079
7.020			13.429
7.070			13.429
7.070			19.253
7.196			19.253
7.196			38.429
7.216			38.429
7.216			13.429
7.402			13.429
7.402			11.430
7.499			11.430
7.499			 4.500
7.536			 4.500
];

blade_cg_offset_s = [
% Radial location	C.G. offset (wrt. quarter chord, positive forward)
% r			(x/c)_s(wept-tip)
% m			adim.
0.280			 0.000
1.887			 0.000
1.887			-0.010
6.707			-0.010
6.707			-0.010
6.758			-0.022
6.758			 0.135
7.000			 0.100
7.000			 0.194
7.020			 0.194
7.020			-0.084
7.070			-0.105
7.070			 0.029
7.196			 0.013
7.196			-0.167
7.216			-0.167
7.216			-0.136
7.402			-0.182
7.402			-0.211
7.499			-0.247
7.499			-0.615
7.536			-0.646
];

blade_extensional_stiffness_s = [
% Radial location	Extensional stiffness
% r			(EA)_s(wept-tip)
% m			N
0.280			5.69e8
0.760			5.69e8
0.760			5.63e8
0.820			5.63e8
0.820			3.77e8
0.873			3.77e8
0.873			5.69e8
0.965			5.69e8
0.965			5.50e8
1.040			5.50e8
1.040			4.74e8
1.111			4.74e8
1.111			3.74e8
1.260			3.74e8
1.260			1.70e8
1.697			1.69e8
1.697			1.69e8
1.757			1.65e8
1.757			1.65e8
1.880			1.71e8
1.880			1.71e8
2.128			1.70e8
2.128			1.70e8
2.278			1.51e8
2.278			1.51e8
5.250			1.45e8
5.250			1.45e8
5.800			1.44e8
5.800			1.44e8
6.110			1.43e8
6.110			1.43e8
7.350			1.43e8
7.350			1.61e8
7.382			1.61e8
7.382			1.16e8
7.536			1.16e8
];

blade_flap_chord_stiffness_s = [
% Radial location	Flap stiffness		Chord stiffness
% r			(EI_f)_s(wept-tip)	(EI_c)_s(wept-tip)
% m			Nm^2			Nm^2
0.280			178.00e4		178.00e4
0.600			178.00e4		178.00e4
0.600			178.00e4		178.00e4
0.610			137.00e4		137.00e4
0.610			137.00e4		137.00e4
0.800			137.00e4		137.00e4
0.800			137.00e4		137.00e4
0.810			 41.20e4		178.00e4
0.810			 41.20e4		178.00e4
1.240			 41.00e4		178.00e4
1.240			 41.00e4		178.00e4
1.250			  8.10e4		153.00e4
1.250			  8.10e4		153.00e4
7.300			  8.10e4		144.00e4
7.300			  8.10e4		144.00e4
7.310			  8.20e4		 71.50e4
7.310			  8.20e4		 71.50e4
7.536			  8.20e4		 71.50e4
];

blade_torsional_stiffness_s = [
% Radial location	Torsional stiffness
% r			(GJ)_s(wept-tip)
% m			Nm^2
0.280			 84.00e4
0.725			 84.00e4
0.725			226.00e4
0.828			226.00e4
0.828			 50.50e4
1.017			 50.50e4
1.017			  8.50e4
6.330			  8.50e4
6.330			  8.50e4
6.858			 18.50e4
6.858			 18.50e4
7.196			 18.50e4
7.536			  5.00e4
];

blade_torsional_inertia_s = [
% Radial location	Torsional inertia
% r			(I_Theta)_s(wept-tip)
% m			kg m
0.280			0.000
0.604			0.000
0.604			0.192
0.610			0.192
0.610			0.164
0.730			0.178
0.730			0.116
0.754			0.130
0.754			0.427
0.760			0.438
0.760			0.205
0.800			0.240
0.800			0.318
0.836			0.359
0.836			0.359
0.837			0.120
0.837			0.120
0.840			0.121
0.840			0.082
1.017			0.121
1.017			0.121
1.040			0.098
1.040			0.075
1.085			0.040
1.085			0.040
1.110			0.040
1.110			0.026
1.260			0.026
1.260			0.017
1.770			0.037
1.770			0.087
1.887			0.109
1.887			0.109
5.546			0.109
5.546			0.109
6.302			0.109
6.302			0.109
6.707			0.063
6.707			0.094
6.758			0.085
6.758			0.309
7.000			0.437
7.000			0.444
7.020			0.444
7.020			0.130
7.070			0.159
7.070			0.222
7.196			0.288
7.196			0.022
7.216			0.022
7.216			0.230
7.402			0.336
7.402			0.292
7.499			0.364
7.499			0.492
7.536			0.542
];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Plots
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if do_plots == 'y',
	gset term post eps color 'Times-Roman' 22
	gset grid
	gset xlabel 'RADIUS, m'

	gset ylabel 'TWIST, degrees'
	gset key right top Left reverse
	gset output 'blade_twist.eps'
	blade_twist_linear = [l_blade_radius_s*[0:.01:1]' 1.841-8.*[0:.01:1]'];
	gplot [0:8][-8:2] blade_twist_u u 1:2 title 'UNMODIFIED BLADE' w l, blade_twist_s u 1:2 title 'SWEPT-TIP BLADE' w l, blade_twist_linear u 1:2 title 'LINEAR TWIST' w d

	gset ylabel 'MASS, kg/m'
	gset key right top Left reverse
	gset output 'blade_mass.eps'
	gplot [0:8][0:60] blade_mass_u u 1:2 title 'UNMODIFIED BLADE' w l, blade_mass_s u 1:2 title 'SWEPT-TIP BLADE' w l

	gset ylabel 'C.G., % root chord'
	gset key left bottom Left reverse
	gset output 'blade_cg_offset.eps'
	gplot [0:8][-.8:.2] blade_cg_offset_u u 1:2 title 'UNMODIFIED BLADE' w l, blade_cg_offset_s u 1:2 title 'SWEPT-TIP BLADE' w l

	gset ylabel 'EA, Newtons'
	gset key right top Left reverse
	gset output 'blade_extensional_stiffness.eps'
	gplot [0:8][0:6e8] blade_extensional_stiffness_u u 1:2 title 'UNMODIFIED BLADE' w l, blade_extensional_stiffness_s u 1:2 title 'SWEPT-TIP BLADE' w l

	gset ylabel 'FLAP STIFFNESS, N-m^2'
	gset key right top Left reverse
	gset output 'blade_flap_stiffness.eps'
	gplot [0:8][0:2e6] blade_flap_chord_stiffness_u u 1:2 title 'UNMODIFIED BLADE' w l, blade_flap_chord_stiffness_s u 1:2 title 'SWEPT-TIP BLADE' w l

	gset ylabel 'CHORD STIFFNESS, N-m^2'
	gset key right top Left reverse
	gset output 'blade_chord_stiffness.eps'
	gplot [0:8][0:2e6] blade_flap_chord_stiffness_u u 1:3 title 'UNMODIFIED BLADE' w l, blade_flap_chord_stiffness_s u 1:3 title 'SWEPT-TIP BLADE' w l

	gset ylabel 'GJ, N-m^2'
	gset key right top Left reverse
	gset output 'blade_torsional_stiffness.eps'
	gplot [0:8][0:2.5e6] blade_torsional_stiffness_u u 1:2 title 'UNMODIFIED BLADE' w l, blade_torsional_stiffness_s u 1:2 title 'SWEPT-TIP BLADE' w l

	gset ylabel 'TORSIONAL INERTIA, kg-m'
	gset key right top Left reverse
	gset output 'blade_torsional_inertia.eps'
	gplot [0:8][0:.6] blade_torsional_inertia_u u 1:2 title 'UNMODIFIED BLADE' w l, blade_torsional_inertia_s u 1:2 title 'SWEPT-TIP BLADE' w l

	gset output '/dev/null'
	gset term x11
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


l_blade_root_cutout = 2.080;	% m
l_blade_chord = 0.537;		% m
l_lag_hinge_axis_x = 0.269;	% m
l_flap_hinge_axis_x = 0.289;	% m
l_pitch_link_x = 0.289;		% m
l_pitch_bearing_x = 0.432;	% m

if (blade == 'u'),	% unmodified
	l_blade_radius = l_blade_radius_u;
	blade_twist = blade_twist_u;
	blade_mass = blade_mass_u;
	blade_cg_offset = blade_cg_offset_u;
	blade_extensional_stiffness = blade_extensional_stiffness_u;
	blade_flap_chord_stiffness = blade_flap_chord_stiffness_u;
	blade_torsional_stiffness = blade_torsional_stiffness_u;
	blade_torsional_inertia = blade_torsional_inertia_u;

elseif (blade == 's'),	% swept-tip
	l_blade_radius = l_blade_radius_s;
	blade_twist = blade_twist_s;
	blade_mass = blade_mass_s;
	blade_cg_offset = blade_cg_offset_s;
	blade_extensional_stiffness = blade_extensional_stiffness_s;
	blade_flap_chord_stiffness = blade_flap_chord_stiffness_s;
	blade_torsional_stiffness = blade_torsional_stiffness_s;
	blade_torsional_inertia = blade_torsional_inertia_s;
end

% NOTE: change sign of blade_cg_offset because the rotor rotates
% opposite to western convention
blade_cg_offset(:, 2) = -blade_cg_offset_u(:, 2);

% make the tables even ...
[n_blade_twist, dmy] = size(blade_twist);
[n_blade_mass, dmy] = size(blade_mass);
[n_blade_cg_offset, dmy] = size(blade_cg_offset);
[n_blade_extensional_stiffness, dmy] = size(blade_extensional_stiffness);
[n_blade_flap_chord_stiffness, dmy] = size(blade_flap_chord_stiffness);
[n_blade_torsional_stiffness, dmy] = size(blade_torsional_stiffness);
[n_blade_torsional_inertia, dmy] = size(blade_torsional_inertia);


BLADE_STATION = 1;
BLADE_TWIST = 2;
BLADE_MASS = 3;
BLADE_CG = 4;
BLADE_EA = 5;
BLADE_EJF = 6;
BLADE_EJC = 7;
BLADE_GJ = 8;
BLADE_J = 9;

% first block
blade_data(1, :) = [
	blade_twist(1, 1), ...
	blade_twist(1, 2), ...
	blade_mass(1, 2), ...
	blade_cg_offset(1, 2), ...
	blade_extensional_stiffness(1, 2), ...
	blade_flap_chord_stiffness(1, 2:3), ...
	blade_torsional_stiffness(1, 2), ...
	blade_torsional_inertia(1, 2)];

i_blade = 2;
i_blade_twist = 2;
i_blade_mass = 2;
i_blade_cg_offset = 2;
i_blade_extensional_stiffness = 2;
i_blade_flap_chord_stiffness = 2;
i_blade_torsional_stiffness = 2;
i_blade_torsional_inertia = 2;

while (1),

	t = [
		blade_twist(i_blade_twist, 1), ...
		blade_mass(i_blade_mass, 1), ...
		blade_cg_offset(i_blade_cg_offset, 1), ...
		blade_extensional_stiffness(i_blade_extensional_stiffness, 1), ...
		blade_flap_chord_stiffness(i_blade_flap_chord_stiffness, 1), ...
		blade_torsional_stiffness(i_blade_torsional_stiffness, 1), ...
		blade_torsional_inertia(i_blade_torsional_inertia, 1)];
	jj = find(t == min(t));
	j = jj(1);
	new_x = t(j);
	blade_data(i_blade, BLADE_STATION) = new_x;

	% twist
	dx = blade_twist(i_blade_twist, 1) - blade_twist(i_blade_twist - 1, 1);
	d1 = blade_twist(i_blade_twist, 1) - new_x;
	d2 = new_x - blade_twist(i_blade_twist - 1, 1);
	blade_data(i_blade, BLADE_TWIST) = ([d1 d2]/dx)*blade_twist(i_blade_twist + [-1, 0], 2);
	
	% mass
	dx = blade_mass(i_blade_mass, 1) - blade_mass(i_blade_mass - 1, 1);
	d1 = blade_mass(i_blade_mass, 1) - new_x;
	d2 = new_x - blade_mass(i_blade_mass - 1, 1);
	blade_data(i_blade, BLADE_MASS) = ([d1 d2]/dx)*blade_mass(i_blade_mass + [-1, 0], 2);
	
	% cg_offset
	dx = blade_cg_offset(i_blade_cg_offset, 1) - blade_cg_offset(i_blade_cg_offset - 1, 1);
	d1 = blade_cg_offset(i_blade_cg_offset, 1) - new_x;
	d2 = new_x - blade_cg_offset(i_blade_cg_offset - 1, 1);
	blade_data(i_blade, BLADE_CG) = ([d1 d2]/dx)*blade_cg_offset(i_blade_cg_offset + [-1, 0], 2);
	
	% extensional_stiffness
	dx = blade_extensional_stiffness(i_blade_extensional_stiffness, 1) - blade_extensional_stiffness(i_blade_extensional_stiffness - 1, 1);
	d1 = blade_extensional_stiffness(i_blade_extensional_stiffness, 1) - new_x;
	d2 = new_x - blade_extensional_stiffness(i_blade_extensional_stiffness - 1, 1);
	blade_data(i_blade, BLADE_EA) = ([d1 d2]/dx)*blade_extensional_stiffness(i_blade_extensional_stiffness + [-1, 0], 2);
	
	% flap_chord_stiffness
	dx = blade_flap_chord_stiffness(i_blade_flap_chord_stiffness, 1) - blade_flap_chord_stiffness(i_blade_flap_chord_stiffness - 1, 1);
	d1 = blade_flap_chord_stiffness(i_blade_flap_chord_stiffness, 1) - new_x;
	d2 = new_x - blade_flap_chord_stiffness(i_blade_flap_chord_stiffness - 1, 1);
	blade_data(i_blade, BLADE_EJF:BLADE_EJC) = ([d1 d2]/dx)*blade_flap_chord_stiffness(i_blade_flap_chord_stiffness + [-1, 0], 2:3);
	
	% torsional_stiffness
	dx = blade_torsional_stiffness(i_blade_torsional_stiffness, 1) - blade_torsional_stiffness(i_blade_torsional_stiffness - 1, 1);
	d1 = blade_torsional_stiffness(i_blade_torsional_stiffness, 1) - new_x;
	d2 = new_x - blade_torsional_stiffness(i_blade_torsional_stiffness - 1, 1);
	blade_data(i_blade, BLADE_GJ) = ([d1 d2]/dx)*blade_torsional_stiffness(i_blade_torsional_stiffness + [-1, 0], 2);
	
	% torsional_inertia
	dx = blade_torsional_inertia(i_blade_torsional_inertia, 1) - blade_torsional_inertia(i_blade_torsional_inertia - 1, 1);
	d1 = blade_torsional_inertia(i_blade_torsional_inertia, 1) - new_x;
	d2 = new_x - blade_torsional_inertia(i_blade_torsional_inertia - 1, 1);
	blade_data(i_blade, BLADE_J) = ([d1 d2]/dx)*blade_torsional_inertia(i_blade_torsional_inertia + [-1, 0], 2);

	% end loop
	if (new_x == blade_twist(n_blade_twist, 1)),
		break;
	end
	
	% copy the previous line
	blade_data(i_blade + 1, :) = blade_data(i_blade, :);

	% change only the required values
	for k = 1:length(jj),
		if (jj(k) == 1),
			blade_data(i_blade + 1, BLADE_TWIST) = blade_twist(i_blade_twist + 1, 2);
			i_blade_twist = i_blade_twist + 2;

		elseif (jj(k) == 2),
			blade_data(i_blade + 1, BLADE_MASS) = blade_mass(i_blade_mass + 1, 2);
			i_blade_mass = i_blade_mass + 2;

		elseif (jj(k) == 3),
			blade_data(i_blade + 1, BLADE_CG) = blade_cg_offset(i_blade_cg_offset + 1, 2);
			i_blade_cg_offset = i_blade_cg_offset + 2;

		elseif (jj(k) == 4),
			blade_data(i_blade + 1, BLADE_EA) = blade_extensional_stiffness(i_blade_extensional_stiffness + 1, 2);
			i_blade_extensional_stiffness = i_blade_extensional_stiffness + 2;

		elseif (jj(k) == 5),
			blade_data(i_blade + 1, BLADE_EJF:BLADE_EJC) = blade_flap_chord_stiffness(i_blade_flap_chord_stiffness + 1, 2:3);
			i_blade_flap_chord_stiffness = i_blade_flap_chord_stiffness + 2;

		elseif (jj(k) == 6),
			blade_data(i_blade + 1, BLADE_GJ) = blade_torsional_stiffness(i_blade_torsional_stiffness + 1, 2);
			i_blade_torsional_stiffness = i_blade_torsional_stiffness + 2;

		elseif (jj(k) == 7),
			blade_data(i_blade + 1, BLADE_J) = blade_torsional_inertia(i_blade_torsional_inertia + 1, 2);
			i_blade_torsional_inertia = i_blade_torsional_inertia + 2;
		end
	end
	i_blade = i_blade + 2;
end

blade_data(:,[1,BLADE_MASS])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Multibody model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% The available data are:
%
% - twist
%
% - mass per unit length
% - cg offset
% - torsional inertia
%
% - axial stiffness
% - bending stiffness
% - torsional stiffness
%
% there is no mention of how structural, aerodynamic and geometrical data
% are placed on the blade; therefore:
%
% - the feathering axis is used as reference
% - the elastic axis is assumed to coincide with the feathering axis
% - the quarter chord is assumed to coincide with the feathering axis
% - the cg chordwise offset is taken with respect to the feathering axis,
%   after twist is applied
% - no cg flapwise offset is considered
% - the center of axial strain is assumed to coincide with the feathering axis
% - the flap and chord stiffness principal axes are assumed to be intended
%   after twist is applied
%
% despite what specified in the tables, the blade from lag hinge
% to pitch bearing is modeled as rigid

% number of blade nodes
nnodes = 2*nbeams + 1;

% nodes are equally spaced; other distributions can be used, provided
% intermediate nodes are at mid element
if (nbeams > 0),
	x_inter_element_nodes = l_pitch_bearing_x + [0:nbeams]/nbeams*(l_blade_radius - l_pitch_bearing_x);
	%%% otherwise add custom node distribution here

	%%% DO NOT MODIFY THIS
	% put mid-nodes in the middle of each element
	x_nodes(1:2:nnodes) = x_inter_element_nodes;
	x_nodes(2:2:nnodes-1) = (x_inter_element_nodes(1:nbeams) + x_inter_element_nodes(2:nbeams+1))/2;

	x_eval_points(1:2:2*nbeams) = x_nodes(2:2:2*nbeams) - .5/sqrt(3)*(x_inter_element_nodes(2:nbeams + 1) - x_inter_element_nodes(1:nbeams));
	x_eval_points(2:2:2*nbeams) = x_nodes(2:2:2*nbeams) + .5/sqrt(3)*(x_inter_element_nodes(2:nbeams + 1) - x_inter_element_nodes(1:nbeams));

	x_bodies = [x_nodes(1), x_eval_points, x_nodes(nnodes)];

else
	% one node, i.e. rigid blade
	x_nodes = l_pitch_bearing_x;
	x_bodies = [x_nodes(1), l_blade_radius];
end

% strategy:
%   1 body between the lag and the flap hinge
%   1 body after the flap hinge
%   1 body after the pitch bearing (coincident w/ flap hinge; first blade node
%       and only blade node for rigid blade)
%   2*nbeams nodes for the blade (if nbeams == 0 then blade is rigid)
% issues:
%   need to merge inertia data (mass, c.g. and twist inertia have different x)
%   need to interpolate compliances
%   need analytical integrals of linearly varying mass and inertia bodies

fin = fopen('blade0.nod', 'w');

fprintf(fin, '# This is the MBDyn model of the AS330 Puma described in Bousman 1996\n');
fprintf(fin, '# first blade node\n');
fprintf(fin, '\n');

fprintf(fin, '# x=%.3f m (%.3f R)\n', l_lag_hinge_axis_x, l_lag_hinge_axis_x/l_blade_radius);
fprintf(fin, 'structural: curr_blade + RF_blade_lag + %d, dynamic,\n', 0);
fprintf(fin, '        reference, curr_blade+RF_blade_lag, null,\n');
fprintf(fin, '        reference, curr_blade+RF_blade_lag, eye,\n');
fprintf(fin, '        reference, curr_blade+RF_blade_lag, null,\n');
fprintf(fin, '        reference, curr_blade+RF_blade_lag, null;\n');
fprintf(fin, '\n');

fprintf(fin, '# x=%.3f m (%.3f R)\n', l_flap_hinge_axis_x, l_flap_hinge_axis_x/l_blade_radius);
fprintf(fin, 'structural: curr_blade + RF_blade_flap + %d, dynamic,\n', 0);
fprintf(fin, '        reference, curr_blade+RF_blade_flap, null,\n');
fprintf(fin, '        reference, curr_blade+RF_blade_flap, eye,\n');
fprintf(fin, '        reference, curr_blade+RF_blade_flap, null,\n');
fprintf(fin, '        reference, curr_blade+RF_blade_flap, null;\n');
fprintf(fin, '\n');

fclose(fin);

fin = fopen('blade.nod', 'w');

fprintf(fin, '# This is the MBDyn model of the AS330 Puma described in Bousman 1996\n');
fprintf(fin, '# other blade nodes\n');
fprintf(fin, '\n');

for node = 1:nnodes,
	fprintf(fin, '# x=%.3f m (%.3f R)\n', x_nodes(node), x_nodes(node)/l_blade_radius);
	fprintf(fin, 'structural: curr_blade + RF_blade + %d, dynamic,\n', node-1);
	fprintf(fin, '        reference, curr_blade + RF_blade,\n');
	fprintf(fin, '                % e,% e,% e, # m\n', ...
			x_nodes(node) - l_pitch_bearing_x, 0., 0.);
	fprintf(fin, '        reference, curr_blade + RF_blade, eye,\n');
	fprintf(fin, '        reference, curr_blade + RF_blade, null,\n');
	fprintf(fin, '        reference, curr_blade + RF_blade, null;\n');
	fprintf(fin, '\n');
end

fclose(fin);

% blade root
fin = fopen('blade0.elm', 'w');

fprintf(fin, '# This is the MBDyn model of the AS330 Puma described in Bousman 1996\n');
fprintf(fin, '# blade root joints\n');
fprintf(fin, '\n');


fprintf(fin, '# blade root inertia and constraints\n');
fprintf(fin, '\n');

% lagging body
body(fin, l_lag_hinge_axis_x, l_flap_hinge_axis_x, l_lag_hinge_axis_x, 'RF_blade_lag', 0);

fprintf(fin, '# lag hinge\n');
fprintf(fin, 'joint: curr_blade + RF_blade_lag + 0, revolute hinge,\n');
fprintf(fin, '        curr_blade + RF_blade_lag + 0,\n');
fprintf(fin, '                reference, curr_blade + RF_blade_lag, null,\n');
fprintf(fin, '                hinge, reference, curr_blade + RF_blade_lag, eye,\n');
fprintf(fin, '        hub,\n');
fprintf(fin, '                reference, curr_blade + RF_blade_lag, null,\n');
fprintf(fin, '                hinge, reference, curr_blade + RF_blade_lag, eye;\n');
fprintf(fin, '\n');

fprintf(fin, '# lag hinge damper \n');
fprintf(fin, 'joint: curr_blade + RF_blade_lag + 1, deformable hinge,\n');
fprintf(fin, '        curr_blade + RF_blade_lag + 0,\n');
fprintf(fin, '                hinge, reference, curr_blade + RF_blade_lag, eye,\n');
fprintf(fin, '        hub,\n');
fprintf(fin, '                hinge, reference, curr_blade + RF_blade_lag, eye,\n');
fprintf(fin, '        linear viscous, 7000;\n');
fprintf(fin, '\n');

% flapping body
body(fin, l_flap_hinge_axis_x, l_pitch_bearing_x, l_flap_hinge_axis_x, 'RF_blade_flap', 0);

fprintf(fin, '# flap hinge\n');
fprintf(fin, 'joint: curr_blade + RF_blade_flap + 0, revolute hinge,\n');
fprintf(fin, '        curr_blade + RF_blade_flap + 0,\n');
fprintf(fin, '                reference, curr_blade + RF_blade_flap, null,\n');
fprintf(fin, '                hinge, reference, curr_blade + RF_blade_flap, eye,\n');
fprintf(fin, '        curr_blade + RF_blade_lag + 0,\n');
fprintf(fin, '                reference, curr_blade + RF_blade_flap, null,\n');
fprintf(fin, '                hinge, reference, curr_blade + RF_blade_flap, eye;\n');
fprintf(fin, '\n');

fclose(fin);

% blade
fin = fopen('blade.elm', 'w');

fprintf(fin, '# This is the MBDyn model of the AS330 Puma described in Bousman 1996\n');
fprintf(fin, '# blade inertia and constraints\n');
fprintf(fin, '\n');

fprintf(fin, '# pitch bearing\n');
fprintf(fin, 'joint: curr_blade + RF_blade + 0, revolute hinge,\n');
fprintf(fin, '        curr_blade + RF_blade + 0,\n');
fprintf(fin, '                reference, curr_blade + RF_blade_pitch, null,\n');
fprintf(fin, '                hinge, reference, curr_blade + RF_blade_pitch, eye,\n');
fprintf(fin, '        curr_blade + RF_blade_flap + 0,\n');
fprintf(fin, '                reference, curr_blade + RF_blade_pitch, null,\n');
fprintf(fin, '                hinge, reference, curr_blade + RF_blade_pitch, eye;\n');
fprintf(fin, '\n');

for count = 0:nnodes - 1,
	% blade bodies (pitching body in case of rigid blade)
	body(fin, x_bodies(count + 1), x_bodies(count + 2), l_pitch_bearing_x, 'RF_blade', count);
end

for count = 0:nbeams - 1,

	% blade beams
	beam(fin, x_nodes(2*count + 1), ...
		x_eval_points(2*count + 1), ...
		x_nodes(2*count + 2), ...
		x_eval_points(2*count + 2), ...
		x_nodes(2*count + 3), ...
		l_pitch_bearing_x, 'RF_blade', count);
end

fclose(fin);

fin = fopen('blade_aero.elm', 'w');

if nbeams == 0,

	fprintf(fin, '# This is the MBDyn model of the AS330 Puma described in Bousman 1996\n');
	fprintf(fin, '# blade aerodynamics\n');
	fprintf(fin, '\n');
	fprintf(fin, 'aerodynamic body: curr_blade + RF_blade + 1, curr_blade + RF_blade + 0,\n');
	fprintf(fin, '	rotor, 1,\n');
	fprintf(fin, '	reference, curr_blade + RF_blade,\n');
	fprintf(fin, '		(l_blade_radius + l_blade_root_cutout)/2. - l_pitch_bearing_x,\n');
	fprintf(fin, '		0.,\n');
	fprintf(fin, '		0.,\n');
	fprintf(fin, '	reference, curr_blade + RF_blade,\n');
	fprintf(fin, '		1, 0.,-1.,0.,\n');
	fprintf(fin, '		2, 0.,0.,1.,\n');
	fprintf(fin, '	l_blade_radius - l_blade_root_cutout,\n');
	fprintf(fin, '	const, l_blade_chord,\n');
	fprintf(fin, '	const, 0.,\n');
	fprintf(fin, '	const, -l_blade_chord/2.*aero_velocity_75_percent,\n');
	fprintf(fin, '	piecewise linear, 9,\n');
	fprintf(fin, '		(-7.490 + (l_blade_radius + l_blade_root_cutout)/2.)/((l_blade_radius - l_blade_root_cutout)/2.), -6.117*deg2rad,\n');
	fprintf(fin, '		(-6.257 + (l_blade_radius + l_blade_root_cutout)/2.)/((l_blade_radius - l_blade_root_cutout)/2.), -4.800*deg2rad,\n');
	fprintf(fin, '		(-3.507 + (l_blade_radius + l_blade_root_cutout)/2.)/((l_blade_radius - l_blade_root_cutout)/2.), -1.867*deg2rad,\n');
	fprintf(fin, '		(-3.257 + (l_blade_radius + l_blade_root_cutout)/2.)/((l_blade_radius - l_blade_root_cutout)/2.), -1.600*deg2rad,\n');
	fprintf(fin, '		(-3.007 + (l_blade_radius + l_blade_root_cutout)/2.)/((l_blade_radius - l_blade_root_cutout)/2.), -1.283*deg2rad,\n');
	fprintf(fin, '		(-2.757 + (l_blade_radius + l_blade_root_cutout)/2.)/((l_blade_radius - l_blade_root_cutout)/2.), -0.983*deg2rad,\n');
	fprintf(fin, '		(-2.507 + (l_blade_radius + l_blade_root_cutout)/2.)/((l_blade_radius - l_blade_root_cutout)/2.), -0.617*deg2rad,\n');
	fprintf(fin, '		(-2.257 + (l_blade_radius + l_blade_root_cutout)/2.)/((l_blade_radius - l_blade_root_cutout)/2.), -0.300*deg2rad,\n');
	fprintf(fin, '		(-2.080 + (l_blade_radius + l_blade_root_cutout)/2.)/((l_blade_radius - l_blade_root_cutout)/2.), -0.155*deg2rad,\n');
	fprintf(fin, '	aero_integration_points,\n');
	fprintf(fin, '	c81, naca0012,\n');
	fprintf(fin, '	unsteady, aero_unsteady_flag;\n');

else
	for count = 0:nbeams - 1,
		% blade aerobeams
		beam_aero(fin, x_nodes(2*count + 1), ...
			x_nodes(2*count + 2), ...
			x_nodes(2*count + 3), ...
			l_blade_root_cutout, l_pitch_bearing_x, 'RF_blade', count);
	end
end

fclose(fin);

