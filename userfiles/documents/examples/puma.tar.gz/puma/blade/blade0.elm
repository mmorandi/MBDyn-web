# This is the MBDyn model of the AS330 Puma described in Bousman 1996
# blade root joints

# blade root inertia and constraints

# RF_blade_lag + 0:  2.690000e-01 ->  2.890000e-01 m (0.036 -> 0.039 R)
body: curr_blade + RF_blade_lag + 0, curr_blade + RF_blade_lag + 0,
         5.256000e-01, # kg; dL= 9.000000e-03 m; ycg= 0.000000e+00 m
        reference, curr_blade + RF_blade_lag,
                 1.550000e-02, 0.000000e+00, 0.000000e+00,
        reference, curr_blade + RF_blade_lag,
                sym,      0.000000e+00, 0.000000e+00, 0.000000e+00,
                                        3.547800e-06, 0.000000e+00,
                                                      3.547800e-06;

# lag hinge
joint: curr_blade + RF_blade_lag + 0, revolute hinge,
        curr_blade + RF_blade_lag + 0,
                reference, curr_blade + RF_blade_lag, null,
                hinge, reference, curr_blade + RF_blade_lag, eye,
        hub,
                reference, curr_blade + RF_blade_lag, null,
                hinge, reference, curr_blade + RF_blade_lag, eye;

# lag hinge damper 
joint: curr_blade + RF_blade_lag + 1, deformable hinge,
        curr_blade + RF_blade_lag + 0,
                hinge, reference, curr_blade + RF_blade_lag, eye,
        hub,
                hinge, reference, curr_blade + RF_blade_lag, eye,
        linear viscous, 7000;

# RF_blade_flap + 0:  2.890000e-01 ->  4.320000e-01 m (0.039 -> 0.058 R)
body: curr_blade + RF_blade_flap + 0, curr_blade + RF_blade_flap + 0,
         8.351200e+00, # kg; dL= 1.430000e-01 m; ycg= 0.000000e+00 m
        reference, curr_blade + RF_blade_flap,
                 7.150000e-02, 0.000000e+00, 0.000000e+00,
        reference, curr_blade + RF_blade_flap,
                sym,      0.000000e+00, 0.000000e+00, 0.000000e+00,
                                        1.423114e-02, 0.000000e+00,
                                                      1.423114e-02;

# flap hinge
joint: curr_blade + RF_blade_flap + 0, revolute hinge,
        curr_blade + RF_blade_flap + 0,
                reference, curr_blade + RF_blade_flap, null,
                hinge, reference, curr_blade + RF_blade_flap, eye,
        curr_blade + RF_blade_lag + 0,
                reference, curr_blade + RF_blade_flap, null,
                hinge, reference, curr_blade + RF_blade_flap, eye;

