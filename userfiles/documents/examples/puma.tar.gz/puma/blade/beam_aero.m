% MBDyn (C) is a multibody analysis code. 
% http://www.mbdyn.org
% 
% Copyright (C) 1996-2006
% 
% Pierangelo Masarati	<masarati@aero.polimi.it>
% Paolo Mantegazza	<mantegazza@aero.polimi.it>
% 
% Dipartimento di Ingegneria Aerospaziale - Politecnico di Milano
% via La Masa, 34 - 20156 Milano, Italy
% http://www.aero.polimi.it
% 
% Changing this copyright notice is forbidden.
% 
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation (version 2 of the License).
% 
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

% This is part of the MBDyn model of the AS330 Puma described in
%
% William G. Bousman, Colin Young, Francois Toulmay, Neil E. Gilbert,
% Roger C. Strawn, Judith V. Miller, Thomas H. Maier, Michel Costes,
% Philippe Beaumier: "A Comparison of Lifting-Line and CFD Methods
% with Flight Test Data from a Research Puma Helicopter",
% NASA TM 110421, October 1996

function beam_aero(fin, xstart, xmid, xend, xcutout, xref, ref, count)

global l_blade_radius blade_data BLADE_STATION BLADE_TWIST

js = find(blade_data(:, BLADE_STATION) >= xstart);
js = js(1);
if (js > 1),
	js = js - 1;
end

if (xstart == blade_data(js, BLADE_STATION)),
	jt(1) = blade_data(js, BLADE_TWIST);
else
	ll = blade_data(js + 1, BLADE_STATION) - blade_data(js, BLADE_STATION);
	l1 = blade_data(js + 1, BLADE_STATION) - xstart;
	l2 = xstart - blade_data(js, BLADE_STATION);
	jt(1) = [l1 l2]*blade_data(js + [0 1], BLADE_TWIST)/ll;
end

jm = find(blade_data(:, BLADE_STATION) >= xmid);
jm = jm(1);
if (blade_data(jm + 1, BLADE_STATION) == blade_data(jm, BLADE_STATION)),
	jm = jm + 1;
end

if (xmid == blade_data(jm, BLADE_STATION)),
	jt(2) = blade_data(jm, BLADE_TWIST);
else
	ll = blade_data(jm + 1, BLADE_STATION) - blade_data(jm, BLADE_STATION);
	l1 = blade_data(jm + 1, BLADE_STATION) - xmid;
	l2 = xmid - blade_data(jm, BLADE_STATION);
	jt(2) = [l1 l2]*blade_data(jm + [0 1], BLADE_TWIST)/ll;
end

je = find(blade_data(:, BLADE_STATION) >= xend);
if (length(je) > 1),
	je = je(1);
	if (blade_data(je + 1, BLADE_STATION) == blade_data(je, BLADE_STATION)),
		je = je + 1;
	end
end
je = je(1);


if (xend == blade_data(je, BLADE_STATION)),
	jt(3) = blade_data(je, BLADE_TWIST);
else
	ll = blade_data(je + 1, BLADE_STATION) - blade_data(je, BLADE_STATION);
	l1 = blade_data(je + 1, BLADE_STATION) - xend;
	l2 = xend - blade_data(je, BLADE_STATION);
	jt(3) = [l1 l2]*blade_data(je + [0 1], BLADE_TWIST)/ll;
end

fprintf(fin, '# %s + %d: % e -> % e -> % e m (%.3f -> %.3f -> %.3f R)\n', ...
	ref, count, xstart, xmid, xend, xstart/l_blade_radius, xmid/l_blade_radius, xend/l_blade_radius);

fprintf(fin, 'aerodynamic beam: curr_blade + %s + %d,\n', ref, count);
fprintf(fin, '	curr_blade + %s + %d,\n', ref, count);
fprintf(fin, '	rotor, 1,\n');

for i = 1:3,
	fprintf(fin, '	reference, node,\n');
	fprintf(fin, '		% e, % e, % e,\n', 0., 0., 0.);
	fprintf(fin, '	reference, curr_blade + RF_blade,\n');
	%fprintf(fin, '		1,  0., -1.,  0.,\n');
	%fprintf(fin, '		2,  0.,  0.,  1.,\n');
	c = cos(jt(i)*pi/180);
	s = sin(jt(i)*pi/180);
	fprintf(fin, '		1, % e, % e, % e,\n', 0., -c, s);
	fprintf(fin, '		2, % e, % e, % e,\n', 0., -s, -c);
end

if (xend < xcutout),
	fprintf(fin, '	const, 0.,\n');

	fprintf(fin, '	const, 0.,\n');

	fprintf(fin, '	const, 0.,\n');
elseif (xstart < xcutout),
	xx = 2.*(xcutout - xmid)/(xend - xstart);

	fprintf(fin, '	piecewise linear, 4,\n');
	fprintf(fin, '		% e, 0.,\n', -1.);
	fprintf(fin, '		% e, 0.,\n', xx - 1.e-7);
	fprintf(fin, '		% e, l_blade_chord,\n', xx + 1.e-7);
	fprintf(fin, '		% e, l_blade_chord,\n', 1.);

	fprintf(fin, '	const, 0.,\n');

	fprintf(fin, '	piecewise linear, 4,\n');
	fprintf(fin, '		% e, 0.,\n', -1.);
	fprintf(fin, '		% e, 0.,\n', xx - 1.e-7);
	fprintf(fin, '		% e, -l_blade_chord/2.*aero_velocity_75_percent,\n', xx + 1.e-7);
	fprintf(fin, '		% e, -l_blade_chord/2.*aero_velocity_75_percent,\n', 1.);
else
	fprintf(fin, '	const, l_blade_chord,\n');

	fprintf(fin, '	const, 0.,\n');

	fprintf(fin, '	const, -l_blade_chord/2.*aero_velocity_75_percent,\n');
end
fprintf(fin, '	const, 0.,\n');
fprintf(fin, '	aero_integration_points,\n');
fprintf(fin, '	c81, naca0012,\n');
fprintf(fin, '	unsteady, aero_unsteady_flag;\n');

fprintf(fin, '\n');

