% MBDyn (C) is a multibody analysis code. 
% http://www.mbdyn.org
% 
% Copyright (C) 1996-2006
% 
% Pierangelo Masarati	<masarati@aero.polimi.it>
% Paolo Mantegazza	<mantegazza@aero.polimi.it>
% 
% Dipartimento di Ingegneria Aerospaziale - Politecnico di Milano
% via La Masa, 34 - 20156 Milano, Italy
% http://www.aero.polimi.it
% 
% Changing this copyright notice is forbidden.
% 
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation (version 2 of the License).
% 
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

% This is part of the MBDyn model of the AS330 Puma described in
%
% William G. Bousman, Colin Young, Francois Toulmay, Neil E. Gilbert,
% Roger C. Strawn, Judith V. Miller, Thomas H. Maier, Michel Costes,
% Philippe Beaumier: "A Comparison of Lifting-Line and CFD Methods
% with Flight Test Data from a Research Puma Helicopter",
% NASA TM 110421, October 1996

function beam(fin, xstart, x1, xmid, x2, xend, xref, ref, count)

global l_blade_radius blade_data BLADE_STATION BLADE_TWIST BLADE_MASS BLADE_CG BLADE_EA BLADE_EJF BLADE_EJC BLADE_GJ BLADE_J

js = find(blade_data(:, BLADE_STATION) >= xstart);
js = js(1);
if (js > 1),
	js = js - 1;
end

j1 = find(blade_data(:, BLADE_STATION) >= x1);
j1 = j1(1);

jm = find(blade_data(:, BLADE_STATION) >= xmid);
jm = jm(1);

j2 = find(blade_data(:, BLADE_STATION) >= x2);
j2 = j2(1);

je = find(blade_data(:, BLADE_STATION) >= xend);
je = je(1);

fprintf(fin, '# %s + %d: % e -> % e m (%.3f -> %.3f R)\n', ref, count, xstart, xend, xstart/l_blade_radius, xend/l_blade_radius);
fprintf(fin, '#     x1=% e xm=% e x2=% e (%.3f -> %.3f -> %.3f R\n', x1, xmid, x2, x1/l_blade_radius, xmid/l_blade_radius, x2/l_blade_radius);

fprintf(fin, 'beam: curr_blade + %s + %d', ref, count);

for i = 1:3,
	fprintf(fin, ',\n');
	fprintf(fin, '        curr_blade + %s + %d,\n', ref, 2*count + i - 1);
	fprintf(fin, '        reference, node,\n');
	fprintf(fin, '                % e,% e,% e', 0., 0., 0.);
end

jis = [j1 j2];
xis = [x1 x2];
for i = 1:2,
	ji = jis(i);
	k = 0;
	xs = xis(i);

	if (blade_data(ji + 2*k, BLADE_STATION) < xs),
		% interpolate
		dxs = xs;
		d1 = blade_data(ji + 2*k + 1, BLADE_STATION) - dxs;
		d2 = dxs - blade_data(ji + 2*k, BLADE_STATION);
		th = ([d1 d2]/(d1 + d2))*blade_data(ji + 2*k + [0 1], BLADE_TWIST);
		EA = ([d1 d2]/(d1 + d2))*blade_data(ji + 2*k + [0 1], BLADE_EA);
		EJf = ([d1 d2]/(d1 + d2))*blade_data(ji + 2*k + [0 1], BLADE_EJF);
		EJc = ([d1 d2]/(d1 + d2))*blade_data(ji + 2*k + [0 1], BLADE_EJC);
		GJ = ([d1 d2]/(d1 + d2))*blade_data(ji + 2*k + [0 1], BLADE_GJ);
	else
		% exact
		dx = blade_data(ji + 2*k, BLADE_STATION);
		th = blade_data(ji + 2*k, BLADE_TWIST);
		EA = blade_data(ji + 2*k, BLADE_EA);
		EJf = blade_data(ji + 2*k, BLADE_EJF);
		EJc = blade_data(ji + 2*k, BLADE_EJC);
		GJ = blade_data(ji + 2*k, BLADE_GJ);
	end

	tw = th/180*pi;
	Rot = [1 0 0; 0 cos(tw) -sin(tw);0 sin(tw) cos(tw)];

	GAf = EA;
	GAc = EA;

	D = Rot*diag([GJ EJf EJc])*Rot';

	fprintf(fin, ',\n');
	fprintf(fin, '        # point %d\n', i);
	fprintf(fin, '        # twist=%.3f deg\n', tw*180/pi);
	fprintf(fin, '        reference, curr_blade + %s,\n', ref);
	fprintf(fin, '                1, % e,% e,% e,\n', 1., 0., 0.);
	fprintf(fin, '                2, % e,% e,% e,\n', Rot(1, 2), Rot(2, 2), Rot(3, 2));
	fprintf(fin, '        # EA=% e N EJf=% e Nm^2 EJc=% e Nm^2 GJ=% e Nm^2\n', EA, EJf, EJc, GJ);
	fprintf(fin, '        linear viscoelastic generic,\n');
	fprintf(fin, '                diag,\n');
	fprintf(fin, '                        % e,% e,% e,\n', EA, GAc, GAf);
	fprintf(fin, '                        % e,% e,% e,\n', GJ, EJf, EJc);
%	fprintf(fin, '                sym,    % e,% e,% e,% e,% e,% e,\n', EA, 0., 0., 0., 0., 0.);
%	fprintf(fin, '                                      % e,% e,% e,% e,% e,\n', GAc, 0., 0., 0., 0.);
%	fprintf(fin, '                                                    % e,% e,% e,% e,\n', GAf, 0., 0., 0.);
%	fprintf(fin, '                                                                  % e,% e,% e,\n', D(1, 1), D(1, 2), D(1, 3));
%	fprintf(fin, '                                                                                % e,% e,\n', D(2, 2), D(2, 3));
%	fprintf(fin, '                                                                                              % e,\n', D(3, 3));
	fprintf(fin, '                proportional, blade_damp');
end

fprintf(fin, ';\n');
fprintf(fin, '\n');

