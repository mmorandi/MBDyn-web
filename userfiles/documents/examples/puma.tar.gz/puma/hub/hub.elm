# MBDyn (C) is a multibody analysis code. 
# http://www.mbdyn.org
# 
# Copyright (C) 1996-2006
# 
# Pierangelo Masarati	<masarati@aero.polimi.it>
# Paolo Mantegazza	<mantegazza@aero.polimi.it>
# 
# Dipartimento di Ingegneria Aerospaziale - Politecnico di Milano
# via La Masa, 34 - 20156 Milano, Italy
# http://www.aero.polimi.it
# 
# Changing this copyright notice is forbidden.
# 
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation (version 2 of the License).
# 
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

# This is part of the MBDyn model of the AS330 Puma described in
#
# William G. Bousman, Colin Young, Francois Toulmay, Neil E. Gilbert,
# Roger C. Strawn, Judith V. Miller, Thomas H. Maier, Michel Costes,
# Philippe Beaumier: "A Comparison of Lifting-Line and CFD Methods
# with Flight Test Data from a Research Puma Helicopter",
# NASA TM 110421, October 1996

# mast rotation
joint: hub, axial rotation,
	hub,
		reference, RF_hub, null,
		hinge, reference, RF_hub, eye,
	helicopter,
		reference, RF_hub, null,
		hinge, reference, RF_hub, eye,
	cosine, 0.,pi/1.,(Omega-Omega0)/2.,half,Omega0;

# fixed swashplate constraints
joint: swashplate_fixed, inline,
	helicopter,
		reference, RF_swashplate_fixed, null,
		reference, RF_swashplate_fixed, eye,
	swashplate_fixed,
		offset, reference, RF_swashplate_fixed, null;

# scissors to prevent fixed plate rotation
joint: swashplate_fixed + 1, inplane,
	helicopter,
		reference, RF_swashplate_fixed, 1.,0.,0.,
		reference, RF_swashplate_fixed, 0.,1.,0.,
	swashplate_fixed,
		offset, reference, RF_swashplate_fixed, 1.,0.,0.;

# swashplate actuators
joint: swashplate_fixed + 11, distance with offset,
	helicopter,
		reference, RF_swashplate_fixed,
			l_sw_actuator_radius*cos(-pi/3.),
			l_sw_actuator_radius*sin(-pi/3.),
			-l_sw_actuator_length,
	swashplate_fixed,
		reference, RF_swashplate_fixed,
			l_sw_actuator_radius*cos(-pi/3.),
			l_sw_actuator_radius*sin(-pi/3.),
			0.,
	dof, sw_actuator_1, abstract, algebraic,
		linear, l_sw_actuator_length, 1.;
joint: swashplate_fixed + 12, distance with offset,
	helicopter,
		reference, RF_swashplate_fixed,
			l_sw_actuator_radius*cos(pi),
			l_sw_actuator_radius*sin(pi),
			-l_sw_actuator_length,
	swashplate_fixed,
		reference, RF_swashplate_fixed,
			l_sw_actuator_radius*cos(pi),
			l_sw_actuator_radius*sin(pi),
			0.,
	dof, sw_actuator_2, abstract, algebraic,
		linear, l_sw_actuator_length, 1.;
joint: swashplate_fixed + 13, distance with offset,
	helicopter,
		reference, RF_swashplate_fixed,
			l_sw_actuator_radius*cos(pi/3.),
			l_sw_actuator_radius*sin(pi/3.),
			-l_sw_actuator_length,
	swashplate_fixed,
		reference, RF_swashplate_fixed,
			l_sw_actuator_radius*cos(pi/3.),
			l_sw_actuator_radius*sin(pi/3.),
			0.,
	dof, sw_actuator_3, abstract, algebraic,
		linear, l_sw_actuator_length, 1.;

# rotating swashplate constraints
joint: swashplate_rotating, revolute hinge,
	swashplate_fixed,
		reference, RF_swashplate_fixed, null,
		hinge, reference, RF_swashplate_fixed, eye,
	swashplate_rotating,
		reference, RF_swashplate_rotating, null,
		hinge, reference, RF_swashplate_rotating, eye;

# scissors to keep rotating plate in sync with hub
joint: swashplate_rotating + 1, inplane,
	hub,
		reference, RF_swashplate_rotating, 1.,0.,0.,
		reference, RF_swashplate_rotating, 0.,1.,0.,
	swashplate_rotating,
		offset, reference, RF_swashplate_rotating, 1.,0.,0.;

# swashplate controls ditributor
genel: swashplate_fixed, swashplate,
	sw_collective,
	sw_fore_aft,
	sw_lateral,
	sw_actuator_1,
	sw_actuator_2,
	sw_actuator_3,
	1e-3,		# delay
	2.84516,	# black magic
	0.18;		# approx. ypltop

