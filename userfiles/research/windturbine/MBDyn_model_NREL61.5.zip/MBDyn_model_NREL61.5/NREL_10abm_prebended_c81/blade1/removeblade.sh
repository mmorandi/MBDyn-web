
 rm blade1.abm
 rm blade1.abm.set
 rm blade1.fbd
 rm blade1.fbd.set
 rm blade1.inr
#rm blade1.jnt
 rm blade1.nod
 rm blade1.nod.set
 rm blade1.rbd
 rm blade1.rbd.set
#rm blade1.set


cp /cygdrive/c/mbdyn.pre/model_generator/_model/RE6M_10bm_fit_nonadaptive_k1.0/blade1/blade1.abm     ./
cp /cygdrive/c/mbdyn.pre/model_generator/_model/RE6M_10bm_fit_nonadaptive_k1.0/blade1/blade1.fbd     ./
cp /cygdrive/c/mbdyn.pre/model_generator/_model/RE6M_10bm_fit_nonadaptive_k1.0/blade1/blade1.nod     ./
cp /cygdrive/c/mbdyn.pre/model_generator/_model/RE6M_10bm_fit_nonadaptive_k1.0/blade1/blade1.rbd     ./
cp /cygdrive/c/mbdyn.pre/model_generator/_model/RE6M_10bm_fit_nonadaptive_k1.0/blade1/blade1.abm.set ./
cp /cygdrive/c/mbdyn.pre/model_generator/_model/RE6M_10bm_fit_nonadaptive_k1.0/blade1/blade1.fbd.set ./
cp /cygdrive/c/mbdyn.pre/model_generator/_model/RE6M_10bm_fit_nonadaptive_k1.0/blade1/blade1.nod.set ./
cp /cygdrive/c/mbdyn.pre/model_generator/_model/RE6M_10bm_fit_nonadaptive_k1.0/blade1/blade1.rbd.set ./
