 mv blade1.abm     blade3.abm
 mv blade1.fbd     blade3.fbd
 mv blade1.abm.set blade3.abm.set
 mv blade1.fbd.set blade3.fbd.set
 mv blade1.nod.set blade3.nod.set
 mv blade1.rbd.set blade3.rbd.set

#mv blade1.abm         blade3.abm
#mv blade1.abm.set     blade3.abm.set
#mv blade1.fbd         blade3.fbd
#mv blade1.fbd.set     blade3.fbd.set
#mv blade1.inr         blade3.inr
#mv blade1.jnt         blade3.jnt
#mv blade1.nod         blade3.nod
#mv blade1.nod.set     blade3.nod.set
#mv blade1.rbd         blade3.rbd
#mv blade1.rbd.set     blade3.rbd.set
#mv blade1.set         blade3.set
