
 rm blade3.abm
 rm blade3.abm.set
 rm blade3.fbd
 rm blade3.fbd.set
#rm blade3.inr
#rm blade3.jnt
 rm blade3.nod
 rm blade3.nod.set
 rm blade3.rbd
 rm blade3.rbd.set
#rm blade3.set


cp /cygdrive/c/mbdyn.pre/model_generator/_model/RE6M_10bm_fit_nonadaptive_k1.0/blade1/blade1.abm     ./
cp /cygdrive/c/mbdyn.pre/model_generator/_model/RE6M_10bm_fit_nonadaptive_k1.0/blade1/blade1.fbd     ./
cp /cygdrive/c/mbdyn.pre/model_generator/_model/RE6M_10bm_fit_nonadaptive_k1.0/blade1/blade1.nod     ./
cp /cygdrive/c/mbdyn.pre/model_generator/_model/RE6M_10bm_fit_nonadaptive_k1.0/blade1/blade1.rbd     ./
cp /cygdrive/c/mbdyn.pre/model_generator/_model/RE6M_10bm_fit_nonadaptive_k1.0/blade1/blade1.abm.set ./
cp /cygdrive/c/mbdyn.pre/model_generator/_model/RE6M_10bm_fit_nonadaptive_k1.0/blade1/blade1.fbd.set ./
cp /cygdrive/c/mbdyn.pre/model_generator/_model/RE6M_10bm_fit_nonadaptive_k1.0/blade1/blade1.nod.set ./
cp /cygdrive/c/mbdyn.pre/model_generator/_model/RE6M_10bm_fit_nonadaptive_k1.0/blade1/blade1.rbd.set ./
