#
# Copyright  (C)  2008  Patrick Rix             <p.rix|at|online.de>
#                   and Philippe-Emmanuel Ascar <philoupointcom|at|hotmail.fr>
#
# This file can be freely used and modified to be run with MBDyn
# provided this copyright notice is not altered nor removed.
#
# THIS MODEL IS PROVIDED AS IS, WITHOUT ANY WARRANTY OF ACCURACY
# OR FITNESS FOR ANY PURPOSE.
#
# ---------------------------------------------------------------
#
# MBDyn model of a LM61.5 Rotorblade as described by  Risoe
#       dated:  22. May 2008
#
# ---------------------------------------------------------------
#
#
#   MBDyn - Model:   >>> LM61p5_3blades <<<   Ver. 1.2.3
#
#   MBDyn - LM61p5_3blades Model 1.0.0
#   ---------------------------------------------
#             H U B   ELEMENTS
#   ---------------------------------------------
#



  # Clamp

# joint: JT_ground_Clamp      , clamp           , # 10011
#   NS_ground, node, node,                        # 1001
#   output, yes  # switch for individual element output
# ;
#
# joint: JT_main_bearing_FIX_TotJnt, total joint,
#   NS_main_bearing_FIX,
#     position            , reference, RF_main_bearing_FIX, null,
#     position orientation, reference, RF_main_bearing_FIX, eye ,
#     rotation orientation, reference, RF_main_bearing_FIX, eye ,
#   NS_ground,
#     position            , reference, RF_main_bearing_FIX, null,
#     position orientation, reference, RF_main_bearing_FIX, eye ,
#     rotation orientation, reference, RF_main_bearing_FIX, eye ,
#   position    constraint, active, active, active, null,
#   orientation constraint, active, active, active, null,
#   output, no   # switch for individual element output
# ;


##########################################################

# SECOND VARIANT
# ==============

# joint: JT_main_bearing_FIX_Clamp      , clamp           , # 10011
#   NS_main_bearing_FIX, node, node,                        # 1001
#   output, no   # switch for individual element output
# ;
#
# joint: JT_hub_center_FIX_TotJnt, total joint,
#   NS_main_bearing_FIX,
#     position            , reference, RF_hub_center_FIX, null,
#     position orientation, reference, RF_hub_center_FIX, eye ,
#     rotation orientation, reference, RF_hub_center_FIX, eye ,
#   NS_hub_center_FIX,
#     position            , reference, RF_hub_center_FIX, null,
#     position orientation, reference, RF_hub_center_FIX, eye ,
#     rotation orientation, reference, RF_hub_center_FIX, eye ,
#   position    constraint, active, active, active, null,
#   orientation constraint, active, active, active, null,
#   output, no   # switch for individual element output
# ;

#############################

  joint: JT_hub_center_FIX_Clamp      , clamp           , #
    NS_hub_center_FIX, node, node,                        #
    output, yes  # switch for individual element output
  ;


  joint: JT_hub_FIX_rotor_cnt_Clamp      , clamp           ,
    NS_hub_FIX_rotor_cnt, node, node,
    output, yes  # switch for individual element output
  ;

  joint: JT_hub_FIX_rotor_top_Clamp      , clamp           ,
    NS_hub_FIX_rotor_top, node, node,
    output, yes  # switch for individual element output
  ;


  joint: JT_hub_FIX_rotor_bot_Clamp      , clamp           ,
    NS_hub_FIX_rotor_bot, node, node,
    output, yes  # switch for individual element output
  ;


  joint: JT_hub_FIX_rotor_rgt_Clamp      , clamp           ,
    NS_hub_FIX_rotor_rgt, node, node,
    output, yes  # switch for individual element output
  ;


  joint: JT_hub_FIX_rotor_lft_Clamp      , clamp           ,
    NS_hub_FIX_rotor_lft, node, node,
    output, yes  # switch for individual element output
  ;


 ##-----------------------------------------------------------------------------------------------
 ##  VARIANT(1)
 ##-----------------------------------------------------------------------------------------------
 ## R O T O R   S P E E D  UP : smooth acceleration using a ANGULAR VELOCITY JOINT and a cosine-HALF-drive

# joint: JT_hub_center_ROTATING_AngVel, angular velocity, #
#   NS_hub_center_ROTATING,
#   reference, RF_hub_center_ROTATING, 1, 0, 0,
#   string,
#     "(
#       ( (  Time <= T_InitRampUp_WindSpeed                                       ) * 0.              )
#       +
#       ( ( (Time >  T_InitRampUp_WindSpeed) && (Time <= T_InitRampUp_RotorSpeed) ) *
#         (omega_start * 0.5*(1-cos(pi*((Time-T_InitRampUp_WindSpeed)/T_InitRampUpPeriod_RotorSpeed)))) )
#       +
#       ( ( (Time <= T_RampBegin_RotorSpeed) && (Time >  T_InitRampUp_RotorSpeed) ) * omega_start     )
#       +
#       ( (  Time >  T_RampBegin_RotorSpeed                                       ) *
#         ( omega_start + (omega_stop - omega_start)*(Time-T_RampBegin_RotorSpeed)/(T_RampEnd_RotorSpeed-T_RampBegin_RotorSpeed))
#       )
#     )",
#   output, no
# ;



# omega_Init_TStart = 0.;
# omega_Init_TStop



  joint: JT_hub_center_ROTATING_AngVel, angular velocity, #
    NS_hub_center_ROTATING,
    reference, RF_hub_center_ROTATING, 1, 0, 0,
    string, # (omega_start==omega_init)*1.
            # (omega_start> omega_init)*
      "((omega_init)
       +(omega_start-omega_init)*(omega_start!=omega_init)*
        (  ((Time>=T_Start      )&&(Time< omega_Init_TE))*0.5*(1.-cos(pi*(Time-T_Start)/(omega_Init_TE-T_Start)))
          +( Time>=omega_Init_TE                        )*1.
        )
       +(omega_delta)*
        (   ((Time>=T_Start      )&&(Time< omega_Ramp_T0))* 0.
           +((Time>=omega_Ramp_T0)&&(Time<=T_Stop))*(Time-omega_Ramp_T0)/(omega_Ramp_TE-omega_Ramp_T0)
        )
      )",
     ##
    #  +
    #  omega_Ramp_delta*
    #  (   ((Time>=T_Start      )&&(Time< omega_Ramp_T0))* 0.
    #     +((Time>=omega_Ramp_T0)&&(Time< omega_Ramp_TE))* (Time-omega_Ramp_T0)/(omega_Ramp_TE-omega_Ramp_T0)
    #     + (Time>=omega_Ramp_TE)                        * 1.
    #  )

  # "(
  #    omega_start*
  #    (   ((Time>=T_Start      )&&(Time< omega_Init_T0))* 0.
  #       +((Time>=omega_Init_T0)&&(Time< omega_Init_TE))* 0.5 *(1.-cos(pi*(Time-omega_Init_T0)/(omega_Init_TE-omega_Init_T0)))
  #       + (Time>=omega_Init_TE)                        * 1.
  #    )
  #    +
  #    omega_Ramp_delta*
  #    (   ((Time>=T_Start      )&&(Time< omega_Ramp_T0))* 0.
  #       +((Time>=omega_Ramp_T0)&&(Time< omega_Ramp_TE))* (Time-omega_Ramp_T0)/(omega_Ramp_TE-omega_Ramp_T0)
  #       + (Time>=omega_Ramp_TE)                        * 1.
  #    )
  # )",

    output, no  # no  # OUT_JT_main_bearing_ROTATING_AngVel  # switch for individual element output
  ;





##-----------------------------------------------------------------------------------------------
  # DRIVEN REVOLUTE HINGE
  #
  # Definition of the revolute hinge joint which replaces the above
  # axial rotation joint at the end of the start up phase.
  #
  joint: JT_hub_center_ROTATING_RevHin, revolute hinge, #
    NS_hub_center_FIX,
      reference, RF_hub_center_FIX, null,
      hinge, reference, RF_rotor_axis, eye,
    NS_hub_center_ROTATING,
      reference, RF_hub_center_FIX, null,
      hinge, reference, RF_rotor_axis, eye,
    output, no
  ;

  # ============================================================================================================================

  # ===== #
  # ROTOR #
  # ===== #

  joint: JT_rotor_TotJnt, total joint,
    NS_rotor,
      position, reference, RF_hub_center_ROTATING, null,
      position orientation, reference, RF_hub_center_ROTATING, eye,
      rotation orientation, reference, RF_hub_center_ROTATING, eye,
    NS_hub_center_ROTATING,
      position, reference, RF_hub_center_ROTATING, null,
      position orientation, reference, RF_hub_center_ROTATING, eye,
      rotation orientation, reference, RF_hub_center_ROTATING, eye,
    position constraint, active, active, active, null,
    orientation constraint, active, active, active, null
  ;



  # ============================================================================================================================

  # =================== #
  # AIRCRAFT INSTRUMENT #
  # =================== #

  aircraft instruments: AI_hub_FIX_rotor_cnt , NS_hub_FIX_rotor_cnt ; # 60000 # , orientation, eye ;
  aircraft instruments: AI_hub_FIX_rotor_top , NS_hub_FIX_rotor_top ; # 60001 # , orientation, eye ;
  aircraft instruments: AI_hub_FIX_rotor_bot , NS_hub_FIX_rotor_bot ; # 60002 # , orientation, eye ;
  aircraft instruments: AI_hub_FIX_rotor_rgt , NS_hub_FIX_rotor_rgt ; # 60003 # , orientation, eye ;
  aircraft instruments: AI_hub_FIX_rotor_lft , NS_hub_FIX_rotor_lft ; # 60004 # , orientation, eye ;

  # BIND EXAMPLE (output= .prm)

# bind:
#   AI_hub_FIX_rotor_cnt, aircraft instruments,              # 60000
#   NP_hub_center_FIX_airspeed, string, "airspeed"           # 600001
# ;
# bind:
#   AI_hub_FIX_rotor_cnt, aircraft instruments,              # 60000
#   NP_hub_center_FIX_groundspeed, string, "groundspeed"     # 600002
# ;
# bind:
#   AI_hub_FIX_rotor_cnt, aircraft instruments,              # 60000
#   NP_hub_center_FIX_verticalspeed, string, "verticalspeed" # 600003
# ;
# bind:
#   AI_hub_FIX_rotor_cnt, aircraft instruments              , # 60000
#   NP_hub_center_FIX_angleofattack, string, "angleofattack"   # 600004
# ;
# bind:
#   AI_hub_FIX_rotor_cnt, aircraft instruments              , # 60000
#   NP_hub_center_FIX_altitude, string, "altitude"            # 600005
# ;


  # ============================================================================================================================

  #             * * * * * * * * * * * * * *
  #            * R O T O R   E L E M E N T *
  #             * * * * * * * * * * * * * *

  induced velocity: RT_rotor,
    NS_hub_center_FIX,   # 'aircraft_node' is the fix rotor_hub_center node clamped to main_bearing node
      hinge, reference, RF_rotor_axis, eye,
    NS_rotor,                     # the rotating rotor node is clamped to hub centre node but with its Z-axis  ==  ROTOR AXIS
    induced velocity,
    # no,
      uniform,   # supported induced velocity models:  { uniform | glauert | mangler }
        Omega_ref_rotor,    /* formerly: om_z_ROTOR, */
        # om_z_ROTOR,
        rotor_reference_radius, # rotor_reference_radius
        # delay, const, 0., # memory factor
        # max iterations, 10,
        # tolerance, 0.3,
      output, no
  ;   # switch for individual element output

  # ============================================================================================================================






# # TOTAL JOINT
# joint: JT_blade1_TotJnt, total joint, # "JT_blade1_TotJnt"
#   NS_hub_center_ROTATING,
#     position            , reference, RF_blade1_FOUND, null,
#     position orientation, reference, RF_blade1_FOUND, eye ,
#     rotation orientation, reference, RF_blade1_FOUND, eye ,
#   NS_blade1         ,
#     position            , reference, RF_blade1_FOUND, null,
#     position orientation, reference, RF_blade1_FOUND, eye ,
#     rotation orientation, reference, RF_blade1_FOUND, eye ,
#   position    constraint, active, active, active, null,
#   orientation constraint, active, active, active, null,
#   output, no   # switch for individual element output
# ;

# joint: JT_hub_center_ROTATING_TotJnt, total joint, #
#   NS_main_bearing_ROTATING,
#     position            , reference, RF_hub_center_ROTATING, null,
#     position orientation, reference, RF_hub_center_ROTATING, eye ,
#     rotation orientation, reference, RF_hub_center_ROTATING, eye ,
#   NS_hub_center_ROTATING,
#     position            , reference, RF_hub_center_ROTATING, null,
#     position orientation, reference, RF_hub_center_ROTATING, eye ,
#     rotation orientation, reference, RF_hub_center_ROTATING, eye ,
#   position    constraint, active, active, active, null,
#   orientation constraint, active, active, active, null,
#   output, no   # switch for individual element output
# ;


# joint: JT_hub_center_ROTATING_AngVel, angular velocity, # label = JT_hub_center_ROTATING_AngVel.eval_undefined
#   NS_hub_center_ROTATING,
#   reference, RF_hub_center_ROTATING, 1, 0, 0,
# # cosine, T_Start, Pulsation_InitRampUp_RotorSpeed, RotorSpeedUp_AngularVelocity/2., half, InitialRotorSpeed_AngularVelocity,
#   string,
#  "(
#      ( (  Time <= T_InitRampUp_WindSpeed                                       ) * 0.              )
#      +
#      ( ( (Time >  T_InitRampUp_WindSpeed) && (Time <= T_InitRampUp_RotorSpeed) ) *
#        (omega_start * 0.5*(1-cos(pi*((Time-T_InitRampUp_WindSpeed)/T_InitRampUpPeriod_RotorSpeed)))) )
#      +
#      ( ( (Time <= T_RampBegin_RotorSpeed) && (Time >  T_InitRampUp_RotorSpeed) ) * omega_start     )
#      +
#      ( (  Time >  T_RampBegin_RotorSpeed                                       ) *
#        ( omega_start + (omega_stop - omega_start)*(Time-T_RampBegin_RotorSpeed)/(T_RampEnd_RotorSpeed-T_RampBegin_RotorSpeed))
#      )
#    )",
#   output, no  # no  # OUT_JT_Main_Bearing_ROTATING_AngVel  # switch for individual element output
# ;
# ##-----------------------------------------------------------------------------------------------
# # DRIVEN REVOLUTE HINGE
# #
# # Definition of the revolute hinge joint which replaces the above
# # axial rotation joint at the end of the start up phase.
# #
# joint: JT_hub_center_ROTATING_RevHin, revolute hinge,     # label = JT_hub_center_ROTATING_RevHin.eval_undefined
#   NS_hub_center_FIX,
#     reference, RF_hub_center_FIX, null,
#     hinge, reference, RF_rotor_axis, eye,
#   NS_hub_center_ROTATING,
#     reference, RF_hub_center_ROTATING, null,
#     hinge, reference, RF_rotor_axis, eye,
#   output, no  # OUT_JT_Main_Bearing_ROTATING_RevHin  # switch for individual element output
# ;
