
 rm blade2.abm
 rm blade2.abm.set
 rm blade2.fbd
 rm blade2.fbd.set
#rm blade2.inr
#rm blade2.jnt
 rm blade2.nod
 rm blade2.nod.set
 rm blade2.rbd
 rm blade2.rbd.set
#rm blade2.set


cp /cygdrive/c/mbdyn.pre/model_generator/_model/RE6M_10bm_fit_nonadaptive_k1.0/blade1/blade1.abm     ./
cp /cygdrive/c/mbdyn.pre/model_generator/_model/RE6M_10bm_fit_nonadaptive_k1.0/blade1/blade1.fbd     ./
cp /cygdrive/c/mbdyn.pre/model_generator/_model/RE6M_10bm_fit_nonadaptive_k1.0/blade1/blade1.nod     ./
cp /cygdrive/c/mbdyn.pre/model_generator/_model/RE6M_10bm_fit_nonadaptive_k1.0/blade1/blade1.rbd     ./
cp /cygdrive/c/mbdyn.pre/model_generator/_model/RE6M_10bm_fit_nonadaptive_k1.0/blade1/blade1.abm.set ./
cp /cygdrive/c/mbdyn.pre/model_generator/_model/RE6M_10bm_fit_nonadaptive_k1.0/blade1/blade1.fbd.set ./
cp /cygdrive/c/mbdyn.pre/model_generator/_model/RE6M_10bm_fit_nonadaptive_k1.0/blade1/blade1.nod.set ./
cp /cygdrive/c/mbdyn.pre/model_generator/_model/RE6M_10bm_fit_nonadaptive_k1.0/blade1/blade1.rbd.set ./
