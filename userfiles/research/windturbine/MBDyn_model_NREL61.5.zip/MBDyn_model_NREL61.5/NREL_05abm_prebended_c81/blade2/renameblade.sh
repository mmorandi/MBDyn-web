 mv blade1.abm     blade2.abm
 mv blade1.fbd     blade2.fbd
 mv blade1.abm.set blade2.abm.set
 mv blade1.fbd.set blade2.fbd.set
 mv blade1.nod.set blade2.nod.set
 mv blade1.rbd.set blade2.rbd.set

#mv blade1.abm         blade2.abm
#mv blade1.abm.set     blade2.abm.set
#mv blade1.fbd         blade2.fbd
#mv blade1.fbd.set     blade2.fbd.set
#mv blade1.inr         blade2.inr
#mv blade1.jnt         blade2.jnt
#mv blade1.nod         blade2.nod
#mv blade1.nod.set     blade2.nod.set
#mv blade1.rbd         blade2.rbd
#mv blade1.rbd.set     blade2.rbd.set
#mv blade1.set         blade2.set
