#
# Copyright  (C)  2008  Patrick Rix             <p.rix|at|online.de>
#                   and Philippe-Emmanuel Ascar <philoupointcom|at|hotmail.fr>
#
# This file can be freely used and modified to be run with MBDyn
# provided this copyright notice is not altered nor removed.
#
# THIS MODEL IS PROVIDED AS IS, WITHOUT ANY WARRANTY OF ACCURACY
# OR FITNESS FOR ANY PURPOSE.
#
# ---------------------------------------------------------------
#
# MBDyn model of a LM61.5 Rotorblade as described by  Risoe
#       dated:  22. May 2008
#
# ---------------------------------------------------------------
#
#
#   MBDyn - Model:   >>> RE61p5_1_blade_flutter_test <<<   Ver. 1.2.3


# ------------------------- #
# SIMULATION CONTROL SENSOR #
# ------------------------- #

  # TIME
  # ====
  # put the  ACTUAL SIMULATION TIME  in an abstract node
  force: FA_SimControl_time, abstract, NA_SimControl_time, abstract, time;
  genel: GE_SimControl_time,
    spring support, FA_SimControl_time, abstract, algebraic, linear elastic, 1.        # unary spring stiffness
  ;
# ------------------------------------------------------------------------------

  # TIME STEP
  # =========
  # put the  ACTUAL SIMULATION TIME STEP  in an abstract node
  force: FA_SimControl_timestep, abstract, NA_SimControl_timestep, abstract,  string, "TimeStep";
  genel: GE_SimControl_timestep,
    spring support, FA_SimControl_timestep, abstract, algebraic, linear elastic, 1.        # unary spring stiffness
  ;
# ------------------------------------------------------------------------------

  # ROTOR SPEED SENSOR IN RPM
  # =========================
  # TowerShadow_blade_angle: label == 1000
  # put the  ACTUAL SIMULATION TIME  in an abstract node
  force: FA_SimControl_rotorspeed, abstract, # 1000
      NA_SimControl_rotorspeed, abstract,
        element, JT_hub_center_ROTATING_RevHin, joint, string, "wz",
        linear, 0., rps2RPM
  ;
  genel: GE_SimControl_rotorspeed,
    spring support, FA_SimControl_rotorspeed, abstract, algebraic, linear elastic, 1.        # unary spring stiffness
  ;
# ------------------------------------------------------------------------------
