/*
 * mbdyn_bulk_buster.h
 *
 *  Created on: 07.06.2010
 *      Author: p.rix
 */

#ifndef MBDYN_BULK_BUSTER_H_
#define MBDYN_BULK_BUSTER_H_


	// =============
	//   CONSTANTS
	// =============

  const char* PRG_name    = "mbdyn_bulk_buster";

  const char* PRG_version = "1.0.1";

  //      *****************************************
  const long Dflt_NL_buff = 500000; // BUFFER SIZE = max. number of text lines read from input file
  //      *****************************************

  const long Dflt_MAX_LINE_LENGTH = 512;//;1024;//4096; // max. number of chars per line for function fgets()

  const long ALL = 2147483647;

	// MAX_LINE_LENGTH affects the performance !
	// Increasing it to infinity will make the program slow !
	// Thus we have to use senseful values which just cover the the longest lines in the input file

  long MAX_LINE_LENGTH = Dflt_MAX_LINE_LENGTH;

  long NL_buff = Dflt_NL_buff;

  int OPTION = 0;
  int OPTION_SetNLbuff = 1;	char* str_OPTION_SetNLbuff = "--set-NLbuff";	int HAVE_OPTION_SetNLbuff = 0;
  int OPTION_SkipLabel = 2;	char* str_OPTION_SkipLabel = "--skip-label";	int HAVE_OPTION_SkipLabel = 0;
  int OPTION_AddTime   = 3;	char* str_OPTION_AddTime   = "--add-time";		int HAVE_OPTION_AddTime   = 0;

  int HAVE_OPTION_NetCDF = 0;
  int HAVE_OPTION_NetCDF_1D = 0;
/*int OPTION_NetCDF_1D_float  = 11;*/	char* str_OPTION_NetCDF_1D_float  = "--netcdf-1D-float";	int HAVE_OPTION_NetCDF_1D_float  = 0;
/*int OPTION_NetCDF_1D_double = 12;*/	char* str_OPTION_NetCDF_1D_double = "--netcdf-1D-double";	int HAVE_OPTION_NetCDF_1D_double = 0;
/*int OPTION_NetCDF_2D_float  = 21;*/	char* str_OPTION_NetCDF_2D_float  = "--netcdf-2D-float";	int HAVE_OPTION_NetCDF_2D_float  = 0;
/*int OPTION_NetCDF_2D_double = 22;*/	char* str_OPTION_NetCDF_2D_double = "--netcdf-2D-double";	int HAVE_OPTION_NetCDF_2D_double = 0;
/*int OPTION_NetCDF_multivar_file = 22;*/	char* str_OPTION_NetCDF_multivar_file = "--netcdf-multivar-file";	int HAVE_OPTION_NetCDF_multivar_file = 0;


	// =============
	//   VARIABLES
	// =============

	int   E = 0;
	int   err = 0;
	int   e1=0, e2=0, e3=0, e4=0;
	long  i,j, p,L;
	long  L_MAX_LEN = 0;
  char* input_filename = NULL;  // input argument (required)
  char* input_file_extension = NULL;
	char* input_file_timeID_str = NULL;
  char* time_filename  = NULL;  // input argument (optional)
  char* output_basename = NULL; // input argument (optional)
  char* output_filename = NULL;
  char* out_dir = NULL;

  FILE*   in_FILE = NULL;
  FILE*  out_FILE = NULL;
  FILE* time_FILE = NULL;

  //TpointerStringList strList_BulkData = NULL; //
  char* *Bulk_DATA = NULL; // Bulk_DATA[iT] =  1D-array of string with the bulk time series data of ALL labels
							 //                  READ-BUFFER for input file
  char* *Time_DATA_STR = NULL; // Time_DATA[iT_time] =  1D-array of string with the time track data (for ALL labels)
							 //                  READ-BUFFER for input file
  long    NT_time = 0;  // counter for number of time steps in time track file
  long    iT_time = 0;  // time step index in time track file
  // time data arrays for NetCDF output:
//long*   iTsim_I  = NULL;      //  dTsim_I[iT_time]  =  1D-array of LONG INT with the simulaiton time step index (for ALL labels)
  int*    iTsim_I  = NULL;      //  dTsim_I[iT_time]  =  1D-array of INT with the simulaiton time step index (for ALL labels)
  float*   Tsim_X  = NULL;      //   Tsim_X[iT_time]  =  1D-array of FLOAT with the simulation time data (for ALL labels)
  float*  dTsim_X  = NULL;      //  dTsim_X[iT_time]  =  1D-array of FLOAT with the simulaiton time step width (for ALL labels)
// double*   Tsim_XX = NULL;      //   Tsim_XX[iT_time] =  1D-array of DOUBLE with the simulation time data (for ALL labels)
// double*  dTsim_XX = NULL;      //  dTsim_XX[iT_time] =  1D-array of DOUBLE with the simulaiton time step width (for ALL labels)

   double  Tsim_MIN =  FLT_MAX;
   double  Tsim_MAX = -FLT_MAX;

   double   X,Y,Z, XX;

   long hours, minutes, seconds;

   time_t  time1_TOTAL , time1_READING , time1_SORTING , time1_WRITING;
   time_t  time2_TOTAL , time2_READING , time2_SORTING , time2_WRITING;
   time_t  time12_TOTAL, time12_READING, time12_SORTING, time12_WRITING;

 //  char* time1_str = NULL;    time_t  time1;     struct tm*  tm1  = NULL;
 //  char* time2_str = NULL;    time_t  time2;     struct tm*  tm2  = NULL;
 //  char* time_diff = NULL;    time_t  time12;    struct tm*  tm12 = NULL;
   char*   START_time_str = NULL;
   char*   STOP_time_str = NULL;
   int     progress, old_progress;
   int     HAVE_PROGRAM_RESTART = 0; // bool
   int     EXECUTE_FOR_THIS_LABEL = 1; // bool
   int     FIRST_BUFF = 1; // bool
   int     SHOW_LABEL_MSG = 1; // bool
   long    buffer = 0; // counter for buffer fillings
long long    Fsize = 0;
long long    Fpos = 0;
   long    L0 = 0;
// long    NL = 0;
   long    RL = 0;
   long    MaxSize = 0;
// long    Len_strList = 0;
   long    line_T = 0; // current line index (counting from 1); indicates the current position when READING the time track input file
   long    line_I = 0; // current line index (counting from 1); indicates the current position when READING the bulk data input file
   long    line_O = 0; // current line index (counting from 1); indicates the current position when WRITING the output file
   char*   line_str = NULL;
   char*   s0 = NULL;
   char*   s1 = NULL;
   char*   s2 = NULL;
   char*   s3 = NULL;
   char*   s4 = NULL;
   char    LastCharacter;
   int     IS_IN_LABELS = 0; // bool
   long    N_Labels = 0; // counter for total number of LABELS
   long    label = 0;         // current label, (i.e. the one the current line_str)
   char*   label_str = NULL;  //
   char*   data_str = NULL;   //
   char*   time_str = NULL;   //
   char*   out_data_str = NULL;   //
   long*   Labels = NULL;     // Labels[iL]    =  1D-array of long with label IDs contained in the bulk data input file
   long*   Labels_NTbuff = NULL;  // Labels_NTbuff[iL] =  1D-array of long with counter for number of time steps per each label
   long*   Labels_NToff = NULL;  // Labels_NToff[iL] =  1D-array of long with counter for time step offset index per each label
   long*   Labels_NCols = NULL; //  Labels_NCols[iL] =  1D-array of long with the number of data columns for each label
   long*   Labels_DATA_sizeNT = NULL; // Labels_DATA[iL,jT]  = 1D-array with current data memory size, i.e. the number of time step strings
   char*** Labels_DATA_STR = NULL;// Labels_DATA_STR[iL,jT]  = 2D-array of STRING with time series data per each label
         // data arrays for NetCDF output:
  float*** Labels_DATA_X   = NULL;// Labels_DATA_X[iL,m,n] = 3D-array of FLOAT  with time series data per each label
 double*** Labels_DATA_XX  = NULL;// Labels_DATA_XX[iL,m,n]= 3D-array of DOUBLE with time series data per each label
         //   with
         // NetCDF-1D-vars:  m == kC data column index
         //                  n == jT time step index
         // NetCDF-2D-vars:  m == jT time step index
         //                  n == kC data column index
   long    iL, this_iL, zL, zL_END,
           jT, NTbuff, sizeNT, NToff, NTfile,
           k,  NCols;


   /* ----------------------------------------------------------------*/
   /*             variables for NetCDf format                         */
   /* ----------------------------------------------------------------*/

   /* Handle netCDF errors by printing an error message and exiting with a
    * non-zero status. */
   #define ERR(e) {printf("\n\n   ERROR: %s\n\n", nc_strerror(e)); return 2;}

   //int NCols = -1;
   char* NCols_str = NULL;
   char* iCol_str = NULL;

   /* IDs for the netCDF file, dimensions, and variables. */
   int nc_FILE_id = -1;

   int Ndims, Nvars, Ngatts;

   int DEFINE_NEW_DIM = 0; // bool
   long L_vecN = 0; // counter for array length
   long* vecN_DIMS_val = NULL; // vecN_DIMS_val[0..L_vecN-1] : 1D-array of int for remembering dimension values (..multivar file context)
   long* vecN_DIMS_id = NULL;  // vecN_DIMS_val[0..L_vecN-1] : 1D-array of int for remembering the ID related to a certain dimension value (..multivar file context)

   int NDIMS = -1;
   int DIM2_ids[2];

   /* the start and count arrays will tell the netCDF library where to
      write our data. */
	size_t  D1start[1], D1count[1];
	size_t  D2start[2], D2count[2];

   char* UNITS_attname       = "units";
   char* TYPE_attname        = "type";
   char* DESCRIPTION_attname = "description";

   int   dummy_DIM_id;

   int   time_DIM_id = -1,
   	     time_VAR_id = -1;
   char* time_DIM_name   = "time";
   char* time_VAR_name   = "time";
   char* time_UNITS_str  = "s";
   char* time_TYPE_str   = "float";
   char* time_DESCRIPTION_str = "simulation time";

   //int   dTsim_DIM_id = -1,
   int	 dTsim_VAR_id = -1;
   //char* dTsim_DIM_name   = "timestep";
   char* dTsim_VAR_name   = "timestep";
   char* dTsim_UNITS_str  = "s";
   char* dTsim_TYPE_str   = "float";
   char* dTsim_DESCRIPTION_str = "integration time step";

   //int   iTsim_DIM_id = -1,
   int	 iTsim_VAR_id = -1;
   //char* iTsim_DIM_name   = "timeindex";
   char* iTsim_VAR_name   = "timeindex";
   char* iTsim_UNITS_str  = "-";
   char* iTsim_TYPE_str   = "int";
   char* iTsim_DESCRIPTION_str = "time step index";

   int*  Labels_entity_DIM_id = NULL; // Labels_entity_VAR_id[iL] = 1D-array of int to hold the DIM-id for each label/entity over multiple buffer fills
   int** Labels_entity_VAR_id = NULL;
		// Labels_entity_VAR_id[iL][k] = 2D-array of int to hold variable IDs over multiple buffer fills
		// with  k == NCols  when having a 1D-variable for each data column of an entity (i.e. label)
		//  or   k == 1      when having a 2D-variable holdin all data columns of entity (i.e. label)

   int   entity_DIM_id=-1,
   	   entity_VAR_id=-1;
   char* entity_DIM_name = NULL ;
   char* entity_VAR_name = NULL ;
   char* entity_UNITS_str  = "???";
   char* entity_TYPE_str   = NULL; // "float" | "double";
   char* entity_DESCRIPTION_str = "???";

   /* ----------------------------------------------------------------*/


#endif /* MBDYN_BULK_BUSTER_H_ */
