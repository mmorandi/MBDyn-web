/*                      Copyright  (C)  2006    Patrick Rix 
 * str_utils.c
 * ===========
 * Contains utilites for string manipulation like
 * copying, inserting, deleting, splitting, etc.
 * 
 * LICENSE
 *                not yet defined
 * 
 * AUTHOR(S)
 *                Patrick Rix          e-mail: <patrick.rix@online.de>
 *
 * Modification History
 * ====================
 * Version      Date         Editor      Changes/Modifications/Improvements
 * -------------------------------------------------------------------------
 *   
 *  VERSION_STR_UTILS  -->  remember to update version number in header file
 * 
 *  0.0.0    30.June 2006    Rix         Basic Version, 1st beta release.
 * 
 */
 
#include "str_utils.h"

#include <stdio.h>    // for sprintf()
#include <stdlib.h>   // for memory allocation
#include <ctype.h>    // for tolower/toupper + character testing(isalpha(), isdigit(), etc.)
#include <string.h>   // for strlen(), strcpy(), strcat(), etc.
#include <float.h>    // for DBL_MAX, etc.
#include <limits.h>   // for INT_MAX, etc.
#include <math.h>	  // for fabs()

// static const char* module  = MODULE_STR_UTILS;
// static const char* version = VERSION_STR_UTILS;

//==============================================================================
//   !!!   IMPORTANT NOTE   !!!   IMPORTANT NOTE   !!!   IMPORTANT NOTE   !!!
//==============================================================================
//
//   INITIALIZE STRING  =  NULL   before using the str_utils - routines.
//
//   This is because when working with strings (=pointer to char) a
//   pointer variable which is not NULL can not be distinguished between
//   not yet mallocated (and thus containing junk) or pointing to a 
//   string constant.
//   BOTH SITUATIONS WILL LEAD TO   F A I L U R E   .
//
//     -->  String variable may not point to STRING CONSTANT. (e.g.:  S = "ABC";)
//     -->  String variable not mallocated but pointer value != NULL.
//    
//	 TIP:   a string var definition could look like this
//
//				char* S = NULL;   str_ini(&S);
//
//==============================================================================


////////////////////////////////////////////////////////////
// <<<  GLOBAL CONSTANTS  exported by  str_utils.c  >>>  
////////////////////////////////////////////////////////////

  const char* DQ = "\"";//34; // a  double  quote char "
  const char* SQ = "'";//39; // a (single) quote char '
  
// Choose OPERATING SYSTEM DEPENDENT STRING SETTINGS 
// by setting  STR_UTILS_TARGET_OS_???  in  str_utils.h  . 
#ifdef  STR_UTILS_TARGET_OS_WINDOWS

  const char* LF = "\r\n"; 
  const char* LF2 ="\r\n\r\n"; 
  const char* LF3 ="\r\n\r\n\r\n"; 
  const char* LF4 ="\r\n\r\n\r\n\r\n"; 
  const char* LF5 ="\r\n\r\n\r\n\r\n\r\n"; 

  const char* PathDelim  =  "\\";  // backslash !
  const char* DriveDelim =  ":";
  const char* PathSep    =  ";";

#elif   STR_UTILS_TARGET_OS_LINUX

  const char* LF = "\n"; 
  const char* LF2 ="\n\n"; 
  const char* LF3 ="\n\n\n"; 
  const char* LF4 ="\n\n\n\n"; 
  const char* LF5 ="\n\n\n\n\n"; 

  const char* PathDelim  =  "/";
  const char* DriveDelim =  "";
  const char* PathSep    =  ":";
  
#endif // ifdef  STR_UTILS_TARGET_OS_


////////////////////////////////////////////////////////////
// <<<  LOCAL CONSTANTS private to  str_utils.c  >>>  
////////////////////////////////////////////////////////////

static const char* ds_dflt  = " \t\b\r\n\f";       // set of default delimiters for getting sub-strings
static const char* numchars = "0123456789.,+-eE";  // set of allowed characters for numbers
static const char* intchars = "0123456789+-";      // set of allowed characters for integer numbers

////////////////////////////////////////////////////////////
// <<<  GLOBAL FUNCTIONS  exported by  str_utils.c  >>>  
////////////////////////////////////////////////////////////


void 
str_free (char* *s1) {
	// Frees any allocated string memory & initializes pointer to NULL.
	if( *s1 != NULL ){ 
		free(*s1);    *s1 = NULL;
	}
} // str_free()	


int
str_clear (char* *s1) {
	// basically the same as fucntion  str_ini()  :
	// String memory allocation + initialization.
	// Allocates memory for  1  character and initializes it with 0 
	// which makes s1 an empty string.
	// On failure -1 is returned and *s1 is set to NULL.
	// On success 0 is returned. 
	int E = -1; // raise ERROR flag
	E = str_ini(s1);
  	return( E );
} // str_clear()


int 
str_ini (char* *s1) {
	// String memory allocation + initialization.
	// Allocates memory for  1  character and initializes it with 0 
	// which makes s1 an empty string.
	// On failure -1 is returned and *s1 is set to NULL.
	// On success 0 is returned. 
	int E = -1; // raise ERROR flag
	E = str_Nini(s1, 0);
  	return( E );
} // str_ini()	


int
str_Nini (char* *s1, long N) {
	// String memory allocation + initialization.
	// Allocates memory for   N+1   characters and initializes 
	// characters s1[0..(N-1)]=' ' with spaces and s1[N]='\0' with 0.
	// This means s1 has enough memory to hold a string of length N plus the trailing 0. 
	// On failure -1 is returned and *s1 is set to NULL.
	// On success 0 is returned.
	
	int E; 
	long i;
	size_t  mem_size;

	E = -1; // raise ERROR flag
    
	//if( *s1 != NULL ){
	//	free(*s1);    *s1 = NULL;   // free any old memory fragments from previous contents
	//}
 
	str_free( s1 );  // free any old memory fragments from previous contents
    
	if( N >= 0 ) {	
		mem_size = (size_t)( (N+1) * sizeof(char) ); // required memory to hold n characters
		if(*s1 == NULL) { 
	  		*s1 = (char *)malloc(mem_size); // allocate memory for s1		
		}else{	
			*s1 = (char *)realloc(*s1, mem_size); 
		}	
		if( *s1 != NULL ) {
		  	
		  	for(i=0;i<N;i++) (*s1)[i] = ' '; // fill with spaces 
		
		    (*s1)[N] = '\0'; // force terminating 0
		    
		  	E = 0; // indicate SUCCESS
		}
	}	
  	return(E);
} // str_Nini()	


int
str_memtrim (char* *s1) {
	// Trims (shortens!) the memory size reserved for s1 to length of string.
	// This function saves memory when an amount of memory was
	// allocated to hold the largest possible string but the 
	// actual string in s1 is shorter. In this case the memory
	// size is fitted to the string size.
	// The content of s1 remains unchanged.
	int E; 
	long L;
	size_t  mem_size;

	E = -1; // raise ERROR flag
	
	if( *s1 != NULL ) {	
		
		L = (long)strlen(*s1);
		mem_size = (size_t)( (L+1) * sizeof(char) ); // required memory to hold L characters plus terminating 0
		
		*s1 = (char *)realloc(*s1, mem_size); 
		
		E = 0; // indicate SUCCESS
	}	
  	return(E);	
} // str_memtrim	


int 
str_is_numstr (const char* s1) {
	// Checks if string s1 only consists of numerical characters
	// returns the result.
	// 0 = FALSE if s1 contains a non-numerical character which is not in defined in numchar
 	// 1 = TRUE if s1 only contains numerical characters	
 	//-1 = UNDEFINED if s1 is empty
 		
	   int result;    
	   int   c_in_numchars;
	   long  L, Lnc, i, j; 
	   char  c;
	
	L   = str_len(s1);	
	Lnc = str_len(numchars);
	
	result = -1;   
	
  	if( L > 0  ) {  
  		result = 1;
		i = -1;  
		while( (result == 1) && (i < (L-1)) ) {
			i++;    c=s1[i]; 
			j = -1;  c_in_numchars = 0;
			while ( (c_in_numchars == 0) && (j < (Lnc-1)) ) {
				j++;	
				if(c == numchars[j]) c_in_numchars = 1;
			}
			if( c_in_numchars == 0){
				result = 0;  
			}
		}
  	}
  	return(result);
} // str_is_numstr()


int 
str_is_intstr (const char* s1) {
	// Checks if string s1 only consists of characters allowed for integer numbers
	// returns the result.
	// 0 = FALSE if s1 contains a non-numerical character which is not in defined in numchar
 	// 1 = TRUE if s1 only contains numerical characters	
 	//-1 = UNDEFINED if s1 is empty
 		
	   int result;    
	   int   c_in_intchars;
	   long  L, Lnc, i, j; 
	   char  c;
	
	L   = str_len(s1);	
	Lnc = str_len(intchars);
	
	result = -1;   
	
  	if( L > 0  ) {  
  		result = 1;
		i = -1;  
		while( (result == 1) && (i < (L-1)) ) {
			i++;    c=s1[i]; 
			j = -1;  c_in_intchars = 0;
			while ( (c_in_intchars == 0) && (j < (Lnc-1)) ) {
				j++;	
				if(c == intchars[j]) c_in_intchars = 1;
			}
			if( c_in_intchars == 0){
				result = 0;  
			}
		}
  	}
  	return(result);
} // str_is_intstr()


int 
str_cmp (const char* s1, const char* s2, int casens) {
	// Compares two strings and returns the result for listing them
	// in increasing order (ASCII).
	// The comparison can be case-sensitve (!=0) or not (==0).
	// Returns 
	//          -1  =  ERROR
	//           0  =  s1 equals s2
	//           1  =  s1 would be listed first
	//           2  =  s2 would be listed first   
	
	int result;
	
	char c1, c2;
	int c1_equals_c2;
	long L,L1,L2;
	long i;
	
	result = -1;  // raise ERROR flag
	
	L1 = str_len(s1);
	L2 = str_len(s2);
	
	if( (L1 > 0) && (L1 > 0) ) {
		L = L1;
		if( L2 > L1 ) L = L2;
		i = -1;   c1_equals_c2 = 1;
		while( c1_equals_c2 && (i < L) ) {
			i++;  
			c1 = s1[i];    c2 = s2[i];
			if( !casens ) {
				c1 = tolower(c1);
				c2 = tolower(c2);
			}	 
			if( c1 != c2) c1_equals_c2 = 0;
		}
			
		if( c1_equals_c2 ) { // the strings are equal up to length L
			if(L1 == L2) { // when s1 has the same length as s2 then..
				result = 0; // STRINGS ARE EQUAL !
			}else{				
				// this means the shorter of s1 or s2 wins.
				if( L1 < L2 ) {
					result = 1; 
				}else{	
					result = 2; 
				}
			}		
		}else{ // a difference was found in the first L characters..
			if( c1 < c2) { // this means the lower ASCII number wins.
				result = 1;
			}else{
				result = 2;
			}		
		}	 
	}
		
	return(result);
} // str_cmp()	


long
str_len (const char* s1) {
	long L = -1;
	if(s1!=NULL) L = (long)strlen(s1);  // from <string.h>
	return(L);
} // str_len


long 
str_pos (const char* s1, const char* s2, int reverse, int casens) {
	// Searches for the 1st occurrence of pattern string s2 in string s1 and
	// returns the position index p or -1 if the pattern s2 is not contained in s1. 
	// The search starts either from
	//   left  (reverse == 0) 
	//     or
	//   right (reverse != 0). 
	//
	// NOTE: INDEX p ALWAYS COUNTS FROM   L E F T   STARTING WITH 0 !!
	
 	   long position;
	   long  L1, L2, i, j; 
	   int  e1 = 0; 
	   int  e2 = 0;
	   char* s  = NULL;
	   char* ss = NULL;
	   char* pos= NULL;
	
	position = -1;
	
	L1 = str_len(s1); 
	L2 = str_len(s2);
	
  	if( (L1 > 0) && (L2 > 0) && (L2 <= L1) ) {  
  		if( reverse ) { // searching s2 in s1 starting from the end of s1
  			str_copy(&s , s1, &e1); // copy s1 into help var s
  			if(e1==0) {
	  			for(i=0;i<=(L1-1);i++) {
	  				j = L1-1 - i;
	  				s[i] = s1[j];  // revert s1 into s
	  			}
  			}	
  			str_copy(&ss , s2, &e2); // copy s2 into help var ss
  			if(e2==0) {
	  			for(i=0;i<=(L2-1);i++) {
	  				j = L2-1 - i;
	  				ss[i] = s2[j];  // revert s2 into ss
	  			}
  			}	
  			
  			if( (e1) || (e2) ) { // exit function if error detected
  				return(position);
  			}	
  			
  			//now search for 1st occurrence of reverted s2 in reverted s1	
			if ( casens ) {
				pos = strstr(s, ss); // from <string.h>
			}else{
				str_tolowerStr(&s,  &e1);      
				str_tolowerStr(&ss, &e2); 
	  			if( (e1) || (e2) ) { // exit function if error detected
	  				return(position);
	  			}	
	  			// get position pointer of ss in s 
				pos = strstr( s, ss ); // from <string.h> 
			}	
  			// get index p from pointer pos
  			if( pos == NULL) {
  				position = -1;
  			}else{	
  				position = (long)(pos - s);
  				position = (L1-1)-(position)-(L2-1);
  			}
			if(s)free(s);    if(ss)free(ss);         			 
  		}else{
			str_copy(&s ,  s1, &e1);  // copy s1 into help var s
			str_copy(&ss , s2, &e2); // copy s2 into help var ss
  			if( (e1) || (e2) ) { // exit function if error detected
  				return(position);
  			}

			if ( casens ) {
				//pos = strstr(s1, s2); // from <string.h>
			}else{
				/*
				 * str_copy(&s ,  s1, &e1);  // copy s1 into help var s
  			     * str_copy(&ss , s2, &e2); // copy s2 into help var ss
	  			 * if( (e1) || (e2) ) { // exit function if error detected
	  			 * 	return(position);
	  			 * }
	  			 */
				str_tolowerStr(&s, &e1);
				str_tolowerStr(&ss, &e2);
	  			if( (e1) || (e2) ) { // exit function if error detected
	  				return(position);
	  			}	
	  			// get position pointer of ss in s 
				//pos = strstr( s, ss );  // from <string.h>
			}

			pos = strstr( s, ss );  // from <string.h>
  			// get index p from pointer pos
  			if( pos == NULL) {
  				position = -1;
  			}else{	
  				position = (long)(pos - s);
  			}
			if(s)free(s);    if(ss)free(ss);         			 
  		}
  	}
  	
  	return(position);
} // str_pos()	

long 
str_posnext (long p0, const char* s1, const char* s2, int reverse, int casens) {
	// Searches for the next occurrence of pattern string s2 in string s1 starting from position p0.
	// Returns the position index p or -1 if the pattern s2 is not contained in s1. 
	// The search starts either from
	//   left  (reverse == 0) 
	//     or
	//   right (reverse != 0). 
	//
	// NOTE: INDEX p ALWAYS COUNTS FROM   L E F T   STARTING WITH 0 !!
	
	   long position;
	   long  L1, L2; 
	   int  e1 = 0; 
	   char* s0 = NULL;
	
	position = -1;	
	
	L1 = str_len(s1);
	L2 = str_len(s2);
	
  	if( (L1 > 0) && (L2 > 0) && (L2 <= L1) && (0 <= p0) && (p0 <= (L1-1)) ) {  
  		if(reverse){
  			str_Ncopy(&s0 , s1, 0, p0+1, &e1);
  		}else{
  			str_Ncopy(&s0 , s1, p0, L1-p0, &e1);
  		}	
  		
  		if( e1==0 ) {
  			
	  		position = str_pos(s0, s2, reverse, casens);
	  		
	  		if(s0) free(s0);
	  		
	  		if( position >= 0 ) {
	  			if( reverse ){
	  				// position has correct index -> no correction required
	  			}else{	
	  				position = position + p0;
	  			}	
	  		}	
  		}	
  	}
  	
  	return(position);
} // str_posnext()	


long
str_copy (char* *s1, const char* s2, int *E) {
	// Copies string s2 into s1 and returns string s1 and forces the terminating 0.
	// On Failure an empty string is returned in s1.
	//   s1 = OUTPUT, RESULT
	//   s2 = INPUT
	// Returns the number of copied characters (= length of s2)
	size_t  L, mem_size;

	*E = -1; // raise error flag
	
	if(*s1 != NULL){
		L = strlen(*s1);
		str_free(s1); // frees memory and sets  *s1 == NULL
	}

	L = 0; // not -1 !!!
	if(s2!=NULL)L = strlen(s2);  // strlen from <string.h> !!!
	
	mem_size = (size_t)( (L + 1) * sizeof(char) ); // required memory to hold a copy of s2 incl. terminating 0
	if(*s1 == NULL) { 
  		*s1 = (char *)malloc(mem_size); // allocate memory for s1		
	}else{	
		*s1 = (char *)realloc(*s1, mem_size); 
	}	
	if( *s1 != NULL ) {
	  	if( L > 0) strcpy(*s1,s2);	// from <string.h>
	  	
	  	(*s1)[L] = 0; // force terminating 0 
	
	  	*E = 0; // indicate SUCCESS
	}
  	return(L);
} // str_copy()	


char*
str_cpy (const char* s) {
	// Copies string s into ss and returns string ss (incl. terminating 0).
	//   s  = INPUT
	//   ss = OUTPUT, RESULT
	// Returns on success a copy of string s or
	//         on failure a NULL pointer. 
	int E;	
    char* ss = NULL;
     
    str_copy( &ss , s, &E );    if(E)return(NULL);    
  	return(ss);
} // str_cpy()	


long
str_Ncopy (char* *s1, const char* s2, long p, long n, int *E) {
	// Copies n characters from s2 starting at position p into s1 and adds the terminating 0.
	// On Failure an empty string is returned in s1.
	//   s1 = OUTPUT, RESULT
	//   s2 = INPUT
	// Returns the number of actually copied characters.
	
	size_t  mem_size;
	   long  L;
	   long  i, err;

    
	*E = -1; // raise ERROR flag
	
	err = 0;
  //err = str_ini(s1);
	if(*s1 != NULL){
		L = strlen(*s1);
		str_free(s1); // frees memory and sets  *s1 == NULL
	}

    if( !err ) {
	 
		 L = str_len(s2);  
		 
	    // check if position index p is in range
	  	if( (p < 0) || (p > (L-1)) ) { 
	  		*E = -1;  // if not -> raise ERROR flag 
	  		 n = 0;   // no characters will be copied  		
	  	}else{	// 0 <= p <= (L-1)  is o.k.
	  	    // if n is negative..	
		  	if( n < 0 ) { // this means copy n characters from the left of p
		  	  p = p + n + 1; //..swap position index, that p is on the left,
		  	  n = -n; //..make n positive
		  	  if( p < 0 ) { //..eventually correct p and n if range is exceeded to the left
		  	  	n = n + p;
		  	  	p = 0;
		  	  }	
		  	}
	  		// check that range is not exceeded to the right
			if( (p+n-1) > (L-1) ) { n = L-p; };
			
			if( n > 0 ) { //enter, if there is something to copy
				mem_size = (size_t) (n + 1); // required memory to hold a copy of s2 
				if(*s1 == NULL) { 
			  		*s1 = (char *)malloc(mem_size); // allocate memory for s1		
				}else{	
					*s1 = (char *)realloc(*s1, mem_size); 
				}
				if( *s1 != NULL) {
					// now copy character-wise	
				  	for(i=0;i<n;i++) {
				  		(*s1)[i] = s2[p+i];
				  	}	
				  	(*s1)[n] = 0; // force terminating 0 
				  			  	
				  	*E = 0; // indicate SUCCESS
				}		  	
			  	//printf(" s1 = <%s>", *s1);
			}
	  	}  	
    }else{
    	*E = -1; // raise ERROR flag
    	n = 0;
    }	  
    	
  	return(n); // return number of actually copied characters
} // str_Ncopy()	

char*
str_Ncpy (const char* s, long p, long n) {
	// Copies n characters from s starting at position p into ss and adds the terminating 0.
	//   s  = INPUT
	//   ss = OUTPUT, RESULT
	// Returns on succuess a copy of the sub-string of s or
	//         on failure a NULL pointer. 
	int E;
    char* ss = NULL;
          
    str_Ncopy( &ss , s, p, n, &E );    if(E)return(NULL);    
  	return(ss);
} // str_Ncpy()	


int
str_getnextStrL (char* *s1, char* *s2, int *E) {
	// Gets the next sub-string FROM LEFT from a sample-string  s2  which is
	// delimited by any white SPACE characters defined in ds_dflt.
	//   s1 = OUTPUT, RESULT sub-str
	//   s2 = INPUT sample-str
	// Returns 0 on success and -1 on failure.
	 str_getnextSubStr (s1, s2, ds_dflt, 0, 0, E); 
	 return(*E);
} // str_getnextStrL()	

char*
str_getnextL (char* *s) {
	// Gets the next sub-string FROM LEFT from a sample-string  s  which is
	// delimited by any white SPACE characters defined in ds_dflt.
	//   s  = INPUT sample-str, on ouput s contains the rest with sL being removed from it.
	//   sL = OUTPUT, RESULT sub-str
	// Returns on succuess sL as result string or
	//         on failure a NULL pointer.
 	 int E;
     char* sL = NULL;
	 str_getnextStrL (&sL, s, &E);    if(E)return(NULL);     
	 return(sL);
} // str_getnextL()	

int
str_getnextStrR (char* *s1, char* *s2, int *E) {		
	// Gets the next sub-string FROM RIGHT from a sample-string  s1  which is
	// delimited by any white SPACE characters defined in ds_dflt.
	//   s1 = INPUT sample-str
	//   s2 = OUTPUT, RESULT sub-str
	// Returns 0 on success and -1 on failure.
	 str_getnextSubStr (s1, s2, ds_dflt, 1, 0, E);
	 return(*E);
} // str_getnextStrR()	

char*
str_getnextR (char* *s) {		
	// Gets the next sub-string FROM RIGHT from a sample-string  s  which is
	// delimited by any white SPACE characters defined in ds_dflt.
	//   s  = INPUT sample-str, on ouput s contains the rest with sR being removed from it.
	//   sR = OUTPUT, RESULT sub-str
	// Returns on sucess  ! s2 !  as result string or
	//         on failue a NULL pointer.
 	 int E;
     char* sR = NULL;
	 str_getnextStrR (s, &sR, &E);    if(E)return(NULL);     
	 return(sR);
} // str_getnextR()	

int
str_getnextStrCL (char* *s1, char* *s2, const char* cs, int *E) {
	// Gets the next sub-string FROM LEFT from a sample-string  s2  which is
	// delimited by any character defined in cs.
	//   s1 = OUTPUT, RESULT sub-str
	//   s2 = INPUT sample-str
	// Returns 0 on success and -1 on failure.
	 str_getnextSubStr (s1, s2, cs, 0, 0, E); 
	 return(*E);
} // str_getnextStrCL()	

char*
str_getnextCL (char* *s, const char* cs) {
	// Gets the next sub-string FROM LEFT from a sample-string  s  which is
	// delimited by any character defined in cs.
	//   s  = INPUT sample-str, on ouput s contains the rest with sL being removed from it.
	//   sL = OUTPUT, RESULT sub-str
	// Returns on success  sL  as result string or
	//         on failure a NULL pointer. 
 	 int E;
     char* sL = NULL;
	 str_getnextStrCL (&sL, s, cs, &E);    if(E)return(NULL);      
	 return(sL);
} // str_getnextCL()	

int
str_getnextStrCR (char* *s1, char* *s2, const char* cs, int *E) {		
	// Gets the next sub-string FROM RIGHT from a sample-string  s1  which is
	// delimited by any character defined in cs.
	//   s1 = INPUT sample-str
	//   s2 = OUTPUT, RESULT sub-str
	// Returns 0 on success and -1 on failure.
	 str_getnextSubStr (s1, s2, cs, 1, 0, E); 
	 return(*E);
} // str_getnextStrCR()	

char*
str_getnextCR (char* *s, const char* cs) {		
	// Gets the next sub-string FROM RIGHT from a sample-string  s  which is
	// delimited by any character defined in cs.
	//   s  = INPUT sample-str, on ouput s contains the rest with sR being removed from it.	
	//   sR = OUTPUT, RESULT sub-str
	// Returns on success  ! sR !  as result string or
	//         on failure a NULL pointer.
 	 int E;
     char* sR = NULL;
	 str_getnextStrCR (s, &sR, cs, &E);    if(E)return(NULL);      
	 return(sR);
} // str_getnextCR()	


int
str_getnextSubStr (char* *s1, char* *s2, const char* cs, int reverse, int casens, int *E) {
	// Gets the next sub-string (from left or right) from a sample-string which is delimited by 
	// any of the characters in the string cs.
	// The sub-string and the delimiting character(s) are deleted from the original sample-string.
	// Results are the sub-string and the remaining rest of the cut sample-string.
	// The sub-string can be split either from
	//   LEFT  (reverse == 0) and returns  s1 = result sub-string  , s2 = trimmed sample-string 
	// or
	//   RIGHT (reverse != 0) and returns  s2 = result sub-string  , s1 = trimmed sample-string 
	// If the sample-string is empty or a NULL pointer then an empty string is returned as result
	// for the sub-string.
	//
	//   NOTE THE CHANGING POSITION OF THE ORIGINAL SAMPLE-STRING
	//   AND THE RESULT SUB-STRING DEPENDING ON THE REVERSE-SWITCH
	//
	// Returns 0 on SUCCESS and -1 on FAILURE.
	// 
	// USAGE:
	//           str_getnextsubstr( &s1 , &s2, cs, reverse, casens,   &E);   
	

		long  L, Lcs; 
		int  e0 = 0; 
		int  e1 = 0; 
		int  e2 = 0;
		char* s0 = NULL;

	*E = 0;  // indicate SUCCESS
	
	Lcs = str_len(cs);  
	
	if( reverse ) { // remove leading + trailing delimiting chars from sample-string
		str_trimStrC(s1, cs, &e1);
		L = str_len(*s1);  
		e2 = str_ini(s2);
	}else{
		str_trimStrC(s2, cs, &e1);
		L = str_len(*s2);  
		e2 = str_ini(s1);
	}
	
	if( (L < 0) || (Lcs < 0) || (e1)  || (e2) ) {
		*E = -1;  // raise ERROR flag
	}	
	
  	if( (L > 0) && (Lcs > 0) && (!*E) ) {  
		if( reverse ) {
  			str_splitC(s1, s2, cs, reverse, casens, &e1);  // split strings..
			L = str_len(*s2);    			
  			if( (L == 0) && (!e1) ) { // s2 is empty if s1 contains just one string 
  				str_copy(s2, *s1, &e1);
  				str_ini(s1);
  			}	
		}else{ // not reverse --> from left
			str_copy(&s0 , *s2, &e0);
			if(!e0) {
	  			str_splitC(&s0, s2, cs, reverse, casens, &e1);  // split strings..			
	  			str_copy(s1, s0, &e0);
			}	
  			if(s0) free(s0);   s0 = NULL;
		}
  			
  		if( reverse ) {  //..and remove delimiters from rest of sample-string
  			if(*s1 != NULL) {
  				L = str_len(*s1);
  				if( L > 0) {
					str_trimStrC(s1, cs, &e2); 
  				}	
  			}	
  		}else{
  			if(*s2 != NULL) {
  				L = str_len(*s2);
  				if( L > 0) {
					str_trimStrC(s2, cs, &e2); 
  				}	
  			}	
  		}		
	  	
        if( (e0) || (e1) || (e2) ) {
           	*E = -1; // raise ERROR flag
        }	
   	}	
   	
	return(*E); 
} // str_getnextSubStr()	


void
str_splitP (char* *s1, char* *s2, long p, int *E) {
	// Splits s1 at position p into two strings
	//   s1=s1[0..(p-1)] , s2=s1[p..(L-1)]	
	// If the splitting fails s1 is left unmodified
	// and an empty string is returned in s2.
	   long  L; 
	   int  e1 = 0; 
	   int  e2 = 0;


	*E = -1;  // raise ERROR flag
	
	e2 = str_ini(s2);
	if( e2 ) return; // EXIT on error 
	
	 L = str_len(*s1);  
	 
    // check if position index p is in range;  
  	if( (p < 0) || (p > (L-1)) ) {  
  		*E = -1;  // if not -> raise error flag 
  	}else{	// 0 <= p <= (L-1)  is o.k.
	  	if( p == 0 ) { 
	  		 str_copy(s2, *s1, &e1); // transfer s1 completely to s2
			 e2 = str_ini(s1); // and set s1 empty
             if( (e1==0) && (e2==0) ) {
             	*E = 0; // indicate SUCCESS						
             }	
			return; 			
	  	}
	  	
		str_Ncopy(s2, *s1, p, L-p, &e1);
		str_delete(s1, p, L-p, &e2);		
        if( (e1==0) && (e2==0) ) {
           	*E = 0; // indicate SUCCESS						
        }	
  	}	
	return; 
} // str_splitP()	


void
str_splitC (char* *s1, char* *s2, const char* cs, int reverse, int casens, int *E) {
	// Splits s1 at the first occurrence of a character of string cs in s1.
	// The search starts either from
	//   LEFT  (reverse == 0) and returns  s1=s1[0..(p-1)] , s2=s1[p..(L-1)] 
	//  or
	//   RIGHT (reverse != 0) and returns  s1=s1[0..p]     , s2=s1[(p+1)..(L-1)]
	//
	// If the splitting fails s1 is left unmodified
	// and an empty string is returned in s2.
		

	   long  L, Lcs, i,i0,i1,i2, j, p, n; 
	   int  found = 0; 
	   int  end = 0; 
	   int  e1 = 0; 
	   int  e2 = 0;

	
	*E = -1;  // raise ERROR flag

	e2 = str_ini(s2);
	if( e2 ) return; // EXIT on error 
	
	 L   = str_len(*s1);  
	 Lcs = str_len(cs);  
	 
    // check if position index p is in range;  
  	if( (L > 0) && (Lcs > 0) ) {  
  		if( reverse ) { 
  			i0 = -1;   i1 = L-1;   i2 = 0;
  		}else{
  			i0 = +1;   i1 = 0;   i2 = L-1;  			
  		}		
  		i = i1-i0;   found = 0;   end = 0;
  		do {
  			i = i + i0;
  			j = -1;  
  			while ( !found && (j<(Lcs-1)) ) {
  				j++;  
  				if ( casens ) {
  					if ( (*s1)[i] == cs[j] ) found = 1;  				
  				}else{
  					if ( tolower((*s1)[i]) == tolower(cs[j]) ) found = 1;  				
  				}	
  			};	
  			if ( i == i2 ) end = 1;
  		} while ( !found && !end);	
  		
  		if( !found ) {
  		  // if no character of cs was found in s1, then	
  		  // return original string s1 and s2==NULL
  		  // leave e1,e2 unchanged:  e1,e2 == 0
  		  //       
  		}else{
		  	if( reverse ) { 
		  		p = i+1;   n = L-p;
		  		if ( p <= (L-1) ) {		  			
			  		str_Ncopy(s2, *s1, p, n, &e1); 
					str_delete(s1, p, n, &e2); 
		  		}
		  	}else{
		  		p = i;   n = L-p;
		  		str_Ncopy(s2, *s1, p, n, &e1); 
				str_delete(s1, p, n, &e2); 
		  	}
  		}		 
	  	
        if( (e1==0) && (e2==0) ) {
           	*E = 0; // indicate SUCCESS						
        }	
  	}	
	return; 
} // str_splitC()	


void
str_splitS (char* *s1, char* *s2, const char* s3, int reverse, int casens, int *E) {
	// Splits s1 at the first occurrence of the pattern string s3 in string s1.
	// Returns 
	//   in s1 the left part of the original string s1 WITHOUT the pattern s3
	//     and 
	//   in s2 the right part of the original string INCLUDING the pattern s3.
	// The search starts either from
	//   LEFT  (reverse == 0) 
	//     or
	//   RIGHT (reverse != 0). 
	// 
	// If the splitting fails s1 is left unmodified
	// and an empty string is returned in s2.
	
	   long  L1, L3, p, n; 
	   int  e1 = 0; 
	   int  e2 = 0;
	

	*E = -1;  // raise ERROR flag

	e2 = str_ini(s2);
	if( e2 ) return; // EXIT on error 
	
	 L1 = str_len(*s1);  
	 L3 = str_len(s3);  
	 
  	if( (L1 > 0) && (L3 > 0) && (L3 <= L1)) {  

  		p = str_pos(*s1, s3, reverse, casens);
  				  		
  		if( p > 0 ) {
	  		n = L1-p;
	  		str_Ncopy(s2, *s1, p, n, &e1); 
			str_delete(s1, p, n, &e2); 
  		}		 
	  	
        if( (e1==0) && (e2==0) ) {
           	*E = 0; // indicate SUCCESS						
        }	
  	}	
	return; 
} // str_splitS()	


long 
str_replaceStr (char* *s1, long N, const char* s2, const char* s3, int reverse, int casens, int *E) {
	// Replaces in string s1 the first N occurrences of pattern string s2 with replacement string s3 and
	// returns the actual number of replacements and the modified string s1.
	// The search starts either from
	//   LEFT  (reverse == 0) 
	//     or
	//   RIGHT (reverse != 0). 
	// 
	
	   long  L1, L2, L3, R, p, p0; 
	   int  e1 = 0; 
	   int  e2 = 0;
	
	*E = -1;  // raise ERROR flag
	
	 L1 = str_len(*s1);  
	 L2 = str_len(s2);  
	 L3 = str_len(s3);  
	
	if( reverse ) {
		p0 = L1-1;
	}else{
		p0 = 0;
	}	
	
	R = -1; 	 
  	if( (L1 > 0) && (L2 > 0) && (L2 <= L1) ) {  
  		R = 0;   p = 1;
        while( (p >= 0) && (R < N) && (!e1) && (!e2) ) {
        	
	  		p = str_posnext(p0, *s1, s2, reverse, casens);
	  				  		
	  		if( p >= 0 ) {
	  			R++;
				str_delete(s1, p, L2, &e1); 
				str_insert(s1, s3, p, &e2); 
				if( reverse ) {
 					p0 = p - 1;
				}else{
					p0 = p + L3;
				}		
	  		}		 
        }
        
	    if( (e1==0) && (e2==0) ) {
	       	*E = 0; // indicate SUCCESS						
	    }	
  	}	

	return(R); 
	  	
} // str_replaceStr()	


char* 
str_repl (char* *s1, long N, const char* s2, const char* s3, int reverse, int casens) {
	// Replaces in string s1 the first N occurrences of pattern string s2 with replacement string s3 and
	// returns on success the modified string s1.
	//         on failure a NULL pointer.
	// The search starts either from
	//   LEFT  (reverse == 0) 
	//     or
	//   RIGHT (reverse != 0). 
	//
	int E;
	str_replaceStr ( s1, N, s2, s3, reverse, casens, &E );    if(E)return(NULL);
	return(*s1);
} // str_repl()


void
str_delete (char* *s1, long p, long n, int *E) {
	// Deletes n characters from s1 starting at position p .
	
	   long  L; 
	   int  e0 = 0; 
	   int  e1 = 0; 
	   int  e2 = 0;
	   int  e3 = 0;
	 char*  s0 = NULL;   
	 char*  s2 = NULL;   

	*E = -1;  // raise ERROR flag
	
	 L = str_len(*s1);  
	 
    // check if position index p is in range
  	if( (p < 0) || (p > (L-1)) ) { 
  		*E = -1;  // if not -> raise ERROR flag 
  	}else{	// 0 <= p <= (L-1)  is o.k.
  		
  		if( n == 0) {
  			// nothing to delete --> leave s1 unchanged and
  			*E = 0;  // indicate SUCCESS  			
  		}else{	
  			// now something is to be deleted..
  			
	  		// if n is negative..
		  	if( n < 0 ) { // delete from the left of p
		  	  p = p + n + 1; //..swap position index, that p is on the left
		  	  n = -n; //..make n positive
		  	  if( p < 0 ) { //..eventually correct p and n if range is exceeded to the left
		  	  	n = n + p;
		  	  	p = 0;
		  	  }	
		  	}
	  		
	  		if( p == 0 ) { // if the complete left part is to be deleted
				str_Ncopy(&s2, *s1, p+n, L-(p+n), &e2); //..return the right part
				str_copy(s1, s2, &e1);
				if(s2) free(s2);    s2 = NULL;
				if( (e1==0) && (e2==0) ) {
		           	*E = 0; // indicate SUCCESS						
		        }		        
				return; 
	  		}	
	  		
			if( (p+n-1) >= (L-1) ) { // if the complete right part is to be deleted
				str_Ncopy(&s2, *s1, 0, p, &e2); //..return the left part
				str_copy(s1, s2, &e1);
				if(s2) free(s2);    s2 = NULL;
				if( (e1==0) && (e2==0) ) {
		           	*E = 0; // indicate SUCCESS						
		        }	
				return; 
			}
			
			if( n > 0 ) { //enter, if there is something to delete
				str_Ncopy(&s2, *s1, p+n, L-(p+n), &e1);
				str_copy(&s0, *s1, &e0);
				str_Ncopy( s1, s0, 0, p, &e2);
				str_catenate( s1, s2, &e3);
				if(s0) free(s0);    s0 = NULL;			
				if(s2) free(s2);    s2 = NULL;			
				if( (e0==0) && (e1==0) && (e2==0) && (e3==0) ) {
		           	*E = 0; // indicate SUCCESS						
		        }	
			  	//printf(" s1 = <%s>", *s1);
			}
  		}
  	}  	
  	return;
} // str_delete()	


char*
str_del (char* *s1, long p, long n) {
	// Deletes n characters from s1 starting at position p and
	// returns on success the modified string or
	//         on failure a NULL pointer.
	int E;
	str_delete ( s1, p, n, &E );    if(E)return(NULL);
	return(*s1);	
} // str_del()	
  
  
void
str_insert (char* *s1, const char* s2, long p, int *E) {
	// Inserts s2 into s1 at position p moving
	// the part s1[p..(L-1)] to the right.
	
	   long  L; 
	   int  e1 = 0; 
	   int  e2 = 0;
	   int  e3 = 0;
	   int  e4 = 0;
	 char*  s0 = NULL;   

	*E = -1;  // raise ERROR flag

	 L = str_len(*s1);  
	 
    // check if position index p is in range;  p = L is here acceptable --> append s2 to s1
  	if( (p < 0) || (p > L) ) {  
  		*E = -1;  // if not -> raise ERROR flag 
  	}else{	// 0 <= p <= (L-1)  is o.k.
	  	if( p == 0 ) { 
	  		str_copy(&s0,  s2, &e1);
			str_catenate(&s0, *s1, &e2);  //s2 is const! s1=str_cat(s2,s1) doesn't work !
			str_copy( s1,  s0, &e3);
			if(s0) free(s0);    s0 = NULL;
			if( (e1==0) && (e2==0) && (e3==0) ) {
	           	*E = 0; // indicate SUCCESS						
	        }	
			return; 			
	  	}
	  	
	  	if( p == L ) {	
			str_catenate(s1, s2, &e1);
			if( e1==0 ) {
	           	*E = 0; // indicate SUCCESS						
	        }	
			return; 
	  	}
  		
		str_Ncopy(&s0, *s1, p, L-p, &e1);
		str_delete( s1, p, L-p, &e2);
		str_catenate( s1, s2, &e3);
		str_catenate( s1, s0, &e4);
		if(s0) free(s0);    s0 = NULL;
		if( (e1==0) && (e2==0)  && (e3==0) && (e4==0)) {
           	*E = 0; // indicate SUCCESS						
        }	
	  	//printf(" s1 = <%s>", *s1);
		
  	}  	
  	return;
} // str_insert()	


char*
str_ins (char* *s1, const char* s2, long p) {
	// Inserts s2 into s1 at position p moving
	// the part s1[p..(L-1)] to the right and
	// returns on success the resulting string or
	//         on failure a NULL pointer;
	int E;
	str_insert ( s1, s2, p, &E );    if(E)return(NULL);
	return(*s1);	
} // str_ins()	
	

void
str_catenate (char* *s1, const char *s2, int *E) {
	// Appends s2 to s1 and forces a trailing 0 by use of strcat() and
	// returns the string s1+s2.
	
    long  L1, L2; 
    //char* S;
	size_t mem_size;

	*E = -1;  // raise ERROR flag
	
	if( *s1 == NULL ) {
		str_ini( s1 );  
	}
				
	L1 = str_len(*s1);	
	L2 = str_len(s2);	
	
	if( ( L1 >= 0) && (L2 > 0) ) {
		mem_size =(size_t)( (L1 + L2 + 1) * sizeof(char) ); // required memory to hold a copy of s1+s2 
		
		if(*s1 == NULL) { // 
	  		*s1 = (char *)malloc(mem_size); // allocate memory for s1		
		}else{	
			*s1 = (char *)realloc(*s1,mem_size); // or resize s1 if s1 was already mallocated
		}	
		if( *s1 != NULL ) {
			strcat(*s1,s2); // from <string.h>
			(*s1)[L1+L2] = 0; // force trailing 0
			 //S = *s1; // for debugging purpose
			*E = 0; // indicate SUCCESS								
		}
			
	}	
  	return;
} // str_catenate()	


char*
str_cat (const char* s1, const char *s2) {
	// Appends s2 to s1 and forces (incl. trailing 0) and
	// returns on success the string s1+s2 or
	//         on failure a NULL pointer.
	int E;
	char* s = NULL;	
	str_catenate3 (&s, s1, s2, &E);    if(E)return(NULL);
	return(s);
} // str_cat()


void
str_catenate3 (char* *s1, const char* s2 , const char* s3, int *E) {
	// Appends s2 and s3 to s1 and 
	// returns the string s1+s2+s3.
	
   int  e1 = 0; 
   int  e2 = 0;
  *E = -1;  // raise error flag
  str_catenate(s1, s2, &e1);
  str_catenate(s1, s3, &e2);  
  if( (e1==0) && (e2==0) ) {
  	 *E = 0; // indicate SUCCESS								
  }	
  return;	
}	


char*
str_cat3 (const char* s1, const char* s2 , const char* s3) {
	// Appends s2 and s3 to s1 and 
	// returns on success the string s1+s2+s3 or
	//         on failure a NULL pointer.
	int E;
	char* s = NULL;	
	str_catenate4 (&s, s1, s2, s3, &E);    if(E)return(NULL);
	return(s);	
}
	
	
void
str_catenate4 (char* *s1, const char* s2 , const char* s3 , const char* s4, int *E) {
	// Appends s2..s4 to s1 and 
	// returns the string s1+s2+..+s4.
   int  e1 = 0; 
   int  e2 = 0;
  *E = -1;  // raise error flag
  str_catenate3(s1,s2,s3, &e1);
  str_catenate(s1,s4, &e2);  
  if( (e1==0) && (e2==0) ) {
  	 *E = 0; // indicate SUCCESS								
  }	
  return;	
}	


char*
str_cat4 (const char* s1, const char* s2 , const char* s3 , const char* s4) {
	// Appends s2..s4 to s1 and 
	// returns on success the string s1+s2+..+s4 or
	//         on failure a NULL pointer.
	int E;
	char* s = NULL;	
	str_catenate5 (&s, s1, s2, s3, s4, &E);    if(E)return(NULL);
	return(s);
}


void
str_catenate5 (char* *s1, const char* s2 , const char* s3 , const char* s4 , const char* s5, int *E) {
	// Appends s2..s5 to s1 and 
	// returns the string s1+s2+..+s5.
   int  e1 = 0; 
   int  e2 = 0;
  *E = -1;  // raise error flag
  str_catenate3(s1,s2,s3, &e1);
  str_catenate3(s1,s4,s5, &e2);  
  if( (e1==0) && (e2==0) ) {
  	 *E = 0; // indicate SUCCESS								
  }	
  return;	
}


char*
str_cat5 (const char* s1, const char* s2 , const char* s3 , const char* s4 , const char* s5) {
	// Appends s2..s5 to s1 and 
	// returns on success the string s1+s2+..+s5.
	//         on failure a NULL pointer.
	int E;
	char* s = NULL;	
	str_catenate5 (&s, s1, s2, s3, s4, &E);    if(E)return(NULL);
	str_catenate  (&s, s5, &E);    if(E)return(NULL);
	return(s);
}


void
str_catenate10 (char* *s1, const char* s2 , const char* s3 , const char* s4 , const char* s5, 
      const char* s6, const char* s7 , const char* s8 , const char* s9 , const char* s10, int *E) {
	// Appends s2..s10 to s1 and 
	// returns the string s1+s2+..+s10.
   int  e1 = 0; 
   int  e2 = 0;
   int  e3 = 0;
  *E = -1;  // raise error flag
  str_catenate5(s1,s2,s3,s4,s5, &e1);
  str_catenate5(s1,s6,s7,s8,s9, &e2);  
  str_catenate(s1,s10, &e3);  
  if( (e1==0) && (e2==0) && (e3==0) ) {
  	 *E = 0; // indicate SUCCESS								
  }	
  return;	
}


char*
str_cat10 (const char* s1, const char* s2 , const char* s3 , const char* s4 , const char* s5, 
           const char* s6, const char* s7 , const char* s8 , const char* s9 , const char* s10) {
	// Appends s2..s10 to s1 and 
	// returns on success the string s1+s2+..+s10 or
	//         on failure a NULL pointer.
	int E;
	char* s = NULL;	
	str_catenate10 (&s, s1, s2, s3, s4, s5, s6, s7, s8, s9, &E);    if(E)return(NULL);
	str_catenate   (&s, s10, &E);    if(E)return(NULL);
	return(s);	
}


void
str_trimStr (char* *s1, int *E) {
	// Deletes leading & trailing ctrl-characters(0..31) and spaces(32)
	
    long L;
    int e1 = 0;
    int e2 = 0;
	     	
	*E = 0;  // inidicate SUCCESS
	
	L = str_len(*s1);

	if( L > 0 ) {
		str_trimStrL(s1, &e1);		
		str_trimStrR(s1, &e2);		
		if( (e1) || (e2) ) {
			*E = -1; // raise ERROR flag		
		}
	}else{
		*E = -1; // raise ERROR flag				
	}		
  	return;
} // str_trimStr()	


char*
str_trim (char* *s1) {
	// Deletes leading & trailing ctrl-characters(0..31) and spaces(32) and
	// returns on success the modified string or
	//         on failure a NULL pointer.
	int E;
	str_trimStr (s1, &E);    if(E)return(NULL);
	return(*s1);
}


void
str_trimStrL (char* *s1, int *E) {
	// Deletes leading ctrl-characters(0..31) and spaces(32)
	
    long L, i, p;
    char c = 0;
    int e = 0;
	     	
	*E = 0;  // indicate SUCCESS
	
	L = str_len(*s1);

	if( L > 0 ) {
		i = -1;  p = -1;
		while( (p < 0) && (i < (L-1)) ) {
			i++;    c=(*s1)[i];    if(c > 32) p=i;
		}
		if( p >= 0) str_delete(s1, 0, p, &e);		
		if( e ) {
			*E = -1; // raise ERROR flag
		}
	}else{
		*E = -1; // raise ERROR flag				
	}		
  	return;
} // str_trimStrL()	


char*
str_trimL (char* *s1) {
	// Deletes leading ctrl-characters(0..31) and spaces(32) and
	// returns on success the modified string or
	//         on failure a NULL pointer.
	int E;
	str_trimStrL (s1, &E);    if(E)return(NULL);
	return(*s1);
}


void
str_trimStrR (char* *s1, int *E) {
	// Deletes trailing ctrl-characters(0..31) and spaces(32)
	
    long L, i, p;
    char c = 0;
    int e = 0;
	     	
	*E = 0;  // indicate SUCCESS
	
	L = str_len(*s1);

	if( L > 0 ) {
		i = L;  p = -1;
		while( (p < 0) && (i > 0) ) {
			i--;    c=(*s1)[i];    if(c > 32) p=i;
		}		
		if( (p >= 0) && (p < (L-1)) ) str_delete(s1, p+1, L-p-1, &e);		
		if( e ) {
			*E = -1; // raise ERROR flag
		}
	}else{
		*E = -1; // raise ERROR flag				
	}		
  	return;
} // str_trimStrR()	


char*
str_trimR (char* *s1) {
	// Deletes trailing ctrl-characters(0..31) and spaces(32) and
	// returns on success the modified string or
	//         on failure a NULL pointer.
	int E;
	str_trimStrR (s1, &E);    if(E)return(NULL);
	return(*s1);
}


void
str_trimStrC (char* *s1, const char* cs, int *E) {
	// Deletes leading & trailing characters of cs from s1
	
    long L;
    int e1 = 0;
    int e2 = 0;
	     	
	*E = 0;  // indicate SUCCESS
	
	L = str_len(*s1);

	if( L > 0 ) {
		str_trimStrCL(s1, cs, &e1);		
		str_trimStrCR(s1, cs, &e2);		
		if( (e1) || (e2) ) {
			*E = -1; // raise ERROR flag	
		}
	}else{
		*E = -1; // raise ERROR flag				
	}		
  	return;
} // str_trimStrC()	


char*
str_trimC (char* *s1, const char* cs) {
	// Deletes leading & trailing characters of cs from s1
	int E;
	str_trimStrC (s1, cs, &E);    if(E)return(NULL);
	return(*s1);
}


void
str_trimStrCL (char* *s1, const char* cs, int *E) {
	// Deletes leading characters of cs from s1
	
    long L, Lcs, i,j, p;
    char c = 0;
    int e = 0;
    int c_in_cs;
	     	
	*E = 0;  // indicate SUCCESS
	
	L   = str_len(*s1);
	Lcs = str_len(cs);

	if( (L > 0) && (Lcs > 0) ) {
		i = -1;  p = -1;
		while( (p < 0) && (i < (L-1)) ) {
			i++;    c=(*s1)[i]; 
			j = -1;  c_in_cs = 0;
			while ( (c_in_cs == 0) && (j < (Lcs-1)) ) {
				j++;	
				if(c == cs[j]) c_in_cs = 1;
			}
			if( c_in_cs == 0){
				p = i;
			}
		}
		if( p >= 0 ) str_delete(s1, 0, p, &e);		
		if( e ) {
			*E = -1; // raise ERROR flag
		}
	}else{
		*E = -1; // raise ERROR flag				
	}		
  	return;
} // str_trimStrCL()	


char*
str_trimCL (char* *s1, const char* cs) {
	// Deletes leading characters of cs from s1
	int E;
	str_trimStrCL (s1, cs, &E);    if(E)return(NULL);
	return(*s1);
}


void
str_trimStrCR (char* *s1, const char* cs, int *E) {
	// Deletes trailing characters of cs from s1
	
    long L, Lcs, i,j, p;
    char c = 0;
    int e = 0;
    int c_in_cs;
	     	
	*E = 0;  // indicate SUCCESS
	
	L   = str_len(*s1);
	Lcs = str_len(cs);

	if( (L > 0) && (Lcs > 0) ) {
		i = L;  p = -1;
		while( (p < 0) && (i > 0) ) {
			i--;    c=(*s1)[i]; 
			j = -1;  c_in_cs = 0;
			while ( (c_in_cs == 0) && (j < (Lcs-1)) ) {
				j++;	
				if(c == cs[j]) c_in_cs = 1;
			}
			if( c_in_cs == 0){
				p = i;
			}
		}
		if( (p >= 0) && (p < (L-1)) ) str_delete(s1, p+1, L-p-1, &e);		
		if( e ) {
			*E = -1; // raise ERROR flag
		}
	}else{
		*E = -1; // raise ERROR flag				
	}		
  	return;
} // str_trimStrCR()	


char*
str_trimCR (char* *s1, const char* cs) {
	// Deletes trailing characters of cs from s1
	int E;
	str_trimStrCR (s1, cs, &E);    if(E)return(NULL);
	return(*s1);
}


void
str_removeLF (char* *s, int *E) {
	// Removes a line feed ( \n or \r\n) at the end of a string 
	
	int err = 0;
	long L;
	
	*E = 0; // indicate SUCCESS
	L = str_len(*s);
	if( L > 0 ) {
		if( (*s)[L-1] == '\n' ) { // if last char (index L-1) is a newline
			(*s)[L-1] = 0; // make this the new end by overwriting it with 0 
			if( L > 1 ){ // repeat the previous procedure if we have \r\n as new line
				if( (*s)[L-2] == '\r' ) {
					(*s)[L-2] = 0;
				}	
			}	
			//err = str_memtrim( s );  // fit memory to actual string length
			if( err ) {
				*E = -1; // raise ERROR flag;
			}	
		}		
	}	
} // str_removeLF


char*
str_remLF (char* *s) {
	int E;
	str_removeLF( s , &E );    if(E)return(NULL);
	return(*s);
} // str_remLF	

	
void
str_fillStrL (char* *s1, const char *s2, long n, int *E) {
	// Repeatetly inserts s2 at the beginning of s1 until the length of s1 equals n.
	
    long L1, L2;
    int e;
    int err = 0;
	char* s0 = NULL;
	     	
	*E = -1;  // raise ERROR flag
	
	L1 = str_len(*s1);
	L2 = str_len(s2);
	
    // printf("\n  s1 = %s\n\n", s1);
    // printf("\n  s2 = %s\n\n", s2);

	if( (n > 0) && (L1 > 0) && (L2 > 0) ) {
		while( (!err) && (L1 < n) ) {
			str_copy(&s0,  s2, &e);  if(e) err = 1;
			str_catenate(&s0, *s1, &e);  if(e) err = 2;
			str_copy( s1,  s0, &e);  if(e) err = 3;
			L1 = L1 + L2;
		}
		if(s0) free(s0);    s0 = NULL;	
		
		L1 = str_len(*s1);  
		if(L1 > n) {
			str_delete(s1, 0, L1-n, &e);  if(e) err = 4;
		}	
		if(!err) {
			*E = 0; // indicate SUCCESS								
		}
	}	
  	return;
} // str_fillStrL()	


char*
str_fillL (char* *s1, const char *s2, long n) {
	// Repeatetly inserts s2 at the beginning of s1 until the length of s1 equals n.
	int E;
	str_fillStrL (s1, s2, n, &E);    if(E)return(NULL);
	return(*s1);
}


void
str_fillStrR (char* *s1, const char *s2, long n, int *E) {
	// Repeatetly appends s2 to s1 until the length of s1 equals n.

    long L1, L2;
    int e;
    int err = 0;
	     	
	*E = -1;  // raise ERROR flag
	
	L1 = str_len(*s1);
	L2 = str_len(s2);
	
    // printf("\n  s1 = %s\n\n", s1);
    // printf("\n  s2 = %s\n\n", s2);

	if( (n > 0) && (L1 > 0) && (L2 > 0) ) {
		while( (!err) && (L1 < n) ) {
			str_catenate(s1, s2, &e);  if(e) err = 1;
			L1 = L1 + L2;
		}	
		L1 = str_len(*s1);  
		if(L1 > n) {
			str_delete(s1, L1, L1-n, &e);  if(e) err = 2;
		}	
		if(!err) {
			*E = 0; // indicate SUCCESS								
		}
	}	
  	return;
} // str_fillStrL()	


char*
str_fillR (char* *s1, const char *s2, long n) {
	// Repeatetly appends s2 to s1 until the length of s1 equals n.
	int E;
	str_fillStrR (s1, s2, n, &E);    if(E)return(NULL);
	return(*s1);
}


void
str_tolowerStr (char* *s1, int *E) {
	// Lowers s1 .
	
	long i, L;
    
	*E = -1; // raise ERROR flag
	
	L = str_len(*s1);
	
	if( L > 0) {
		for(i=0;i<=(L-1);i++) {
	  		(*s1)[i] = tolower((*s1)[i]); // from <ctype.h>
	  	}			
	  	*E = 0; // indicate SUCCESS
	}	
  	return;
} // str_tolowerStr()	


char*
str_tolower (char* *s1) {
	int E;
	str_tolowerStr (s1, &E);    if(E)return(NULL);
	return(*s1);
}

void
str_toupperStr (char* *s1, int *E) {
	// Uppers s1 .
	
	long i, L;

	*E = -1; // raise error flag
	
	L = str_len(*s1);
	
	if( L > 0) {
	  	for(i=0;i<=(L-1);i++) {
	  		(*s1)[i] = toupper((*s1)[i]); // from <ctype.h>
	  	}			
	  	*E = 0; // indicate SUCCESS
	}	
  	return;
} // str_toupper()	


char*
str_toupper (char* *s1) {
	int E;
	str_toupperStr (s1, &E);    if(E)return(NULL);
	return(*s1);
}


void
str_GetFileNameStr (char* *s1, const char* s2, int *E) {
	// Get file name incl. extension from string s2 and
	// return it in s1.
	
	const int not_casens = 0;
	const int reverse = 1;

    long L2, p,p1,p2;
    int e1, e2;
    
	     	    
	*E = -1;  // raise ERROR flag
	
	e1 = str_ini(s1);
	if( e1 ) return; // EXIT on error 
	
	L2 = str_len(s2);
	
	if( L2 > 0) {
		
		//p = str_pos(s2, PathDelim, reverse, not_casens);
		
		//search the last path delimiter  / or \  in path string s1:  
		p = -1;    
		p1 = str_pos ( s2, "/" ,  reverse, not_casens);	   if( p1 >= 0 ) p = p1;
		p2 = str_pos ( s2, "\\" , reverse, not_casens);	   if( p2 >= 0 ) p = p2;
		if( (p1>=0)&&(p2>=0) ) {  if( p1 > p2 ) p = p1; else p = p2;  }
				
		if( p < 0) {
			str_copy(s1 , s2, &e1);
		}else{
			str_Ncopy(s1, s2, p+1, L2-(p+1), &e1);
		}	
		
		str_trimStr(s1, &e2);

		if( (!e1) && (!e2) ) {		  	
		  	*E = 0; // indicate SUCCESS
		}
	}	
	
  	return;	
} // str_GetFileNameStr()


char*
str_GetFileName (const char* s2) {
	// Get file name incl. extension from string s2 and
	// return it in s1.
	int E;
	char* s1 = NULL;
	str_GetFileNameStr (&s1, s2, &E);    if(E)return(NULL);
	return(s1);
}


void
str_GetFilePathStr (char* *s1, const char* s2, int *E) {
	// Get file path (incl. trailing delimiter) from string s2 and
	// return it in s1.
	// If s2 contains no path (just a file or directory name) 
	// an empty string is returned in s1.
	
	const int not_casens = 0;
	const int reverse = 1;

    long L2, p,p1,p2;
    int e1, e2;
	     	

	*E = -1;  // raise ERROR flag

	e1 = str_ini(s1);
	if( e1 ) return; // EXIT on error 
		
	L2 = str_len(s2);
	
	if( L2 > 0) {
		
		//p = str_pos(s2, PathDelim, reverse, not_casens);
		
		//search the last path delimiter  / or \  in path string s1:  
		p = -1;    
		p1 = str_pos ( s2, "/" ,  reverse, not_casens);	   if( p1 >= 0 ) p = p1;
		p2 = str_pos ( s2, "\\" , reverse, not_casens);	   if( p2 >= 0 ) p = p2;
		if( (p1>=0)&&(p2>=0) ) {  if( p1 > p2 ) p = p1; else p = p2;  }
		
		if( p < 0) { 
			str_ini(s1);  
		}else{
			str_Ncopy(s1, s2, 0, p+1, &e1);
		}	
		
		str_trimStr(s1, &e2);

		if( (!e1) && (!e2) ) {		  	
		  	*E = 0; // indicate SUCCESS
		}
	}	
	
  	return;	
} // str_GetFilePathStr()


char*
str_GetFilePath (const char* s2) {
	// Get file path (incl. trailing delimiter) from string s2 and
	// return it in s1.
	// If s2 contains no path (just a file or directory name) 
	// an empty string is returned in s1.
	int E;
	char* s1 = NULL;
	str_GetFilePathStr (&s1, s2, &E);    if(E)return(NULL);
	return(s1);
}


void
str_GetFileExtStr (char* *s1, const char* s2, int *E) {
	// Get file extension (incl. '.') from string s2 and
	// return it in s1.
	// If s2 has no extension an empty string is returned.
	
	const int not_casens = 0;
	const int reverse = 1;
	
    const char* ExtDelim = ".";
    
    long L1, L2, p;
    int e, e1, err;
	char* s0 = NULL;

	err = 0;
	     	    
	*E = -1;  // raise ERROR flag

	e1 = str_ini(s1);
	if( e1 ) return; // EXIT on error 
		
	L2 = str_len(s2);
	
	if( L2 > 0) {
		
		str_GetFileNameStr(s1, s2, &e);    if(e) err = 1;
		
		L1 = str_len(*s1);
		
		p = str_pos(*s1, ExtDelim, reverse, not_casens);
		
		if( p < 0) {
		    if( !str_ini(s1) ) err = 2;
		}else{
			str_Ncopy(&s0, *s1, p, L1-p, &e);    if(e) err = 21;
			str_copy(s1, s0, &e);                if(e) err = 22;
		}	
		if(s0) free(s0);    s0 = NULL;
		
		str_trimStr(s1, &e);    if(e) err = 3;

		if( !err ) {		  	
		  	*E = 0; // indicate SUCCESS
		}
	}	
	
  	return;	
} // str_GetFileExtStr()


char*
str_GetFileExt (const char* s2) {
	// Get file extension (incl. '.') from string s2 and
	// return it in s1.
	// If s2 has no extension an empty string is returned.
	int E;
	char* s1 = NULL;
	str_GetFileExtStr (&s1, s2, &E);    if(E)return(NULL);
	return(s1);
}	


void
str_ChangeFileExtStr (char* *s1, const char* s2, int *E) {
	// Change file extension in s1 to the extension given in s2 (incl. '.')
	// and return s1.
	// If s1 has no extension s2 is appended to s1.
	
	const int not_casens = 0;
	const int reverse = 1;
	
    const char* ExtDelim = ".";
    
    long L1, L2, Ln, p;
    int e, err;
	char* path = NULL;
	char* name = NULL;

	err = 0;
	     	
	*E = -1;  // raise ERROR flag
		
	L1 = str_len(*s1);
	L2 = str_len(s2);
	
	if( (L1 > 0) && (L2 > 0) ) {
		
		str_GetFilePathStr(&path, *s1, &e);   if(e) err = 1;
		str_GetFileNameStr(&name, *s1, &e);   if(e) err = 2;
		
		Ln = str_len(name);
		
		p = str_pos(name, ExtDelim, reverse, not_casens);
		
		if( p >= 0 ) {
			str_delete(&name, p, Ln-p, &e);    if(e) err = 21;
		}	

		str_catenate3(&path , name, s2, &e);    if(e) err = 3;
		str_copy(s1 , path, &e);           if(e) err = 4;
		
		str_trimStr(s1, &e);    if(e) err = 5;

		if(path) free(path);    path = NULL;
		if(name) free(name);    name = NULL;
		
		if( !err ) {		  	
		  	*E = 0; // indicate SUCCESS
		}
	}	
	
  	return;	
} // str_GetFileExtStr()


char*
str_ChangeFileExt (const char* s2) {
	// Change file extension in s1 to the extension given in s2 (incl. '.')
	// and return s1.
	// If s1 has no extension s2 is appended to s1.
	int E;
	char* s1 = NULL;
	str_ChangeFileExtStr (&s1, s2, &E);    if(E)return(NULL);
	return(s1);
}


char *
Efmt_ (long double X, int width, int d_exp) {
	// Formats a floating point number X into a string of 
	// scientific format of length width and with an exponent
	// of d_exp digits and returns the number-string as result.
	// In width the first character is always reserved for the sign.
	// In case of a positive X a space is inserted as 1st character
	// instead of a '+'.
	//
	// NOTE:   d_exp = 1..3     more than 3 digits in the exponent
	//                          are NOT SUPPORTED by %E - formating
	//                          max. supported exponent is 300 !!
	//
	// !! NOT INTENDED FOR DIRECT USE --> USE MACRO INSTEAD !!
	
	const int d_base = 6; // -->  -1.1E+d_exp  as minimum supported format 
	int W_min;		
	int precision;	
	int err;
	long L;
	char* S = NULL;
	char c;
	
	err = str_ini(&S);	
	if( err ) {// mallocates memory and initializes S as empty string;
         S = NULL;
	     return(S);  // exit on error 
	}     
	
	//correct nb. of exponent digits
	if( d_exp < 1) d_exp = 1;
	if( d_exp > 3) d_exp = 3;  
	
	//if X is an extremely large or small value correct d_exp
			if( X < 0.0 ) {
				if( -X >= (long double)1.0E+100 ) d_exp = 3;
				if( -X <= (long double)1.0E-100 ) d_exp = 3;
	 }else{ if( X > 0.0 ) {
				if(  X >= (long double)1.0E+100 ) d_exp = 3;
				if(  X <= (long double)1.0E-100 ) d_exp = 3;
			}}
			
	if( d_exp == 1 ) {
			if( X < 0.0 ) {
				if( -X >= 1.0E+10 ) d_exp = 2;
				if( -X <= 1.0E-10 ) d_exp = 2;
	 }else{ if( X > 0.0 ) {
				if(  X >= 1.0E+10 ) d_exp = 2;
				if(  X <= 1.0E-10 ) d_exp = 2;

			}}
	}	
		
	W_min = d_base + d_exp;  // -->  -1.1E+1  as minimum supported format
	
	if ( width < W_min ) width = W_min ;  // correct width if too small
	
	precision = width - (d_base-1) - d_exp;
	
	if( d_exp == 1) width = width + 1; // in case of d_exp = 1 increase width by 1.
	                                   // Otherwise in case of a positive X the
	                                   // leading space would be missing  or the
	                                   // string would exceed the width by one character
	                                   // if X is negative.

// %E creates a scientific format with a !!  2-digit !!  exponent.	
// If the number is very large or very small, a 3-digit exponent
// of range 100..300 can result. 
// If exponent > 300 sprintf returns the string ' INF'.
	sprintf(S, "%*.*LE", width,precision, X);  // sprintf() from <stdio.h>
	
    L = str_len(S);
    
    if( (L > 0) /*&& (d_exp != 2)*/ ) {
    	c = S[L-3]; 
  	// Do we have a 3-digit exponent ?
    	if( (c == '+') || (c == '-') ) {
    		// NO , a '+' or '-' sign was found
    		
    		// EXPONENT has 2 digits !
    		
    		// In case of a 1-digit exponent desired,
    		// trim exponent by deleting a leading '0'
    		if( d_exp == 1 ) {
	    		c = S[L-2]; 
    			if(c == '0') str_delete(&S, L-2, 1, &err);    			
    		}
    			
    		// In case of 3-digit exponent desired,
    		// insert a leading '0'   
    		if( d_exp == 3 ) {
    			str_insert(&S, "0", L-2, &err);    			
    			c = S[0];
    			if( c == ' ' ) str_delete(&S, 0, 1, &err);
    		}	   
    	}else{
    		// ..maybe 3-digit, further checking required..
    		if( isdigit( (int)c ) ) { // if S[L-3]==0-9.. 
    		  	c = S[L-4];                 //..and..
    			if( (c == '+') || (c == '-') ) { //..if S[L-4]== +,-
    				
		    		// YES , EXPONENT has 3 digits !
		    		
		    		// A 3-digit exponent is only produced for
		    		// very large numbers, when the 2-digit standard
		    		// format is insufficient.
		    		c = S[L-3]; //So S[L-3] SHOULD NEVER BE '0' !!		    		
		    		
		    		if(d_exp == 2) { 
		    			// THIS SHOULD NEVER BE EXECUTED 
		    			// (but maybe the above comparison of X to the extreme values failed)
		    			precision = precision - 1;
		    			sprintf(S, "%*.*LE", width,precision, X);  // sprintf() from <stdio.h>
		    		}	
    			}
    		}
    	}	
    }	
        
    return(S);
} // Efmt()


char *
Ffmt_ (long double X, int width, int d_frac) {
	// Formats a floating point number X into a string of 
	// floating point format of length width and with d_frac
	// digits after the decimal point and returns the 
	// number-string as result.
	// In width the first character is always reserved for the sign.
	// In case of a positive X a space is inserted as 1st character
	// instead of a '+'.
	// If the value of X is too large that the width would be
	// exceeded,  Efmt()  is called in order to try to fit the
	// desired width.
	// If width <= 0 then the length of the string is free (up to MAX_WIDTH).
	//
	// !! NOT INTENDED FOR DIRECT USE --> USE MACRO INSTEAD !!
	
	const long MAX_WIDTH = 30;
	
	int W_min;		
	int precision;	
	int err;
	long L;
	char* S = NULL;
    
    err = str_ini(&S);
	if( err ) {// mallocates memory and initializes S as empty string;
         S = NULL;
	     return(S);  // exit on error 
	}     
	
	//correct nb. of fractional digits
	if( d_frac < 0) d_frac = 0;
	if( d_frac == 0 ) W_min = 2; else W_min = d_frac + 2;
		 	
	precision = d_frac;
	if( width <= 0 ) { // free width but not more than MAX_WIDTH
		sprintf(S, "%.*Lf", precision, X);  // sprintf() from <stdio.h>
		L = str_len(S);
		if( L > MAX_WIDTH ) {
			S = Efmt_(X, MAX_WIDTH, 1);
		}	
	}else{	
		if( width < W_min ) width = W_min;
		sprintf(S, "%*.*Lf", width,precision, X);  // sprintf() from <stdio.h>
		
		L = str_len(S);
		if( L > width ) {
			S = Efmt_(X, width, 1); // try scientific format with as less digits for the exponent
			                       // to keep as much precision as possible. 
		}	
	}
			
    return(S);
} // Ffmt()


double
str_toDbl (const char* s1, int *E) {
	
	double X;
	double Y;  // help var
	int e1 = 0;
	int e2 = 0;
	long L;
	char* S = NULL;
	char* ss = NULL;
	
	*E = -1; // raise ERROR flag
	
	X = DBL_MAX;  // from <float.h>
	
	L = str_len(s1);
	
	if( L > 0) {
		str_copy(&S, s1, &e1);
		str_trimStr(&S, &e2);
		if( (!e1) && (!e2) ) {
			if( str_is_numstr(S) ) {
				
				Y = strtod(S, &ss);  // from <stdlib.h>
				
				if( str_len(ss) == 0 ) {
					 X = Y;
					*E = 0;  // indicate SUCCESS
				}	 
			}	
		}			
		if(S!=NULL) free(S);		
	}
	return(X);	
} // str_toDbl


float
str_toFlt (const char* s1, int *E) {
	
	float X;
	double Y;  // help var
	int e1 = 0;
	
	*E = -1; // raise ERROR flag
	
	X = FLT_MAX;  // from <float.h>
	
	Y = str_toDbl(s1, &e1);
	
	if( !e1 ) {
		if( fabs(Y) <= (double)FLT_MAX ) {
			 X = (float)Y;
			*E = 0;  // indicate SUCCESS
		}	
	}
	return(X);	
} // str_toFlt


long
str_toLong (const char* s1, int *E) {
	
	long I;
	long J;  // help var
	int e1 = 0;
	int e2 = 0;
	long L;
	char* S = NULL;
	char* ss = NULL;
	
	*E = -1; // raise ERROR flag
	
	I = LONG_MAX;  // from <limits.h>
	
	L = str_len(s1);
	
	if( L > 0) {
		str_copy(&S, s1, &e1);
		str_trimStr(&S, &e2);
		if( (!e1) && (!e2) ) {
			if( str_is_intstr(S) ) {
				
				J = strtol(S, &ss, 10);  // from <stdlib.h>
				
				if( str_len(ss) == 0 ) {
					 I = J;
					*E = 0;  // indicate SUCCESS
				}	 
			}	
		}			
		if(S!=NULL) free(S);		
	}
	return(I);	
} // str_toLong


int
str_toInt (const char* s1, int *E) {
	
	int I;
	long J;  // help var
	int e1 = 0;
	
	*E = -1; // raise ERROR flag
	
	I = INT_MAX;  // from <limits.h>
	
	J = str_toLong(s1, &e1);
	
	if( !e1 ) {
		if( labs(J) <= (long)INT_MAX ) {
			 I = (int)J;
			*E = 0;  // indicate SUCCESS
		}	
	}
	return(I);	
} // str_toInt


short
str_toShrt (const char* s1, int *E) {
	
	short I;
	long J;  // help var
	int e1 = 0;
	
	*E = -1; // raise ERROR flag
	
	I = SHRT_MAX;  // from <limits.h>
	
	J = str_toLong(s1, &e1);
	
	if( !e1 ) {
		if( labs(J) <= (long)SHRT_MAX ) {
			 I = (short)J;
			*E = 0;  // indicate SUCCESS
		}	
	}
	return(I);	
} // str_toShrt


signed char
str_toChar (const char* s1, int *E) {
	
	signed char I;
	long J;  // help var
	int e1 = 0;
	
	*E = -1; // raise ERROR flag
	
	I = SCHAR_MAX;  // from <limits.h>
	
	J = str_toLong(s1, &e1);
	
	if( !e1 ) {
		if( labs(J) <= (long)SCHAR_MAX ) {
			 I = (signed char)J;
			*E = 0;  // indicate SUCCESS
		}	
	}
	return(I);	
} // str_toChar


unsigned long
str_toUlong (const char* s1, int *E) {
	
	unsigned long U;
	unsigned long V;  // help var
	int e1 = 0;
	int e2 = 0;
	long L;
	char* S = NULL;
	char* ss = NULL;
	
	*E = -1; // raise ERROR flag
	
	U = ULONG_MAX;  // from <limits.h>
	
	L = str_len(s1);
	
	if( L > 0) {
		str_copy(&S, s1, &e1);
		str_trimStr(&S, &e2);
		if( (!e1) && (!e2) ) {
			if( str_is_intstr(S) && (S[0] != '-') ) {
				
				V = strtoul(S, &ss, 10);  // from <stdlib.h>
				
				if( str_len(ss) == 0 ) {
					 U = V;
					*E = 0;  // indicate SUCCESS
				}	 
			}	
		}			
		if(S!=NULL) free(S);		
	}
	return(U);	
} // str_toUlong


unsigned int
str_toUint (const char* s1, int *E) {
	
	unsigned int U;
	unsigned long V;  // help var
	int e1 = 0;
	
	*E = -1; // raise ERROR flag
	
	U = UINT_MAX;  // from <limits.h>
	
	V = str_toUlong(s1, &e1);
	
	if( !e1 ) {
		if( fabs((double)V) <= (double)UINT_MAX ) {
			 U = (unsigned int)V;
			*E = 0;  // indicate SUCCESS
		}	
	}
	return(U);	
} // str_toUint


unsigned short
str_toUshrt (const char* s1, int *E) {
	
	unsigned short U;
	unsigned long V;  // help var
	int e1 = 0;
	
	*E = -1; // raise ERROR flag
	
	U = USHRT_MAX;  // from <limits.h>
	
	V = str_toUlong(s1, &e1);
	
	if( !e1 ) {
		if( fabs((double)V) <= (double)USHRT_MAX ) {
			 U = (unsigned short)V;
			*E = 0;  // indicate SUCCESS
		}	
	}
	return(U);	
} // str_toUshrt


unsigned char
str_toUchar (const char* s1, int *E) {
	
	unsigned char U;
	unsigned long V;  // help var
	int e1 = 0;
	
	*E = -1; // raise ERROR flag
	
	U = UCHAR_MAX;  // from <limits.h>
	
	V = str_toUlong(s1, &e1);
	
	if( !e1 ) {
		if( fabs((double)V) <= (double)UCHAR_MAX ) {
			 U = (unsigned char)V;
			*E = 0;  // indicate SUCCESS
		}	
	}
	return(U);	
} // str_toUchar
