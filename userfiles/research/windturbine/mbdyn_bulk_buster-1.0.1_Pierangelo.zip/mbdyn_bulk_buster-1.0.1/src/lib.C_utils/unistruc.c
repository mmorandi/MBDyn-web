/*                      Copyright  (C)  2006    Patrick Rix 
 * unistruc.h
 * ===========
 * Utilities for (A)scii <-> (B)inary (C)onversion of data files
 * containing measurement or simulation data with vector or matrix
 * character. 
 * This includes 
 *  - reading data-sets from ascii files or abc-formatted binary files
 *    into abc-data structures
 *  - writing abc-data structures to an acscii file or an abc-formatted binary file
 *  - manipulating contents of abc-data structures like editing or compressing of data etc.
 *
 * Main purpose is to provide an I/O-interface for general handling and manipulation
 * of result files of  MBDyn  simulations which come out in ascii format.
 * The main focus was to provide an interface for the ascii <-> binary conversion
 * including a simultaneous file-compression when transforming from 
 * ascii -> binary floating formats -> binary integral formats.
 * The central aspect is to shrink the file size required to hold the results.
 *
 * 
 * LICENSE
 *                not yet defined
 * 
 * AUTHOR(S)
 *                Patrick Rix          e-mail: <patrick.rix@online.de>
 *
 * Modification History
 * ====================
 * Version      Date         Editor      Changes/Modifications/Improvements
 * -------------------------------------------------------------------------
 *   
 *  VERSION_UNISTRUC  -->  remember to update version number in header file
 * 
 *  0.0.0    11.August 2006    Rix         Basic Version, 1st beta release.
 * 
 */

#include "unistruc.h"

#include "sys_utils.h"
#include "str_utils.h"

#include <float.h>
#include <limits.h>
#include <stdlib.h>

////////////////////////////////////////////////////////////
// <<<  GLOBAL CONSTANTS  exported by  unistruc.c  >>>  
////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////
// <<<  LOCAL CONSTANTS private to  unistruc.c  >>>  
////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////
// <<<  LOCAL FUNCTIONS private to  unistruc.c  >>>  
////////////////////////////////////////////////////////////

static int  CreateResizeUniStruct ( int CREATE,  TpointerUniStruct *UNI,  unsigned long Size,  short dType,  short pType );
static int  ModifyUniStruct       ( int COMMAND, TpointerUniStruct *UNI,  unsigned long Index,  unsigned long Number );

static void XchangeSubElemContent ( int MOVE,    TpointerUniStruct *UNI,  unsigned long i,  unsigned long j,  short Sub_dType );

static int dType_SUPPORTED(short dType);
static int pType_SUPPORTED(short pType);

////////////////////////////////////////////////////////////
// <<<  GLOBAL FUNCTIONS  exported by  unistruc.c  >>>  
////////////////////////////////////////////////////////////

static int
dType_SUPPORTED ( short dType ) { 
	switch( dType ) {
	  case e_T_UNI_STRUCT:
      case e_T_ITEM_DATA: 
      case e_T_OBJECT_DATA:
      case e_T_SERIES_DATA:
      case e_T_DATASET_DATA:
      case e_T_CHAR:          case e_T_UCHAR:
      case e_T_SHORT:         case e_T_USHORT:
      case e_T_INT:           case e_T_UINT:
      case e_T_LONG:          case e_T_ULONG:
      case e_T_FLOAT:
      case e_T_DOUBLE:
      case e_T_LONG_DOUBLE:        
          return(1);
        break; 
	  default:
	      return(0);
	}	
} // dType_SUPPORTED


static int
pType_SUPPORTED ( short pType ) { 
	switch( pType ) {
      case e_T_NO_PROP:
      case e_T_BASE_PROP:
      case e_T_ITEM_PROP:    
      case e_T_OBJECT_PROP:  
      case e_T_SERIES_PROP:  
      case e_T_DATASET_PROP: 
          return(1);
        break; 
	  default:
	      return(0);
	}	
} // pType_SUPPORTED	


int
IniScaleStruct ( ScaleStruct_t *Scale ) {
	if( Scale == NULL )return(-1);
	Scale->Fac = 0.0;    Scale->Off = 0.0;
	return(0);
}

int
CreateScaleStruct ( ScaleStruct_t* *Scale ) {
	if( !(*Scale = Xmalloc( ScaleStruct_t , 1 )) )return(-1);
	IniScaleStruct( *Scale );
	return(0);
}

int
DestroyScaleStruct ( ScaleStruct_t* *Scale) {
	if( *Scale != NULL ) { free(*Scale);   *Scale = NULL; };
	return(0);
}



int
IniStatStruct ( StatStruct_t *Stat ) {
	if( Stat == NULL )return(-1);
	Stat->Min =  DBL_MAX;     Stat->Mean = 0.0;
	Stat->Max = -DBL_MAX;     Stat->Rms  = 0.0; 	           
	return(0);
}

int
CreateStatStruct ( StatStruct_t* *Stat ) {
	if( !(*Stat = Xmalloc( StatStruct_t , 1 )) )return(-1);
	IniStatStruct( *Stat );
	return(0);
}

int
DestroyStatStruct ( StatStruct_t* *Stat ) {
	if( *Stat != NULL ) { free(*Stat);   *Stat = NULL; };
	return(0);
};



int
IniParaStruct ( ParaStruct_t *Para ) {
	if( Para == NULL )return(-1);
	Para->Name = NULL;
	Para->Val  = NULL;   Para->L_Val = 0;
	return(0);
}

int
CreateParaStruct ( ParaStruct_t* *Para ) {
	if( !(*Para = Xmalloc( ParaStruct_t , 1 )) )return(-1);
	IniParaStruct( *Para );
	return(0);
}

int
DestroyParaStruct ( ParaStruct_t* *Para ) {
	if( *Para != NULL ) { 
		if( (*Para)->Name != NULL ) free((*Para)->Name);
		if( (*Para)->Val  != NULL ) free((*Para)->Val);
		free(*Para);   *Para = NULL;
	}	
	return(0);
}



int
IniBaseProp( TpointerBaseProp  BaseProp ) {	
	
	int E = -1; // indicate FAILURE
	
	if( BaseProp == NULL )return(E); // EXIT ON ERROR	
	
	BaseProp->ShareCommonProperies = 0; // all series share the same common properties --> series do not own individual properties
	BaseProp->IsSynchronized       = 0; // all series share the same reference (time track, frequency or whatever)
	BaseProp->IsEquidistant        = 0; // all series share the same equidistandt reference (const. dT, dF, etc.)   
	BaseProp->IsEquisized          = 0; // all series have the same length (number of elements
	
	BaseProp->Name  = NULL;    
	BaseProp->Unit  = NULL;
	BaseProp->Descr = NULL;

	BaseProp->L_ID    = 0;    BaseProp->ID    = NULL;       
	BaseProp->L_Index = 0;    BaseProp->Index = NULL;     
    BaseProp->L_Flag  = 0;    BaseProp->Flag  = NULL;
		
	BaseProp->Scale = NULL;    

	BaseProp->Stat  = NULL; 
	
	BaseProp->L_Para = 0;   BaseProp->Para = NULL; 
	
	E = 0; // indicate SUCCESS
	return(E);	
} // IniBaseProp	             

extern int CreateBaseProp ( TpointerBaseProp *BaseProp );
extern int DestroyBaseProp ( TpointerBaseProp *BaseProp );

int
CreateBaseProp ( TpointerBaseProp *BaseProp ) {
	if( !(*BaseProp = Xmalloc( BaseProp_t , 1 )) )return(-1);
	IniBaseProp( *BaseProp );
	return(0);
}

int
DestroyBaseProp ( TpointerBaseProp *BaseProp ) { // basic properties for objects, items, series, datasets, etc.   	
	if( *BaseProp != NULL ) { 	
		if( (*BaseProp)->Name  != NULL ) free((*BaseProp)->Name);    
		if( (*BaseProp)->Unit  != NULL ) free((*BaseProp)->Unit);    
		if( (*BaseProp)->Descr != NULL ) free((*BaseProp)->Descr);    

		if( (*BaseProp)->ID    != NULL ) free((*BaseProp)->ID);    
		if( (*BaseProp)->Index != NULL ) free((*BaseProp)->Index);    
		if( (*BaseProp)->Flag  != NULL ) free((*BaseProp)->Flag);    
	
		DestroyScaleStruct( &((*BaseProp)->Scale) );    
		
		DestroyStatStruct( &((*BaseProp)->Stat) );
		
		DestroyParaStruct( &((*BaseProp)->Para) );

		free(*BaseProp);   *BaseProp = NULL;			
	}	
	return(0);
}; // DestroyBaseProp	

u_long_t
ReadBaseProp( FILE* F, TpointerBaseProp *BaseProp, int *E ) {
	
	u_long_t  L_r = 0;  // accumulated number of BYTES written
	
	short  L_Name, L_Unit, L_Descr;
	char HAVE_ScaleStruct = 0;
	char HAVE_StatStruct  = 0;
	size_t     N_r;
	int i;
	int err;
		
	*E = -1; // raise ERROR flag
	
	if( F == NULL )return(L_r); // EXIT ON ERROR	
	if( BaseProp == NULL )return(L_r); // EXIT ON ERROR	
	if( *BaseProp == NULL )return(L_r); // EXIT ON ERROR	
        
    // read  CONTROL FLAGS
	L_r += fREAD( F, &(*BaseProp)->ShareCommonProperies, char, 1, &N_r, &err );    if(err)return(L_r); // EXIT ON ERROR
	L_r += fREAD( F, &(*BaseProp)->IsSynchronized, char, 1, &N_r, &err );    if(err)return(L_r); // EXIT ON ERROR
	L_r += fREAD( F, &(*BaseProp)->IsEquidistant, char, 1, &N_r, &err );    if(err)return(L_r); // EXIT ON ERROR
	L_r += fREAD( F, &(*BaseProp)->IsEquisized, char, 1, &N_r, &err );    if(err)return(L_r); // EXIT ON ERROR
	
    // read  HELP-FLAGS  
	L_r += fREAD( F, &HAVE_ScaleStruct, char, 1, &N_r, &err );    if(err)return(L_r); // EXIT ON ERROR
	L_r += fREAD( F, &HAVE_StatStruct,  char, 1, &N_r, &err );    if(err)return(L_r); // EXIT ON ERROR

	// read  LENGTH:  L_Name,  L_Unit,  L_Descr
	L_r += fREAD( F, &L_Name,  short, 1, &N_r, &err );    if(err)return(L_r); // EXIT ON ERROR	
	L_r += fREAD( F, &L_Unit,  short, 1, &N_r, &err );    if(err)return(L_r); // EXIT ON ERROR	
	L_r += fREAD( F, &L_Descr, short, 1, &N_r, &err );   if(err)return(L_r); // EXIT ON ERROR	
    	
	// read  LENGTH:  L_ID,  L_Index,  L_Flag,  L_Para
	L_r += fREAD( F, &(*BaseProp)->L_ID,    unsigned short, 1, &N_r, &err );    if(err)return(L_r); // EXIT ON ERROR	
	L_r += fREAD( F, &(*BaseProp)->L_Index, unsigned short, 1, &N_r, &err );    if(err)return(L_r); // EXIT ON ERROR	
	L_r += fREAD( F, &(*BaseProp)->L_Flag,  unsigned short, 1, &N_r, &err );    if(err)return(L_r); // EXIT ON ERROR	
	L_r += fREAD( F, &(*BaseProp)->L_Para,  unsigned short, 1, &N_r, &err );    if(err)return(L_r); // EXIT ON ERROR	
		
    // read  ID[],  Index[],  Flag[]
    if( (*BaseProp)->L_ID > 0 ) {
    	if( !((*BaseProp)->ID = Xmalloc( long, (*BaseProp)->L_ID )) )return(L_r);  // EXIT ON ERROR
		L_r += fREAD( F, (*BaseProp)->ID, long, (*BaseProp)->L_ID, &N_r, &err );    if(err)return(L_r); // EXIT ON ERROR
    }	
    if( (*BaseProp)->L_Index > 0 ) {
    	if( !((*BaseProp)->Index = Xmalloc( long, (*BaseProp)->L_Index )) )return(L_r);  // EXIT ON ERROR
		L_r += fREAD( F, (*BaseProp)->Index, long, (*BaseProp)->L_Index, &N_r, &err );    if(err)return(L_r); // EXIT ON ERROR
    }	
    if( (*BaseProp)->L_Flag > 0 ) {
    	if( !((*BaseProp)->Flag = Xmalloc( short, (*BaseProp)->L_Flag )) )return(L_r);  // EXIT ON ERROR
		L_r += fREAD( F, (*BaseProp)->Flag, short, (*BaseProp)->L_Flag, &N_r, &err );    if(err)return(L_r); // EXIT ON ERROR
    }	
	
	// read STRING:  Name[]
	if( L_Name > 0 ) {
		str_Nini( &((*BaseProp)->Name) , (long)(L_Name + 1) ); // L_Name + terminating 0
		L_r += fREAD( F, (*BaseProp)->Name, char, L_Name, &N_r, &err );    if(err)return(L_r); // EXIT ON ERROR
	}else{ // <= 0
		if( (*BaseProp)->Name != NULL ) { 
			free((*BaseProp)->Name);    (*BaseProp)->Name = NULL; 
		}
	}		

	// read STRING:  Unit[],  	
	if( L_Unit > 0 ) {
		str_Nini( &((*BaseProp)->Unit) , (long)(L_Unit + 1) ); // L_Unit + terminating 0
		L_r += fREAD( F, (*BaseProp)->Unit, char, L_Unit, &N_r, &err );    if(err)return(L_r); // EXIT ON ERROR
	}else{ // <= 0
		if( (*BaseProp)->Unit != NULL ) { 
			free((*BaseProp)->Unit);    (*BaseProp)->Unit = NULL; 
		}
	}		

	// read STRING:  Descr[]	
	if( L_Descr > 0 ) {
		str_Nini( &((*BaseProp)->Descr) , (long)(L_Descr + 1) ); // L_Descr + terminating 0
		L_r += fREAD( F, (*BaseProp)->Descr, char, L_Descr, &N_r, &err );    if(err)return(L_r); // EXIT ON ERROR
	}else{ // <= 0
		if( (*BaseProp)->Descr != NULL ) { 
			free((*BaseProp)->Descr);    (*BaseProp)->Descr = NULL; 
		}
	}		
	
	
	// read  Scale		
	if( HAVE_ScaleStruct ) {		
	 //	L_r += ReadScaleStruct( F, &(*BaseProp)->Scale, &err );    if(err)return(L_r); // EXIT ON ERROR		
	}	

	// read  Stat		
	if( HAVE_StatStruct ) {	
	 //	L_r += ReadStatStruct( F, &(*BaseProp)->Stat, &err );    if(err)return(L_r); // EXIT ON ERROR					
	}	

	if( (*BaseProp)->L_Para > 0 ) {
		for(i=0; i<(*BaseProp)->L_Para; i++) {
		 //	L_r += ReadParaStruct( F, &(*BaseProp)->Para[i], &err );    if(err)return(L_r); // EXIT ON ERROR					
		} 
	}else{ // <= 0
		if( (*BaseProp)->Para != NULL ) { 
			free((*BaseProp)->Para);    (*BaseProp)->Para = NULL; 
		}
	}		
	
	
		
	*E = 0; // indicate SUCCESS
	
	return(L_r);
} // ReadBaseProp	

u_long_t
WriteBaseProp( FILE* F, TpointerBaseProp *BaseProp, int *E ) {
	
	u_long_t  L_w = 0;  // accumulated number of BYTES written
	
	short  L_Name, L_Unit, L_Descr;
	char HAVE_ScaleStruct = 0;
	char HAVE_StatStruct  = 0;
	size_t     N_w;
	int i;
	int err;
		
	*E = -1; // raise ERROR flag
	
	if( F == NULL )return(L_w); // EXIT ON ERROR	
	if( BaseProp == NULL )return(L_w); // EXIT ON ERROR	
	if( *BaseProp == NULL )return(L_w); // EXIT ON ERROR	
    
	if( (*BaseProp)->Scale == NULL ) HAVE_ScaleStruct = 0; else HAVE_ScaleStruct  = 1;	
	if( (*BaseProp)->Stat  == NULL ) HAVE_StatStruct  = 0; else HAVE_StatStruct = 1;	

	L_Name  = (short) str_len ( (*BaseProp)->Name );      if( L_Name < 0 )  L_Name  = 0;
	L_Unit  = (short) str_len ( (*BaseProp)->Unit );      if( L_Unit < 0 )  L_Unit  = 0;
	L_Descr = (short) str_len ( (*BaseProp)->Descr );     if( L_Descr < 0 ) L_Descr = 0;
    
    // write  CONTROL FLAGS
	L_w += fWRITE( F, &(*BaseProp)->ShareCommonProperies, char, 1, &N_w, &err );    if(err)return(L_w); // EXIT ON ERROR
	L_w += fWRITE( F, &(*BaseProp)->IsSynchronized, char, 1, &N_w, &err );    if(err)return(L_w); // EXIT ON ERROR
	L_w += fWRITE( F, &(*BaseProp)->IsEquidistant, char, 1, &N_w, &err );    if(err)return(L_w); // EXIT ON ERROR
	L_w += fWRITE( F, &(*BaseProp)->IsEquisized, char, 1, &N_w, &err );    if(err)return(L_w); // EXIT ON ERROR
	
    // write  HELP-FLAGS  
	L_w += fWRITE( F, &HAVE_ScaleStruct, char, 1, &N_w, &err );    if(err)return(L_w); // EXIT ON ERROR
	L_w += fWRITE( F, &HAVE_StatStruct,  char, 1, &N_w, &err );    if(err)return(L_w); // EXIT ON ERROR

	// write  LENGTH:  L_Name,  L_Unit,  L_Descr
	L_w += fWRITE( F, &L_Name,  short, 1, &N_w, &err );    if(err)return(L_w); // EXIT ON ERROR	
	L_w += fWRITE( F, &L_Unit,  short, 1, &N_w, &err );    if(err)return(L_w); // EXIT ON ERROR	
	L_w += fWRITE( F, &L_Descr, short, 1, &N_w, &err );   if(err)return(L_w); // EXIT ON ERROR	
    	
	// write  LENGTH:  L_ID,  L_Index,  L_Flag,  L_Para
	L_w += fWRITE( F, &(*BaseProp)->L_ID,    unsigned short, 1, &N_w, &err );    if(err)return(L_w); // EXIT ON ERROR	
	L_w += fWRITE( F, &(*BaseProp)->L_Index, unsigned short, 1, &N_w, &err );    if(err)return(L_w); // EXIT ON ERROR	
	L_w += fWRITE( F, &(*BaseProp)->L_Flag,  unsigned short, 1, &N_w, &err );    if(err)return(L_w); // EXIT ON ERROR	
	L_w += fWRITE( F, &(*BaseProp)->L_Para,  unsigned short, 1, &N_w, &err );    if(err)return(L_w); // EXIT ON ERROR	
		
    // write  ID[],  Index[],  Flag[]
	L_w += fWRITE( F, (*BaseProp)->ID,    long, (*BaseProp)->L_ID, &N_w, &err );    if(err)return(L_w); // EXIT ON ERROR
	L_w += fWRITE( F, (*BaseProp)->Index, long, (*BaseProp)->L_Index, &N_w, &err );    if(err)return(L_w); // EXIT ON ERROR
	L_w += fWRITE( F, (*BaseProp)->Flag, short, (*BaseProp)->L_Flag, &N_w, &err );    if(err)return(L_w); // EXIT ON ERROR
	
	// write STRINGS:  Name[],  Unit[],  Descr[]
	if( L_Name > 0 ) {
		L_w += fWRITE( F, (*BaseProp)->Name, char, L_Name, &N_w, &err );    if(err)return(L_w); // EXIT ON ERROR
	}
	if( L_Unit > 0 ) {
		L_w += fWRITE( F, (*BaseProp)->Unit, char, L_Unit, &N_w, &err );    if(err)return(L_w); // EXIT ON ERROR
	}
	if( L_Descr > 0 ) {
		L_w += fWRITE( F, (*BaseProp)->Descr, char, L_Descr, &N_w, &err );    if(err)return(L_w); // EXIT ON ERROR
	}
	
	// write  Scale		
	if( HAVE_ScaleStruct ) {		
	 //	L_w += WriteScaleStruct( F, &(*BaseProp)->Scale, &err );    if(err)return(L_w); // EXIT ON ERROR		
	}	

	// write  Stat		
	if( HAVE_StatStruct ) {	
	 //	L_w += WriteStatStruct( F, &(*BaseProp)->Stat, &err );    if(err)return(L_w); // EXIT ON ERROR					
	}	

	if( (*BaseProp)->L_Para > 0 ) {
		for(i=0; i<(*BaseProp)->L_Para; i++) {
		 //	L_w += WriteParaStruct( F, &(*BaseProp)->Para[i], &err );    if(err)return(L_w); // EXIT ON ERROR					
		} 
	}
		
	*E = 0; // indicate SUCCESS
	
	return(L_w);
} // WriteBaseProp	


int
IniEntityProp( TpointerEntityProp  EntityProp ) {
	
	int E = -1; // indicate FAILURE
	
	if( EntityProp == NULL )return(E); // EXIT ON ERROR	
	
    EntityProp->Base = NULL;
	EntityProp->Ref  = NULL;
			
	E = 0; // indicate SUCCESS
	return(E);	
} // IniEntityProp	             

int
CreateEntityProp ( TpointerEntityProp *EntityProp ) {
	if( !(*EntityProp = Xmalloc( EntityProp_t , 1 )) )return(-1);
	IniEntityProp( *EntityProp );
	return(0);
}

int
DestroyEntityProp ( TpointerEntityProp *EntityProp) // properties of ONE SERIES
{   			 
	if( *EntityProp != NULL ) { 	
		DestroyBaseProp( &((*EntityProp)->Base) );
		DestroyUniStruct( &((*EntityProp)->Ref) );		
		free(*EntityProp);   *EntityProp = NULL;			
	}
	return(0);
}; 



int
IniGroupProp( TpointerGroupProp  GroupProp ) {
	
	int E = -1; // indicate FAILURE
	int i;
	
	if( GroupProp == NULL )return(E); // EXIT ON ERROR	
	
	for(i=0; i<6; i++) GroupProp->TimeStamp[i] = -1;   // yyyy.mm.dd hh.nn.ss
	GroupProp->FileName = NULL;
	GroupProp->Title    = NULL;

    GroupProp->Base   = NULL;	
	GroupProp->Shared = NULL; // array holding the properties of each series contained in the set
	
	E = 0; // indicate SUCCESS
	return(E);	
} // IniDataSetProp	             

int
CreateGroupProp ( TpointerGroupProp *GroupProp ) {
	if( !(*GroupProp = Xmalloc( GroupProp_t , 1 )) )return(-1);
	IniGroupProp( *GroupProp );
	return(0);
}

int
DestroyGroupProp ( TpointerGroupProp *GroupProp ) // properties of ONE group element
{   			 
	if( *GroupProp != NULL ) { 	
		DestroyBaseProp  ( &((*GroupProp)->Base) );
		DestroyEntityProp( &((*GroupProp)->Shared) );
		free(*GroupProp);   *GroupProp = NULL;			
	}
	return(0);
}; 

u_long_t
ReadGroupProp( FILE* F, TpointerGroupProp *GroupProp, int *E ) {
	
	u_long_t  L_r = 0;  // accumulated number of BYTES read from file
	
	short  L_FileName, L_Title;
	size_t     N_r;
	int HAVE_BaseProp   = 0;
	int HAVE_SharedProp = 0;
	int err = 0;
	
	
	*E = -1; // raise ERROR flag
	
	if( F == NULL )return(L_r); // EXIT ON ERROR	
	if( GroupProp == NULL )return(L_r); // EXIT ON ERROR	
	if( *GroupProp == NULL )return(L_r); // EXIT ON ERROR	
    
    // read  TimeStamp[6]
	L_r += fREAD( F, (*GroupProp)->TimeStamp, short, 6, &N_r, &err );    if(err)return(L_r); // EXIT ON ERROR
	
	// read  L_FileName  +  FileName[]	
	L_r += fREAD( F, &L_FileName, short, 1, &N_r, &err );    if(err)return(L_r); // EXIT ON ERROR	
	if( L_FileName > 0 ) {
		str_Nini( &((*GroupProp)->FileName) , (long)(L_FileName + 1) ); // L_FNme + terminating 0
		L_r += fREAD( F, (*GroupProp)->FileName, char, L_FileName, &N_r, &err );    if(err)return(L_r); // EXIT ON ERROR
	}else{ // <= 0
		if( (*GroupProp)->FileName != NULL ) { 
			free((*GroupProp)->FileName);    (*GroupProp)->FileName = NULL; 
		}
	}		
	// read  L_Title  +  Title[]	
	L_r += fREAD( F, &L_Title, short, 1, &N_r, &err );    if(err)return(L_r); // EXIT ON ERROR	
	if( L_Title > 0 ) {
		str_Nini( &((*GroupProp)->Title) , (long)(L_Title + 1) ); // L_Title + terminating 0
		L_r += fREAD( F, (*GroupProp)->Title, char, L_Title, &N_r, &err );    if(err)return(L_r); // EXIT ON ERROR
	}else{ // <= 0
		if( (*GroupProp)->Title != NULL ) { 
			free((*GroupProp)->Title);    (*GroupProp)->Title = NULL; 
		}
	}		
	
	if( (*GroupProp)->Base  != NULL ) {
		 if( DestroyBaseProp( &((*GroupProp)->Base) ) )return(L_r); // EXIT ON ERROR
	}	 
	if( (*GroupProp)->Shared!= NULL ) {
		if( DestroyEntityProp( &((*GroupProp)->Shared) ) )return(L_r); // EXIT ON ERROR
	}	
    
    // read  FLAGS  
	L_r += fREAD( F, &HAVE_BaseProp,   char, 1, &N_r, &err );    if(err)return(L_r); // EXIT ON ERROR
	L_r += fREAD( F, &HAVE_SharedProp, char, 1, &N_r, &err );    if(err)return(L_r); // EXIT ON ERROR
	
	if( HAVE_BaseProp ) {		
		if( CreateBaseProp( &((*GroupProp)->Base) ) )return(L_r); // EXIT ON ERROR
	 	L_r += ReadBaseProp( F, &(*GroupProp)->Base, &err );    if(err)return(L_r); // EXIT ON ERROR		
	}	

	if( HAVE_SharedProp ) {	// --> RECURSIVE STRUCTURE !!
	 // if( CreateEntityProp( &((*GroupProp)->Shared) ) )return(L_r); // EXIT ON ERROR
	 //	L_r += ReadEntityProp( F, &(*GroupProp)->Shared, &err );    if(err)return(L_r); // EXIT ON ERROR					
	}	
		
	*E = 0; // indicate SUCCESS
	
	return(L_r);
} // ReadGroupProp	

u_long_t
WriteGroupProp( FILE* F, TpointerGroupProp *GroupProp, int *E ) {
	
	u_long_t  L_w = 0;  // accumulated number of BYTES written
	
	short  L_FileName, L_Title;
	size_t     N_w;
	int HAVE_BaseProp, HAVE_SharedProp;
	int err;
	
	
	*E = -1; // raise ERROR flag
	
	if( F == NULL )return(L_w); // EXIT ON ERROR	
	if( GroupProp == NULL )return(L_w); // EXIT ON ERROR	
	if( *GroupProp == NULL )return(L_w); // EXIT ON ERROR	

	if( (*GroupProp)->Base  == NULL ) HAVE_BaseProp   = 0; else HAVE_BaseProp   = 1;	
	if( (*GroupProp)->Shared== NULL ) HAVE_SharedProp = 0; else HAVE_SharedProp = 1;	
    
    
    // write  TimeStamp[6]
	L_w += fWRITE( F, (*GroupProp)->TimeStamp, short, 6, &N_w, &err );    if(err)return(L_w); // EXIT ON ERROR
	
	// write  L_FileName  +  FileName[]
	L_FileName = (short) str_len ( (*GroupProp)->FileName );
	if( L_FileName < 0 ) L_FileName = 0;
	L_w += fWRITE( F, &L_FileName, short, 1, &N_w, &err );    if(err)return(L_w); // EXIT ON ERROR	
	if( L_FileName > 0 ) {
		L_w += fWRITE( F, (*GroupProp)->FileName, char, L_FileName, &N_w, &err );    if(err)return(L_w); // EXIT ON ERROR
	}
    // write  L_Title  +  Title[]
	L_Title = (short) str_len ( (*GroupProp)->Title );
	if( L_Title < 0 ) L_Title = 0;
	L_w += fWRITE( F, &L_Title, short, 1, &N_w, &err );    if(err)return(L_w); // EXIT ON ERROR	
	if( L_Title > 0 ) {
		L_w += fWRITE( F, (*GroupProp)->Title, char, L_Title, &N_w, &err );    if(err)return(L_w); // EXIT ON ERROR
	}
	
    // write  FLAGS  
	L_w += fWRITE( F, &HAVE_BaseProp,   char, 1, &N_w, &err );    if(err)return(L_w); // EXIT ON ERROR
	L_w += fWRITE( F, &HAVE_SharedProp, char, 1, &N_w, &err );    if(err)return(L_w); // EXIT ON ERROR
	
	if( HAVE_BaseProp ) {		
	 	L_w += WriteBaseProp( F, &(*GroupProp)->Base, &err );    if(err)return(L_w); // EXIT ON ERROR		
	}	

	if( HAVE_SharedProp ) {	// --> RECURSIVE STRUCTURE !!
	 //	L_w += WriteEntityProp( F, &(*GroupProp)->Shared, &err );    if(err)return(L_w); // EXIT ON ERROR					
	}	
		
	*E = 0; // indicate SUCCESS
	
	return(L_w);
} // WriteGroupProp	


int
IniUniStruct ( TpointerUniStruct UNI ) {
	
	int E = -1; // indicate FAILURE

	if( UNI == NULL )return(E); // EXIT ON ERROR	

	UNI->Size =  0;
	
	UNI->dType = 0;   
 	UNI->pType = 0;   
 	//UNI->vDim  = 0;    UNI->vSize = NULL;
	
	   
	UNI->d = NULL;
	UNI->p = NULL;
	E = 0; // indicate SUCCESS
	return(E);
} // IniUniStruct

int
CreateUniStruct ( TpointerUniStruct *UNI,  unsigned long Size,  short dType,  short pType ) {
   return( CreateResizeUniStruct ( 1 , UNI, Size, dType, pType ) );	
}	

int
ResizeUniStruct ( TpointerUniStruct *UNI,  unsigned long Size ) {
   short dType_dummy = -1;
   short pType_dummy = -1;	
   return( CreateResizeUniStruct ( 0 , UNI, Size, dType_dummy, pType_dummy ) );	
}	

static int
CreateResizeUniStruct (int CREATE,  TpointerUniStruct *UNI,  unsigned long Size,  short dType,  short pType ) {
	
	int E = -1; // indicate FAILURE
	//int i;
	unsigned long L, N_D, N_D_prev;
	
	// CHECK ACTUAL ARGUMENTS
	if( UNI == NULL )return(E);	// EXIT ON ERROR	
	if(CREATE) { // the type has already been checked at creation
		if( !dType_SUPPORTED(dType) )return(E); // EXIT ON ERROR
		if( !pType_SUPPORTED(pType) )return(E); // EXIT ON ERROR
	}
	//if( vDim < 0 )return(E);        // EXIT ON ERROR
	//if( vSize == NULL )return(E);   // EXIT ON ERROR
	//for(i=0; i<vDim; i++) if(!vSize[i])return(E);   // EXIT ON ERROR

	if(CREATE) {		
		if( *UNI == NULL ) {
			 if( !(*UNI = Xmalloc( UniStruct_t, 1 )) )return(E);  // EXIT ON ERROR
		}
		IniUniStruct ( *UNI );
		
	 	(*UNI)->Size  = Size;
	 	
		(*UNI)->dType = dType;   
	 	(*UNI)->pType = pType;   
	 	//(*UNI)->vDim  = vDim;   
	 	//(*UNI)->vSize = Xmalloc( unsigned long, vDim );    if( !((*UNI)->vSize) )return(E); //EXIT ON ERROR	 	              
	 	
	}else{ // RESIZE
		if( *UNI == NULL )return(E); // EXIT ON ERROR --> UniStruct not existing !
		
		N_D_prev = (*UNI)->Size; 
		
		dType = (*UNI)->dType;
		pType = (*UNI)->pType;
		
	 	//N_D_prev = (*UNI)->vSize[0];  for(i=1; i<(*UNI)->vDim; i++) N_D_prev = N_D_prev * (*UNI)->vSize[i];
	 	
		//(*UNI)->vDim  = vDim;   
	 	//(*UNI)->vSize = Xrealloc( unsigned long,(*UNI)->vSize, vDim );    if( !((*UNI)->vSize) )return(E); //EXIT ON ERROR	 	              		
	}
		              
 	//for(i=0; i<vDim; i++) (*UNI)->vSize[i] = vSize[i]; 	
 	
 	// calculate number of elements  N_D  from 'virtual' dimension sizes
 	//N_D = vSize[0];  for(i=1; i<vDim; i++) N_D = N_D * vSize[i];
 	
 	N_D = Size;
 	
 	if(CREATE) {
	 	// allocate memory for DATA UNION
	 	if( !((*UNI)->d = Xmalloc( UniData_t, 1 )) )return(E); //EXIT ON ERROR
	    (*UNI)->d->Obj = NULL; // only set 1st member to initialize a union !
	
	 	// allocate memory for PROPERTY UNION    
	 	if( !((*UNI)->p = Xmalloc( UniProp_t, 1 )) )return(E); //EXIT ON ERROR
	    (*UNI)->p->Obj = NULL; // only set 1st member to initialize a union !
 	}
 	     	
 // - - - - - - - - - -   BEGIN SWITCH  D A T A  TYPE   - - - - - - - - - -	
	switch( dType ) {

		case e_T_MATRIX_DATA:    
			if(CREATE) {   
				if( !((*UNI)->d->Mat = Xmalloc( TpointerUniStruct, N_D )) )return(E); // EXIT ON ERROR
			    for(L=0; L<N_D; L++){
	 				 if( !((*UNI)->d->Mat[L] = Xmalloc( UniStruct_t, 1 )) )return(E);
			    	 IniUniStruct(  (*UNI)->d->Mat[L]  );             
			    }	 
			}else{ // RESIZE
				if(N_D < N_D_prev) {
					for(L=N_D; L<N_D_prev; L++){
 				 		if(  DestroyUniStruct( &((*UNI)->d->Mat[L]) )  )return(E);
		    		}	 					
				}	

				if( !((*UNI)->d->Mat = Xrealloc( TpointerUniStruct, (*UNI)->d->Mat, N_D )) )return(E); // EXIT ON ERROR
				
			    for(L=N_D_prev; L<N_D; L++){ // only if   N_D > N_D_prev 
	 				 if( !((*UNI)->d->Mat[L] = Xmalloc( UniStruct_t, 1 )) )return(E);
			    	 IniUniStruct(  (*UNI)->d->Mat[L]  );             
			    }	 				
			}
		break;

			case e_T_VECTOR_DATA:    
			    if(CREATE) {
					if( !((*UNI)->d->Vec = Xmalloc( TpointerUniStruct, N_D )) )return(E); // EXIT ON ERROR
				    for(L=0; L<N_D; L++){
		 				if( !((*UNI)->d->Vec[L] = Xmalloc( UniStruct_t, 1 )) )return(E);
				    	IniUniStruct(  (*UNI)->d->Vec[L]  );             
				    }	 
				}else{ 
					if(N_D < N_D_prev) {
						for(L=N_D; L<N_D_prev; L++){
	 				 		if(  DestroyUniStruct( &((*UNI)->d->Vec[L]) )  )return(E);
			    		}	 					
					}	
					
					if( !((*UNI)->d->Vec = Xrealloc( TpointerUniStruct, (*UNI)->d->Vec, N_D )) )return(E); // EXIT ON ERROR
				    for(L=N_D_prev; L<N_D; L++){ // only if   N_D > N_D_prev 
		 				 if( !((*UNI)->d->Vec[L] = Xmalloc( UniStruct_t, 1 )) )return(E);
				    	 IniUniStruct(  (*UNI)->d->Vec[L]  );             
				    }	 				
				}				    
			break;
		
		
		case e_T_OBJECT_DATA:    
			if(CREATE) {   
				if( !((*UNI)->d->Obj = Xmalloc( TpointerUniStruct, N_D )) )return(E); // EXIT ON ERROR
			    for(L=0; L<N_D; L++){
	 				 if( !((*UNI)->d->Obj[L] = Xmalloc( UniStruct_t, 1 )) )return(E);
			    	 IniUniStruct(  (*UNI)->d->Obj[L]  );             
			    }	 
			}else{ // RESIZE
				if(N_D < N_D_prev) {
					for(L=N_D; L<N_D_prev; L++){
 				 		if(  DestroyUniStruct( &((*UNI)->d->Obj[L]) )  )return(E);
		    		}	 					
				}	

				if( !((*UNI)->d->Obj = Xrealloc( TpointerUniStruct, (*UNI)->d->Obj, N_D )) )return(E); // EXIT ON ERROR
				
			    for(L=N_D_prev; L<N_D; L++){ // only if   N_D > N_D_prev 
	 				 if( !((*UNI)->d->Obj[L] = Xmalloc( UniStruct_t, 1 )) )return(E);
			    	 IniUniStruct(  (*UNI)->d->Obj[L]  );             
			    }	 				
			}
		break;

			case e_T_ITEM_DATA:    
			    if(CREATE) {
					if( !((*UNI)->d->Item = Xmalloc( TpointerUniStruct, N_D )) )return(E); // EXIT ON ERROR
				    for(L=0; L<N_D; L++){
		 				if( !((*UNI)->d->Item[L] = Xmalloc( UniStruct_t, 1 )) )return(E);
				    	IniUniStruct(  (*UNI)->d->Item[L]  );             
				    }	 
				}else{ 
					if(N_D < N_D_prev) {
						for(L=N_D; L<N_D_prev; L++){
	 				 		if(  DestroyUniStruct( &((*UNI)->d->Item[L]) )  )return(E);
			    		}	 					
					}	
					
					if( !((*UNI)->d->Item = Xrealloc( TpointerUniStruct, (*UNI)->d->Item, N_D )) )return(E); // EXIT ON ERROR
				    for(L=N_D_prev; L<N_D; L++){ // only if   N_D > N_D_prev 
		 				 if( !((*UNI)->d->Item[L] = Xmalloc( UniStruct_t, 1 )) )return(E);
				    	 IniUniStruct(  (*UNI)->d->Item[L]  );             
				    }	 				
				}				    
			break;
		
		
		case e_T_DATASET_DATA:    
			if(CREATE) {   
				if( !((*UNI)->d->DSet = Xmalloc( TpointerUniStruct, N_D )) )return(E); // EXIT ON ERROR
			    for(L=0; L<N_D; L++){
	 				if( !((*UNI)->d->DSet[L] = Xmalloc( UniStruct_t, 1 )) )return(E);
			    	IniUniStruct(  (*UNI)->d->DSet[L]  );             
			    }	 
			}else{ // RESIZE
				if(N_D < N_D_prev) {
					for(L=N_D; L<N_D_prev; L++){
 				 		if(  DestroyUniStruct( &((*UNI)->d->DSet[L]) )  )return(E);
		    		}	 					
				}	

				if( !((*UNI)->d->DSet = Xrealloc( TpointerUniStruct, (*UNI)->d->DSet, N_D )) )return(E); // EXIT ON ERROR
				
			    for(L=N_D_prev; L<N_D; L++){ // only if   N_D > N_D_prev 
	 				 if( !((*UNI)->d->DSet[L] = Xmalloc( UniStruct_t, 1 )) )return(E);
			    	 IniUniStruct(  (*UNI)->d->DSet[L]  );             
			    }	 				
			}
		break;

			case e_T_SERIES_DATA:    
				if(CREATE) {   
					if( !((*UNI)->d->Ser = Xmalloc( TpointerUniStruct, N_D )) )return(E); // EXIT ON ERROR
				    for(L=0; L<N_D; L++){
		 				if( !((*UNI)->d->Ser[L] = Xmalloc( UniStruct_t, 1 )) )return(E);
				    	IniUniStruct(  (*UNI)->d->Ser[L]  );             
				    }	 
				}else{ // RESIZE
					if(N_D < N_D_prev) {
						for(L=N_D; L<N_D_prev; L++){
	 				 		if(  DestroyUniStruct( &((*UNI)->d->Ser[L]) )  )return(E);
			    		}	 					
					}	
	
					if( !((*UNI)->d->Ser = Xrealloc( TpointerUniStruct, (*UNI)->d->Ser, N_D )) )return(E); // EXIT ON ERROR
					
				    for(L=N_D_prev; L<N_D; L++){ // only if   N_D > N_D_prev 
		 				 if( !((*UNI)->d->Ser[L] = Xmalloc( UniStruct_t, 1 )) )return(E);
				    	 IniUniStruct(  (*UNI)->d->Ser[L]  );             
				    }	 				
				}
			break;

	 // ELEMENTARY DATA-TYPES:  1 - DIMENSIONAL ARRAYS OF GENERIC C-TYPES
	 	  
		case e_T_CHAR:    
		    if(CREATE) {
				if( !((*UNI)->d->Xc = Xmalloc( char, N_D )) )return(E); // EXIT ON ERROR
			    for(L=0; L<N_D; L++) (*UNI)->d->Xc[L] = 0;  		    
		    }else{ // RESIZE
				if( !((*UNI)->d->Xc = Xrealloc( char, (*UNI)->d->Xc, N_D )) )return(E); // EXIT ON ERROR
			    for(L=N_D_prev; L<N_D; L++) (*UNI)->d->Xc[L] = 0;  		    
		    }    
		break;

		case e_T_UCHAR:    
		    if(CREATE) {
				if( !((*UNI)->d->Xuc = Xmalloc( unsigned char, N_D )) )return(E); // EXIT ON ERROR
			    for(L=0; L<N_D; L++) (*UNI)->d->Xuc[L] = 0; 
		    }else{ // RESIZE
				if( !((*UNI)->d->Xuc = Xrealloc( char, (*UNI)->d->Xuc, N_D )) )return(E); // EXIT ON ERROR
			    for(L=N_D_prev; L<N_D; L++) (*UNI)->d->Xuc[L] = 0;  		    
		    }    
		break;
		
		case e_T_SHORT:    
		    if(CREATE) {
				if( !((*UNI)->d->Xs = Xmalloc( short, N_D )) )return(E); // EXIT ON ERROR
			    for(L=0; L<N_D; L++) (*UNI)->d->Xs[L] = 0; 
		    }else{ // RESIZE
				if( !((*UNI)->d->Xs = Xrealloc( short, (*UNI)->d->Xs, N_D )) )return(E); // EXIT ON ERROR
			    for(L=N_D_prev; L<N_D; L++) (*UNI)->d->Xs[L] = 0;  		    
		    }    
		break;

		case e_T_USHORT:    
		    if(CREATE) {
				if( !((*UNI)->d->Xus = Xmalloc( unsigned short, N_D )) )return(E); // EXIT ON ERROR
			    for(L=0; L<N_D; L++) (*UNI)->d->Xus[L] = 0;
		    }else{ // RESIZE
				if( !((*UNI)->d->Xus = Xrealloc( unsigned short, (*UNI)->d->Xus, N_D )) )return(E); // EXIT ON ERROR
			    for(L=N_D_prev; L<N_D; L++) (*UNI)->d->Xus[L] = 0;  		    
		    }    
		break;
		
		case e_T_INT:    
		    if(CREATE) {
				if( !((*UNI)->d->Xi = Xmalloc( int, N_D )) )return(E); // EXIT ON ERROR
			    for(L=0; L<N_D; L++) (*UNI)->d->Xi[L] = 0; 
		    }else{ // RESIZE
				if( !((*UNI)->d->Xi = Xrealloc( int, (*UNI)->d->Xi, N_D )) )return(E); // EXIT ON ERROR
			    for(L=N_D_prev; L<N_D; L++) (*UNI)->d->Xi[L] = 0;  		    
		    }    			    
		break;

		case e_T_UINT:    
		    if(CREATE) {
				if( !((*UNI)->d->Xui = Xmalloc( unsigned int, N_D )) )return(E); // EXIT ON ERROR
			    for(L=0; L<N_D; L++) (*UNI)->d->Xui[L] = 0;
		    }else{ // RESIZE
				if( !((*UNI)->d->Xui = Xrealloc( unsigned int, (*UNI)->d->Xui, N_D )) )return(E); // EXIT ON ERROR
			    for(L=N_D_prev; L<N_D; L++) (*UNI)->d->Xui[L] = 0;  		    
		    }    			    			    
		break;

		case e_T_LONG:    
		    if(CREATE) {
				if( !((*UNI)->d->Xl = Xmalloc( long, N_D )) )return(E); // EXIT ON ERROR
			    for(L=0; L<N_D; L++) (*UNI)->d->Xl[L] = 0; 
		    }else{ // RESIZE
				if( !((*UNI)->d->Xl = Xrealloc( long, (*UNI)->d->Xl, N_D )) )return(E); // EXIT ON ERROR
			    for(L=N_D_prev; L<N_D; L++) (*UNI)->d->Xl[L] = 0;  		    
		    }    			    			    
		break;

		case e_T_ULONG:    
		    if(CREATE) {
				if( !((*UNI)->d->Xul = Xmalloc( unsigned long, N_D )) )return(E); // EXIT ON ERROR
			    for(L=0; L<N_D; L++) (*UNI)->d->Xul[L] = 0;
		    }else{ // RESIZE
				if( !((*UNI)->d->Xul = Xrealloc( unsigned long, (*UNI)->d->Xul, N_D )) )return(E); // EXIT ON ERROR
			    for(L=N_D_prev; L<N_D; L++) (*UNI)->d->Xul[L] = 0;  		    
		    }    			    			    
		break;

		case e_T_FLOAT:    
		    if(CREATE) {
				if( !((*UNI)->d->Xf = Xmalloc( float, N_D )) )return(E); // EXIT ON ERROR
			    for(L=0; L<N_D; L++) (*UNI)->d->Xf[L] = 0.0; 
		    }else{ // RESIZE
				if( !((*UNI)->d->Xf = Xrealloc( float, (*UNI)->d->Xf, N_D )) )return(E); // EXIT ON ERROR
			    for(L=N_D_prev; L<N_D; L++) (*UNI)->d->Xf[L] = 0;  		    
		    }    			    			    
		break;

		case e_T_DOUBLE:    
		    if(CREATE) {
				if( !((*UNI)->d->Xd = Xmalloc( double, N_D )) )return(E); // EXIT ON ERROR
			    for(L=0; L<N_D; L++) (*UNI)->d->Xd[L] = 0.0; 
		    }else{ // RESIZE
				if( !((*UNI)->d->Xd = Xrealloc( double, (*UNI)->d->Xd, N_D )) )return(E); // EXIT ON ERROR
			    for(L=N_D_prev; L<N_D; L++) (*UNI)->d->Xd[L] = 0;  		    
		    }    			    			    
		break;

		case e_T_LONG_DOUBLE:    
		    if(CREATE) {
				if( !((*UNI)->d->Xld = Xmalloc( long double, N_D )) )return(E); // EXIT ON ERROR
			    for(L=0; L<N_D; L++) (*UNI)->d->Xld[L] = 0.0; 
		    }else{ // RESIZE
				if( !((*UNI)->d->Xld = Xrealloc( long double, (*UNI)->d->Xld, N_D )) )return(E); // EXIT ON ERROR
			    for(L=N_D_prev; L<N_D; L++) (*UNI)->d->Xld[L] = 0;  		    
		    }    			    			    
		break;
		
	} // switch( Dtype )
 // - - - - - - - - - -   END SWITCH  D A T A  TYPE   - - - - - - - - - -	
	
	
 // - - - - - - - - - -   BEGIN SWITCH  P R O P E R T Y  TYPE   - - - - - - - - - -	
	switch( pType ) {

		case e_T_NO_PROP: // free  UniProp_t 'p'     
			free( (*UNI)->p );   (*UNI)->p = NULL;
		break;

		case e_T_MATRIX_PROP:    
			if(CREATE) {
				if( !((*UNI)->p->Mat = Xmalloc( TpointerGroupProp, N_D )) )return(E); // EXIT ON ERROR
			    for(L=0; L<N_D; L++) {
			    	if( CreateGroupProp( &((*UNI)->p->Mat[L]) ) )return(E); // EXIT ON ERROR     	
			    }	 
			}else{ // RESIZE
				if(N_D < N_D_prev) {
					for(L=N_D; L<N_D_prev; L++){
						if(  DestroyGroupProp( &((*UNI)->p->Mat[L]) )  )return(E);						
		    		}	 					
				}	

				if( !((*UNI)->p->Mat = Xrealloc( TpointerGroupProp, (*UNI)->p->Mat, N_D )) )return(E); // EXIT ON ERROR
				
			    for(L=N_D_prev; L<N_D; L++){ // only if   N_D > N_D_prev 
			    	if( CreateGroupProp( &((*UNI)->p->Mat[L]) ) )return(E); // EXIT ON ERROR     	
			    }	 				
			}		    
		break;

			case e_T_VECTOR_PROP:    
				if(CREATE) {   
					if( !((*UNI)->p->Vec = Xmalloc( TpointerEntityProp, N_D )) )return(E); // EXIT ON ERROR
				    for(L=0; L<N_D; L++) {
				    	if( CreateEntityProp( &((*UNI)->p->Vec[L]) ) )return(E); // EXIT ON ERROR     				    	
				    }	
				}else{ // RESIZE
					if(N_D < N_D_prev) {
						for(L=N_D; L<N_D_prev; L++){
							if(  DestroyEntityProp( &((*UNI)->p->Vec[L]) )  )return(E);						
			    		}	 					
					}	
	
					if( !((*UNI)->p->Vec = Xrealloc( TpointerEntityProp, (*UNI)->p->Vec, N_D )) )return(E); // EXIT ON ERROR
					
				    for(L=N_D_prev; L<N_D; L++){ // only if   N_D > N_D_prev 
				    	if( CreateEntityProp( &((*UNI)->p->Vec[L]) ) )return(E); // EXIT ON ERROR     	
				    }	 				
				}		    				    
			break;
		
		
		case e_T_OBJECT_PROP:    
			if(CREATE) {
				if( !((*UNI)->p->Obj = Xmalloc( TpointerGroupProp, N_D )) )return(E); // EXIT ON ERROR
			    for(L=0; L<N_D; L++) {
			    	if( CreateGroupProp( &((*UNI)->p->Obj[L]) ) )return(E); // EXIT ON ERROR     	
			    }	 
			}else{ // RESIZE
				if(N_D < N_D_prev) {
					for(L=N_D; L<N_D_prev; L++){
						if(  DestroyGroupProp( &((*UNI)->p->Obj[L]) )  )return(E);						
		    		}	 					
				}	

				if( !((*UNI)->p->Obj = Xrealloc( TpointerGroupProp, (*UNI)->p->Obj, N_D )) )return(E); // EXIT ON ERROR
				
			    for(L=N_D_prev; L<N_D; L++){ // only if   N_D > N_D_prev 
			    	if( CreateGroupProp( &((*UNI)->p->Obj[L]) ) )return(E); // EXIT ON ERROR     	
			    }	 				
			}		    
		break;

			case e_T_ITEM_PROP:    
				if(CREATE) {   
					if( !((*UNI)->p->Item = Xmalloc( TpointerEntityProp, N_D )) )return(E); // EXIT ON ERROR
				    for(L=0; L<N_D; L++) {
				    	if( CreateEntityProp( &((*UNI)->p->Item[L]) ) )return(E); // EXIT ON ERROR     				    	
				    }	
				}else{ // RESIZE
					if(N_D < N_D_prev) {
						for(L=N_D; L<N_D_prev; L++){
							if(  DestroyEntityProp( &((*UNI)->p->Item[L]) )  )return(E);						
			    		}	 					
					}	
	
					if( !((*UNI)->p->Item = Xrealloc( TpointerEntityProp, (*UNI)->p->Item, N_D )) )return(E); // EXIT ON ERROR
					
				    for(L=N_D_prev; L<N_D; L++){ // only if   N_D > N_D_prev 
				    	if( CreateEntityProp( &((*UNI)->p->Item[L]) ) )return(E); // EXIT ON ERROR     	
				    }	 				
				}		    				    
			break;
		
		
		case e_T_DATASET_PROP:  
		    if(CREATE) {  
				if( !((*UNI)->p->DSet = Xmalloc( TpointerGroupProp, N_D )) )return(E); // EXIT ON ERROR
			    for(L=0; L<N_D; L++){
			    	if( CreateGroupProp( &((*UNI)->p->DSet[L]) ) )return(E); // EXIT ON ERROR     				    	
			    }	 
			}else{ // RESIZE
				if(N_D < N_D_prev) {
					for(L=N_D; L<N_D_prev; L++){
						if(  DestroyGroupProp( &((*UNI)->p->DSet[L]) )  )return(E);						
		    		}	 					
				}	

				if( !((*UNI)->p->DSet = Xrealloc( TpointerGroupProp, (*UNI)->p->DSet, N_D )) )return(E); // EXIT ON ERROR
				
			    for(L=N_D_prev; L<N_D; L++){ // only if   N_D > N_D_prev 
			    	if( CreateGroupProp( &((*UNI)->p->DSet[L]) ) )return(E); // EXIT ON ERROR     	
			    }	 				
			}		    				    			    
		break;

			case e_T_SERIES_PROP:    
				if(CREATE) {
					if( !((*UNI)->p->Ser = Xmalloc( TpointerEntityProp, N_D )) )return(E); // EXIT ON ERROR
				    for(L=0; L<N_D; L++){
			    		if( CreateEntityProp( &((*UNI)->p->Ser[L]) ) )return(E); // EXIT ON ERROR     				    			    		
				    }			    			    			    	 
				}else{ // RESIZE
					if(N_D < N_D_prev) {
						for(L=N_D; L<N_D_prev; L++){
							if(  DestroyEntityProp( &((*UNI)->p->Ser[L]) )  )return(E);						
			    		}	 					
					}	
	
					if( !((*UNI)->p->Ser = Xrealloc( TpointerEntityProp, (*UNI)->p->Ser, N_D )) )return(E); // EXIT ON ERROR
					
				    for(L=N_D_prev; L<N_D; L++){ // only if   N_D > N_D_prev 
			    		if( CreateEntityProp( &((*UNI)->p->Ser[L]) ) )return(E); // EXIT ON ERROR     	
				    }	 				
				}		    				    			    
			break; 

		case e_T_BASE_PROP:    
		    if(CREATE) {
				if( !((*UNI)->p->Xp = Xmalloc( TpointerBaseProp, N_D )) )return(E); // EXIT ON ERROR
			    for(L=0; L<N_D; L++) {
			    	if( CreateBaseProp( &((*UNI)->p->Xp[L]) ) )return(E); // EXIT ON ERROR     	
			    }	 
			}else{ // RESIZE
				if(N_D < N_D_prev) {
					for(L=N_D; L<N_D_prev; L++){
						if(  DestroyBaseProp( &((*UNI)->p->Xp[L]) )  )return(E);						
		    		}	 					
				}	

				if( !((*UNI)->p->Xp = Xrealloc( TpointerBaseProp, (*UNI)->p->Xp, N_D )) )return(E); // EXIT ON ERROR
				
			    for(L=N_D_prev; L<N_D; L++){ // only if   N_D > N_D_prev 
			    	if( CreateBaseProp( &((*UNI)->p->Xp[L]) ) )return(E); // EXIT ON ERROR     	
			    }	 				
			}		    
		break;
					 
	} // switch( Ptype )
 // - - - - - - - - - -   END SWITCH  P R O P E R T Y  TYPE   - - - - - - - - - -	

	if(CREATE) {		
		// nothing
	}else{ // RESIZE
	 	(*UNI)->Size  = Size; // set Uni.Size to actual size (remember: Size = N_D !)
	}
	
	E = 0;  // indicate SUCCESS;
	return(E);
} // CreateUniStruct	


int
DestroyUniStruct ( TpointerUniStruct *UNI ) {
	
	int E = -1; // indicate FAILURE
	//int i;
	unsigned long L, N_D;

	// does the !pointer! to UniStruct exist ?	
	if( UNI == NULL ) { // if not --> then we're finished
		E = 0;   return(E);  // indicate SUCCESS
	}

	// does UniStruct exist ?	
	if( *UNI == NULL ) { // if not --> then we're finished
		E = 0;   return(E);  // indicate SUCCESS
	}
	
	//N_D = (*UNI)->vSize[0];  for(i=1; i<(*UNI)->vDim; i++) N_D = N_D * (*UNI)->vSize[i];

	N_D = (*UNI)->Size;
	
	 // - - - - - - - - - -   BEGIN SWITCH  D A T A  TYPE   - - - - - - - - - -	
 if( (*UNI)->d != NULL ) {
	switch( (*UNI)->dType ) {

		case e_T_MATRIX_DATA:    
		    for(L=0; L<N_D; L++){
 				 if(  DestroyUniStruct( &((*UNI)->d->Mat[L]) )  )return(E);
		    }	 
			free( (*UNI)->d->Mat );    (*UNI)->d->Mat = NULL;			
			free( (*UNI)->d );   (*UNI)->d = NULL;			
		break;

			case e_T_VECTOR_DATA:    
			    for(L=0; L<N_D; L++){
	 				 if(  DestroyUniStruct( &((*UNI)->d->Vec[L]) )  )return(E);
			    }	 
				free( (*UNI)->d->Vec );    (*UNI)->d->Vec = NULL;				
				free( (*UNI)->d );   (*UNI)->d = NULL;			
			break;


		case e_T_OBJECT_DATA:    
		    for(L=0; L<N_D; L++){
 				 if(  DestroyUniStruct( &((*UNI)->d->Obj[L]) )  )return(E);
		    }	 
			free( (*UNI)->d->Obj );    (*UNI)->d->Obj = NULL;			
			free( (*UNI)->d );   (*UNI)->d = NULL;			
		break;

			case e_T_ITEM_DATA:    
			    for(L=0; L<N_D; L++){
	 				 if(  DestroyUniStruct( &((*UNI)->d->Item[L]) )  )return(E);
			    }	 
				free( (*UNI)->d->Item );    (*UNI)->d->Item = NULL;				
				free( (*UNI)->d );   (*UNI)->d = NULL;			
			break;

		case e_T_DATASET_DATA:    
		    for(L=0; L<N_D; L++){
 				 if(  DestroyUniStruct( &((*UNI)->d->DSet[L]) )  )return(E);
		    }	 
			free( (*UNI)->d->DSet );    (*UNI)->d->DSet = NULL;
			free( (*UNI)->d );   (*UNI)->d = NULL;			
		break;

			case e_T_SERIES_DATA:    
			    for(L=0; L<N_D; L++){
	 				 if(  DestroyUniStruct( &((*UNI)->d->Ser[L]) )  )return(E);
			    }	 
				free( (*UNI)->d->Ser );    (*UNI)->d->Ser = NULL;				
				free( (*UNI)->d );   (*UNI)->d = NULL;			
			break;
			
	 // ELEMENTARY DATA-TYPES:  1 - DIMENSIONAL ARRAYS OF GENERIC C-TYPES
	 	 	  
		case e_T_CHAR:    
			free( (*UNI)->d->Xc );    (*UNI)->d->Xc = NULL; 
		break;

		case e_T_UCHAR:    
			free( (*UNI)->d->Xuc );   (*UNI)->d->Xuc = NULL; 
		break;
		
		case e_T_SHORT:    
			free( (*UNI)->d->Xs );    (*UNI)->d->Xs = NULL; 
		break;

		case e_T_USHORT:    
			free( (*UNI)->d->Xus );   (*UNI)->d->Xus = NULL; 
		break;
		
		case e_T_INT:    
			free( (*UNI)->d->Xi );    (*UNI)->d->Xi = NULL; 
		break;

		case e_T_UINT:    
			free( (*UNI)->d->Xui );   (*UNI)->d->Xui = NULL; 
		break;

		case e_T_LONG:    
			free( (*UNI)->d->Xl );    (*UNI)->d->Xl = NULL; 
		break;

		case e_T_ULONG:    
			free( (*UNI)->d->Xul );   (*UNI)->d->Xul = NULL; 
		break;

		case e_T_FLOAT:    
			free( (*UNI)->d->Xf );    (*UNI)->d->Xf = NULL; 
		break;

		case e_T_DOUBLE:    
			free( (*UNI)->d->Xd );    (*UNI)->d->Xd = NULL; 
		break;

		case e_T_LONG_DOUBLE:    
			free( (*UNI)->d->Xld );   (*UNI)->d->Xld = NULL; 
		break;
		
	} // switch( Dtype )
	
	// DO NOT FREE  UniData 'd'  AT LOWEST LEVEL OF ELEMENTARY TYPES !!!
	// THIS BREAKES THE RECURSION
	// !! NO !! --> free( (*UNI)->d );   (*UNI)->d = NULL;			
	
		
 } // if( (*UNI)->d != NULL )	
 // - - - - - - - - - -   END SWITCH  D A T A  TYPE   - - - - - - - - - -	
		
 // - - - - - - - - - -   BEGIN SWITCH  P R O P E R T Y  TYPE   - - - - - - - - - -	
 if( (*UNI)->p != NULL ) {
	switch( (*UNI)->pType ) {
		
		case e_T_NO_PROP:    
			free( (*UNI)->p );   (*UNI)->p = NULL;
		break;

		
		case e_T_MATRIX_PROP:    
		    for(L=0; L<N_D; L++){
 				 if(  DestroyGroupProp( &((*UNI)->p->Mat[L]) )  )return(E);
		    }	 
			free( (*UNI)->p->Mat );    (*UNI)->p->Mat = NULL;
			free( (*UNI)->p );   (*UNI)->p = NULL;
		break;

			case e_T_VECTOR_PROP:    
			    for(L=0; L<N_D; L++){
	 				 if(  DestroyEntityProp( &((*UNI)->p->Vec[L]) )  )return(E);
			    }	 
				free( (*UNI)->p->Vec );    (*UNI)->p->Vec = NULL;
				free( (*UNI)->p );   (*UNI)->p = NULL;
			break;
		
		
		case e_T_OBJECT_PROP:    
		    for(L=0; L<N_D; L++){
 				 if(  DestroyGroupProp( &((*UNI)->p->Obj[L]) )  )return(E);
		    }	 
			free( (*UNI)->p->Obj );    (*UNI)->p->Obj = NULL;
			free( (*UNI)->p );   (*UNI)->p = NULL;
		break;

			case e_T_ITEM_PROP:    
			    for(L=0; L<N_D; L++){
	 				 if(  DestroyEntityProp( &((*UNI)->p->Item[L]) )  )return(E);
			    }	 
				free( (*UNI)->p->Item );    (*UNI)->p->Item = NULL;
				free( (*UNI)->p );   (*UNI)->p = NULL;
			break;
		
		
		case e_T_DATASET_PROP:    
		    for(L=0; L<N_D; L++){
 				 if(  DestroyGroupProp( &((*UNI)->p->DSet[L]) )  )return(E);
		    }	 
			free( (*UNI)->p->DSet );    (*UNI)->p->DSet = NULL;
			free( (*UNI)->p );   (*UNI)->p = NULL;
		break;

			case e_T_SERIES_PROP:    
			    for(L=0; L<N_D; L++){
			    
			    	printf("(*UNI)->p->Ser[%lu]->Ref = %p\n",L,(*UNI)->p->Ser[L]->Ref);
			    	
	 				 if(  DestroyEntityProp( &((*UNI)->p->Ser[L]) )  )return(E);
			    }	 
				free( (*UNI)->p->Ser );    (*UNI)->p->Ser = NULL;
				free( (*UNI)->p );   (*UNI)->p = NULL;
			break; 

		case e_T_BASE_PROP:    
			    for(L=0; L<N_D; L++){
	 				 if(  DestroyBaseProp( &((*UNI)->p->Xp[L]) )  )return(E);
			    }	 
				free( (*UNI)->p->Xp );    (*UNI)->p->Xp = NULL;
				free( (*UNI)->p );   (*UNI)->p = NULL;
		break;
							 
	} // switch( Ptype )
		
 } // if( (*UNI)->d != NULL )		
 // - - - - - - - - - -   END SWITCH  P R O P E R T Y  TYPE   - - - - - - - - - -	
 
	//free( (*UNI)->vSize );   (*UNI)->vSize = NULL;
	//      (*UNI)->vDim = 0;  

    (*UNI)->Size = 0;  
          
	free( *UNI );   *UNI = NULL;
		
	E = 0;  // indicate SUCCESS;
	return(E);	
} // DestroyUniStruct	


int
AppendBlockToUniStruct ( TpointerUniStruct *UNI,  unsigned long Number ) {
	unsigned long Index = (*UNI)->Size-1;
	return( ModifyUniStruct (  2  ,  UNI , Index, Number ) );
}

int
InsertBlockToUniStruct ( TpointerUniStruct *UNI,  unsigned long Index,  unsigned long Number ) {
	return( ModifyUniStruct (  1  ,  UNI , Index, Number ) );
}

int
DeleteBlockFromUniStruct ( TpointerUniStruct *UNI,  unsigned long Index,  unsigned long Number ) {
	return( ModifyUniStruct (  0  ,  UNI , Index, Number ) );
}

static int
ModifyUniStruct ( int COMMAND,   TpointerUniStruct *UNI,  unsigned long Index,  unsigned long Number ) {

	const int APPEND = 2;
	const int INSERT = 1;
	const int DELETE = 0;
	
	int E = -1; // indicate FAILURE
	int DO_SHIFT = 0;	
	unsigned long i,j, iStart, iStop, OldSize, NewSize;
	
	// does the !pointer! to UniStruct exist ?	
	if(  UNI == NULL )return(E);	// EXIT ON ERROR		
	if( *UNI == NULL )return(E);	// EXIT ON ERROR	
	
	if(COMMAND == APPEND) Index = (*UNI)->Size -1;
	
	// check: is Index valid ?
	if( Index > (*UNI)->Size-1 )return(E);	// EXIT ON ERROR		 

	// something to insert ?	
	if( Number == 0 ) { // if not --> then we're finished
		E = 0;   return(E);  // indicate SUCCESS
	}

	if(COMMAND == DELETE){ // if DELETE
		if(Index+Number > (*UNI)->Size) Number = (*UNI)->Size - Index; // eventually correct Number
	}	

	
	if( (*UNI)->d == NULL )return(E);	// EXIT ON ERROR	
	//if( (*UNI)->p == NULL )return(E);	// EXIT ON ERROR	having no properties is not a fault
	
	OldSize = (*UNI)->Size;
	
  //  P R E - S H I F T - O P E R A T I O N S 
    if( (COMMAND == INSERT) ||
        (COMMAND == APPEND) ) {
        	
    	NewSize = OldSize + Number;    	
    	
    	//  allocate more memory for inserting new elements    
    	if(  ResizeUniStruct ( UNI , NewSize )  )return(E);  // EXIT ON ERROR 
    	    	
    }else if(COMMAND == DELETE) { // DELETE - OPERATION
    	if(OldSize < Number) NewSize = 0; else NewSize = OldSize - Number;
    	// free memory --> destroy elements to be deleted
    	if( (*UNI)->d != NULL ) {
	    	for( i = Index;   i < Index+Number;   i++ ) {
	    		switch( (*UNI)->dType ) {
	    			case e_T_MATRIX_DATA:   if( DestroyUniStruct( &(*UNI)->d->Mat[i] )  )return(E); // EXIT ON ERROR
	    			break;
	    			case e_T_VECTOR_DATA:   if( DestroyUniStruct( &(*UNI)->d->Vec[i] )  )return(E); // EXIT ON ERROR
	    			break;
	    			case e_T_OBJECT_DATA:   if( DestroyUniStruct( &(*UNI)->d->Obj[i] )  )return(E); // EXIT ON ERROR
	    			break;
	    			case e_T_ITEM_DATA:     if( DestroyUniStruct( &(*UNI)->d->Item[i] ) )return(E); // EXIT ON ERROR
	    			break;
	    			case e_T_DATASET_DATA:  if( DestroyUniStruct( &(*UNI)->d->DSet[i] ) )return(E); // EXIT ON ERROR
	    			break;
	    			case e_T_SERIES_DATA:   if( DestroyUniStruct( &(*UNI)->d->Ser[i] )  )return(E); // EXIT ON ERROR
	    			break;
	    			    			    			
	    		} // switch dType
	    	} // for(i=Index..) 	
    	}    	
    }	
    
  //  S H I F T I N G   O F   E L E M E N T S   BY EXCHANGING POINTERS
  //  NO shift for APPEND !
	if( (COMMAND == INSERT) ||    // SHIFT ELEMENTS in REVERSE ORDER starting at the END
	    (COMMAND == DELETE) ) { 
		
		DO_SHIFT = 0;
		
			if(COMMAND == INSERT) { //  for( i = OldSize-1;   i >= Index;   i-- )   REVERSE ORDER !
				iStart = OldSize - 1;      iStop = Index;            
				i = iStart;   if( iStart >= iStop ) DO_SHIFT = 1;
			}	
	   else if(COMMAND == DELETE) { //  for( i = Index+Number;   i <= OldSize-1;   i++ )   forward order
			  	iStart = Index+Number;     iStop = OldSize - 1;      
				i = iStart;   if( iStart <= iStop ) DO_SHIFT = 1;
			}	
		
		while( DO_SHIFT ) {  // case INSERT:  -->  for( i = OldSize-1;      i >= Index;       i-- )
			                 // case DELETE:  -->  for( i = Index+Number;   i <= OldSize-1;   i++ )
		         // set target index  j  
			     if(COMMAND==INSERT){ j = i + Number; }
			else if(COMMAND==DELETE){ j = i - Number; }
		    		    
			//  DATA - SHIFTING
			if( (*UNI)->d != NULL ) {
				switch( (*UNI)->dType ) {
					case e_T_MATRIX_DATA:   (*UNI)->d->Mat[j]  = (*UNI)->d->Mat[i];      (*UNI)->d->Mat[i]  = NULL;				    			
					break;
					case e_T_VECTOR_DATA:   (*UNI)->d->Vec[j]  = (*UNI)->d->Vec[i];      (*UNI)->d->Vec[i]  = NULL;				    			
					break;
					case e_T_OBJECT_DATA:   (*UNI)->d->Obj[j]  = (*UNI)->d->Obj[i];      (*UNI)->d->Obj[i]  = NULL;				    			
					break;
					case e_T_ITEM_DATA:     (*UNI)->d->Item[j] = (*UNI)->d->Item[i];     (*UNI)->d->Item[i] = NULL;				    			
					break;
					case e_T_DATASET_DATA:  (*UNI)->d->DSet[j] = (*UNI)->d->DSet[i];     (*UNI)->d->DSet[i] = NULL;				    			
					break;
					case e_T_SERIES_DATA:   (*UNI)->d->Ser[j]  = (*UNI)->d->Ser[i];      (*UNI)->d->Ser[i]  = NULL;				    			
					break;
					
					case e_T_CHAR:        (*UNI)->d->Xc[j]  = (*UNI)->d->Xc[i];      (*UNI)->d->Xc[i]  = 0;
					break;
	    			case e_T_UCHAR:       (*UNI)->d->Xuc[j] = (*UNI)->d->Xuc[i];     (*UNI)->d->Xuc[i] = 0; 
					break;
	    			case e_T_SHORT:       (*UNI)->d->Xs[j]  = (*UNI)->d->Xs[i];      (*UNI)->d->Xs[i]  = 0; 
					break;
	    			case e_T_USHORT:      (*UNI)->d->Xus[j] = (*UNI)->d->Xus[i];     (*UNI)->d->Xus[i] = 0;   
					break;
	    			case e_T_INT:         (*UNI)->d->Xi[j]  = (*UNI)->d->Xi[i];      (*UNI)->d->Xi[i]  = 0; 
					break;  
	    			case e_T_UINT:        (*UNI)->d->Xui[j] = (*UNI)->d->Xui[i];     (*UNI)->d->Xui[i] = 0;   
					break;
	    			case e_T_LONG:        (*UNI)->d->Xl[j]  = (*UNI)->d->Xl[i];      (*UNI)->d->Xl[i]  = 0; 
					break;  
	    			case e_T_ULONG:       (*UNI)->d->Xul[j] = (*UNI)->d->Xul[i];     (*UNI)->d->Xul[i] = 0;   
					break;
	    			case e_T_FLOAT:       (*UNI)->d->Xf[j]  = (*UNI)->d->Xf[i];      (*UNI)->d->Xf[i]  = 0.0;   
					break;
	    			case e_T_DOUBLE:      (*UNI)->d->Xd[j]  = (*UNI)->d->Xd[i];      (*UNI)->d->Xd[i]  = 0.0; 
					break;  
	    			case e_T_LONG_DOUBLE: (*UNI)->d->Xld[j] = (*UNI)->d->Xld[i];     (*UNI)->d->Xld[i] = 0.0;   
					break;
					
				} // switch dType	
			}
			
			//  PROPERTY - SHIFTING
			if( (*UNI)->p != NULL ) {
				switch( (*UNI)->pType ) {
					case e_T_NO_PROP:  // no shift
					break;
					case e_T_MATRIX_PROP:   (*UNI)->p->Mat[j]  = (*UNI)->p->Mat[i];      (*UNI)->p->Mat[i]  = NULL;				    			
					break;
					case e_T_VECTOR_PROP:   (*UNI)->p->Vec[j]  = (*UNI)->p->Vec[i];      (*UNI)->p->Vec[i]  = NULL;				    			
					break;
					case e_T_OBJECT_PROP:   (*UNI)->p->Obj[j]  = (*UNI)->p->Obj[i];      (*UNI)->p->Obj[i]  = NULL;				    			
					break;
					case e_T_ITEM_PROP:     (*UNI)->p->Item[j] = (*UNI)->p->Item[i];     (*UNI)->p->Item[i] = NULL;				    			
					break;
					case e_T_DATASET_PROP:  (*UNI)->p->DSet[j] = (*UNI)->p->DSet[i];     (*UNI)->p->DSet[i] = NULL;				    			
					break;
					case e_T_SERIES_PROP:   (*UNI)->p->Ser[j]  = (*UNI)->p->Ser[i];      (*UNI)->p->Ser[i]  = NULL;				    			
					break;
					case e_T_BASE_PROP:     (*UNI)->p->Xp[j]   = (*UNI)->p->Xp[i];       (*UNI)->p->Xp[i]   = NULL;				    			
					break;
				} // switch pType	
			}
			
			     // decrease/increase loop index  i  and check for loop end
			     if(COMMAND == INSERT){   i--;   if( i < iStop ) DO_SHIFT = 0; }
			else if(COMMAND == DELETE){   i++;   if( i > iStop ) DO_SHIFT = 0; }
			
		} // while( DO_SHIFT)..
	} // if(COMMAND==INSERT || COMMAND==DELETE)..	


  //  P O S T - S H I F T - C O M M A N D S
    if( (COMMAND == INSERT) ||
        (COMMAND == APPEND) ) {
    	// nothing
    }else if(COMMAND == DELETE) { // DELETE - OPERATION
    	
        //  free memory; trim to actual size after deleting elements
    	if(  ResizeUniStruct ( UNI , NewSize )  )return(E);  // EXIT ON ERROR     	
    }	
	
	(*UNI)->Size = NewSize;
	
	E = 0; // INDICATE SUCCESS
	return(E);
} // ModifyUniStruct	


void
GetSubSizesUniStruct (  TpointerUniStruct UNI,  unsigned long *MinSz,  unsigned long *MaxSz ) {
	
	int EVALUATE;
	unsigned long i, Size;
	
	*MinSz = ULONG_MAX;  	 *MaxSz = 0;
	
	if( UNI == NULL )return;	// EXIT ON ERROR	
	
	if( UNI->d != NULL ) {
		for( i = 0;  i < UNI->Size;  i++ ) {
			EVALUATE = 0;
			switch( UNI->dType ) {
				
				case e_T_MATRIX_DATA:   Size = UNI->d->Mat[i]->Size;	  EVALUATE = 1;			    			
				break;
				case e_T_VECTOR_DATA:   Size = UNI->d->Vec[i]->Size;	  EVALUATE = 1;
				break;
				case e_T_OBJECT_DATA:   Size = UNI->d->Obj[i]->Size;	  EVALUATE = 1;
				break;
				case e_T_ITEM_DATA:     Size = UNI->d->Item[i]->Size;	  EVALUATE = 1;
				break;
				case e_T_DATASET_DATA:  Size = UNI->d->DSet[i]->Size;	  EVALUATE = 1;
				break;
				case e_T_SERIES_DATA:   Size = UNI->d->Ser[i]->Size;	  EVALUATE = 1; 
				break;
				
				// ELEMENTARY DATA TYPES
				case e_T_CHAR:       
    			case e_T_UCHAR:      
    			case e_T_SHORT:      
    			case e_T_USHORT:     
    			case e_T_INT:        
    			case e_T_UINT:       
    			case e_T_LONG:       
    			case e_T_ULONG:      
    			case e_T_FLOAT:      
    			case e_T_DOUBLE:     
    			case e_T_LONG_DOUBLE: { /* not applicable for these types */ }
				
			} // switch dType		
			
			if(EVALUATE) {
				if( Size < *MinSz ) *MinSz = Size;
				if( Size > *MaxSz ) *MaxSz = Size;
			}
		} // for(i=0;i<UNI->Size;i++)	
	}	
	return;
} // GetSubSizesUniStruct	


void
GetSubTypesUniStruct (  TpointerUniStruct UNI,  short *dType,  short *pType ) {
	
	int EXIT_LOOP;
	unsigned long i;
	
	*dType = -1;  	 *dType = -1;
	
	if( UNI == NULL )return;	// EXIT ON ERROR	
	
	// check  !SUB! - dType  if applicable
	if( UNI->d != NULL ) {
		EXIT_LOOP = 0;
		for( i = 0;  i < UNI->Size;  i++ ) {			
			if( i == 0 ) {
				switch( UNI->dType ) {					
					case e_T_MATRIX_DATA:   *dType = UNI->d->Mat[i]->dType;	  
					break;
					case e_T_VECTOR_DATA:   *dType = UNI->d->Vec[i]->dType;	  
					break;
					case e_T_OBJECT_DATA:   *dType = UNI->d->Obj[i]->dType;	  
					break;
					case e_T_ITEM_DATA:     *dType = UNI->d->Item[i]->dType;	
					break;
					case e_T_DATASET_DATA:  *dType = UNI->d->DSet[i]->dType;	 
					break;
					case e_T_SERIES_DATA:   *dType = UNI->d->Ser[i]->dType;	  
					break;
					 // not applicable for ELEMENTARY DATA TYPES 
					default:  EXIT_LOOP = 1;
				} // switch dType	
			}else{ 
				switch( UNI->dType ) {					
					case e_T_MATRIX_DATA:   if( UNI->d->Mat[i]->dType  != *dType ) EXIT_LOOP = 1;
					break;
					case e_T_VECTOR_DATA:   if( UNI->d->Vec[i]->dType  != *dType ) EXIT_LOOP = 1;
					break;
					case e_T_OBJECT_DATA:   if( UNI->d->Obj[i]->dType  != *dType ) EXIT_LOOP = 1;
					break;
					case e_T_ITEM_DATA:     if( UNI->d->Item[i]->dType != *dType ) EXIT_LOOP = 1;
					break;
					case e_T_DATASET_DATA:  if( UNI->d->DSet[i]->dType != *dType ) EXIT_LOOP = 1;
					break;
					case e_T_SERIES_DATA:   if( UNI->d->Ser[i]->dType  != *dType ) EXIT_LOOP = 1;
					break;
					 // not applicable for ELEMENTARY DATA TYPES 
					default:  EXIT_LOOP = 1;
				} // switch dType		
			} // if(i==0)..else..
			
			if(EXIT_LOOP) {
				 *dType = -1;    break;  // EXIT FOR-LOOP when   SUB - dType   differs
			}
		} // for(i=0;i<UNI->Size;i++)	
	} // if(UNI->d != NULL).. 	

    // check  !SUB! - pType  if applicable    
	if( UNI->d != NULL ) {
		EXIT_LOOP = 0;
		for( i = 0;  i < UNI->Size;  i++ ) {			
			if( i == 0 ) {
				switch( UNI->dType ) {					
					case e_T_MATRIX_DATA:   *pType = UNI->d->Mat[i]->pType;	  
					break;
					case e_T_VECTOR_DATA:   *pType = UNI->d->Vec[i]->pType;	  
					break;
					case e_T_OBJECT_DATA:   *pType = UNI->d->Obj[i]->pType;	  
					break;
					case e_T_ITEM_DATA:     *pType = UNI->d->Item[i]->pType;	  
					break;
					case e_T_DATASET_DATA:  *pType = UNI->d->DSet[i]->pType;	  
					break;
					case e_T_SERIES_DATA:   *pType = UNI->d->Ser[i]->pType;	  
					break;
					 // not applicable for ELEMENTARY DATA TYPES 
					default:  EXIT_LOOP = 1;
				} // switch dType	
			}else{ 
				switch( UNI->dType ) {					
					case e_T_MATRIX_DATA:   if( UNI->d->Mat[i]->pType  != *pType ) EXIT_LOOP = 1;
					break;
					case e_T_VECTOR_DATA:   if( UNI->d->Vec[i]->pType  != *pType ) EXIT_LOOP = 1;
					break;
					case e_T_OBJECT_DATA:   if( UNI->d->Obj[i]->pType  != *pType ) EXIT_LOOP = 1;
					break;
					case e_T_ITEM_DATA:     if( UNI->d->Item[i]->pType != *pType ) EXIT_LOOP = 1;
					break;
					case e_T_DATASET_DATA:  if( UNI->d->DSet[i]->pType != *pType ) EXIT_LOOP = 1;
					break;
					case e_T_SERIES_DATA:   if( UNI->d->Ser[i]->pType  != *pType ) EXIT_LOOP = 1;
					break;
					 // not applicable for ELEMENTARY DATA TYPES 
					default:  EXIT_LOOP = 1;
				} // switch dType		
			} // if(i==0)..else..
			
			if(EXIT_LOOP) {
				 *pType = -1;    break;  // EXIT FOR-LOOP when   SUB - pType   differs
			}
		} // for(i=0;i<UNI->Size;i++)	
	} // if(UNI->d != NULL).. 	
	
	return;
} // GetSubTypesUniStruct	


int
EqualizeUniStruct ( TpointerUniStruct *UNI,  unsigned long Size ) {
		
	int E = -1; // indicate FAILURE
	unsigned long i;
	
	// does the !pointer! to UniStruct exist ?	
	if(  UNI == NULL )return(E);	// EXIT ON ERROR		
	if( *UNI == NULL )return(E);	// EXIT ON ERROR	
	
	if( (*UNI)->d == NULL )return(E);  // EXIT ON ERROR
			
	for( i=0; i<(*UNI)->Size-1; i++ ) {
		
		switch( (*UNI)->dType ) {
			
			case e_T_MATRIX_DATA:   
				if( (*UNI)->d->Mat[i]->Size != Size) {
					if( !(ResizeUniStruct( &((*UNI)->d->Mat[i]) , Size)) )return(E);	
				};	
			break;
			case e_T_VECTOR_DATA:   
				if( (*UNI)->d->Vec[i]->Size != Size) {
					if( !(ResizeUniStruct( &((*UNI)->d->Vec[i]) , Size)) )return(E);	
				};	
			break;
			case e_T_OBJECT_DATA:   
				if( (*UNI)->d->Obj[i]->Size != Size) {
					if( !(ResizeUniStruct( &((*UNI)->d->Obj[i]) , Size)) )return(E);	
				};	
			break;
			case e_T_ITEM_DATA:     
				if( (*UNI)->d->Item[i]->Size != Size) {
					if( !(ResizeUniStruct( &((*UNI)->d->Item[i]) , Size)) )return(E);	
				};	
			break;
			case e_T_DATASET_DATA: 
				if( (*UNI)->d->DSet[i]->Size != Size) {
					if( !(ResizeUniStruct( &((*UNI)->d->DSet[i]) , Size)) )return(E);	
				};	
			break;
			case e_T_SERIES_DATA:
				if( (*UNI)->d->Ser[i]->Size != Size) {
					if( !(ResizeUniStruct( &((*UNI)->d->Ser[i]) , Size)) )return(E);	
				};	
			break;
			
			// ELEMENTARY DATA TYPES
			case e_T_CHAR:       
			case e_T_UCHAR:      
			case e_T_SHORT:      
			case e_T_USHORT:     
			case e_T_INT:        
			case e_T_UINT:       
			case e_T_LONG:       
			case e_T_ULONG:      
			case e_T_FLOAT:      
			case e_T_DOUBLE:     
			case e_T_LONG_DOUBLE: { /* not applicable for these types */ }
							
		} // switch dType			
	}	
	E = 0; // indicate SUCCESS
	return(E);		
} // EqualizeUniStruct	


int
TransposeUniStruct ( TpointerUniStruct *UNI ) {

	enum { 	M_EQ_N = 0,  // M == N
			M_LT_N = 1,  // M <  N
			M_GT_N = 2   // M  > N
		 };	
	
	int E = -1; // indicate FAILURE	
	int M_x_N;
	short  Sub_dType=0, Sub_pType=0;
	unsigned long Min_SubSize=0, Max_SubSize=0;
	unsigned long i,j, L,M,N;
	
	// does the !pointer! to UniStruct exist ?	
	if(  UNI == NULL )return(E);	// EXIT ON ERROR		
	if( *UNI == NULL )return(E);	// EXIT ON ERROR	
	
	if( (*UNI)->d == NULL )return(E);  // EXIT ON ERROR
			
	GetSubTypesUniStruct ( *UNI, &Sub_dType, &Sub_pType);      // e.g.:  Sub_dType =(*UNI)->d->Obj[i=0..L]->d->dType	
    GetSubSizesUniStruct ( *UNI, &Min_SubSize, &Max_SubSize ); //    
    
    if( Max_SubSize == 0 )return(E);      // EXIT ON ERROR  --> all sub-sizes zero !?
    if( Sub_dType <= 0 )return(E);        // EXIT ON ERROR  --> differing sub-dType
    if( Sub_pType == 0 ) { // Sub_pType == 0 is o.k.
    	// --> means: has no properties          
    }else if( Sub_pType <  0 )return(E);  // EXIT ON ERROR  --> differing sub-pType 
    
    if( Min_SubSize != Max_SubSize) {
    	if( EqualizeUniStruct( UNI, Max_SubSize ) )return(E);	// EXIT ON ERROR		
    }
    
    M = (*UNI)->Size;
    N = Max_SubSize;
         if( M == N ){   M_x_N = M_EQ_N;    L = M;  }
    else if( M < N ) {   M_x_N = M_LT_N;    L = M;  }
    else if( M > N ) {   M_x_N = M_GT_N;    L = N;  }
 // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -   
 // FIRST:  T R A N S P O S E  ( M O V E )   ' O U T E R '   E L E M E N T S
    switch( M_x_N ) {    	
    	
    	case M_LT_N:  // M < N
    	 // PRE-TRANSPOSE-OPERATIONS --> ALLOCATE DESTINATION MEMORY    	  
    	    // add space for new row-/line- pointers at the end
    		if( ResizeUniStruct( UNI , N ) )return(E); // EXIT ON ERROR    		
    		// now allocate memory for new rows/lines of length  M
    		for( i=M; i<N; i++ ) {
    			switch( (*UNI)->dType ) {     //  L == M 
    				case e_T_MATRIX_DATA:
		    			if( CreateUniStruct( &((*UNI)->d->Mat[i]),  M,  Sub_dType, Sub_pType ) )return(E);// EXIT ON ERROR
		    		break;	
    				case e_T_VECTOR_DATA:
		    			if( CreateUniStruct( &((*UNI)->d->Vec[i]),  M,  Sub_dType, Sub_pType ) )return(E);// EXIT ON ERROR
		    		break;	
    				case e_T_OBJECT_DATA:
		    			if( CreateUniStruct( &((*UNI)->d->Obj[i]),  M,  Sub_dType, Sub_pType ) )return(E);// EXIT ON ERROR
		    		break;	
    				case e_T_ITEM_DATA:
		    			if( CreateUniStruct( &((*UNI)->d->Item[i]), M,  Sub_dType, Sub_pType ) )return(E);// EXIT ON ERROR
		    		break;	
    				case e_T_DATASET_DATA:
		    			if( CreateUniStruct( &((*UNI)->d->DSet[i]), M,  Sub_dType, Sub_pType ) )return(E);// EXIT ON ERROR
		    		break;	
    				case e_T_SERIES_DATA:
		    			if( CreateUniStruct( &((*UNI)->d->Ser[i]),  M,  Sub_dType, Sub_pType ) )return(E);// EXIT ON ERROR
		    		break;	
    			} // switch( (*UNI)->dType ) 	
    		} // for(i=M;i<N;i++).. 	
    		
    	 // TRANSPOSE(=MOVE!) OUTER VALUES 
    		for( i=0; i<M; i++ ) { // loop over 'rows'/'lines'
	    		for( j=M; j<N; j++ ) { // loop over 'columns'
	    			
	    			XchangeSubElemContent( 1 /*->MOVE*/ , UNI , i,j, Sub_dType );
	    			
	    		} // for(j=M;j<N;j++)..		
    		} // for(i=0;i<M;i++)..	
    		
    	 // POST-TRANSPOSE-OPERATIONS --> FREE (TRANSPOSED) SOURCE MEMORY 
    		for( i=0; i<M; i++ ) { // loop over 'rows'/'lines'
    			switch( (*UNI)->dType ) {
    				case e_T_MATRIX_DATA:
    					if( ResizeUniStruct( &((*UNI)->d->Mat[i]), M ) )return(E); // EXIT ON ERROR
	    			break;	
    				case e_T_VECTOR_DATA:
    					if( ResizeUniStruct( &((*UNI)->d->Vec[i]), M ) )return(E); // EXIT ON ERROR
	    			break;	
    				case e_T_OBJECT_DATA:
    					if( ResizeUniStruct( &((*UNI)->d->Obj[i]), M ) )return(E); // EXIT ON ERROR
	    			break;	
    				case e_T_ITEM_DATA:
    					if( ResizeUniStruct( &((*UNI)->d->Item[i]), M ) )return(E); // EXIT ON ERROR
	    			break;	
    				case e_T_DATASET_DATA:
    					if( ResizeUniStruct( &((*UNI)->d->DSet[i]), M ) )return(E); // EXIT ON ERROR
	    			break;	
    				case e_T_SERIES_DATA:
    					if( ResizeUniStruct( &((*UNI)->d->Ser[i]), M ) )return(E); // EXIT ON ERROR
	    			break;	
    			} // switch( (*UNI)->dType )	
    		} // for(i=0;i<M;i++)..	    	 
    		
    	break; // end of case M < N
    	
      //  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -     	
    	
    	case M_GT_N:  // M > N
    	 // PRE-TRANSPOSE-OPERATIONS --> ALLOCATE DESTINATION MEMORY    	      	    		
    		// allocate memory at the end of existing first N rows/lines --> extend to length  M
    		for( i=0; i<N; i++ ) {
    			switch( (*UNI)->dType ) {
    				case e_T_MATRIX_DATA:  if( ResizeUniStruct( &((*UNI)->d->Mat[i]), M ) )return(E); // EXIT ON ERROR
            		break;
    				case e_T_VECTOR_DATA:  if( ResizeUniStruct( &((*UNI)->d->Vec[i]), M ) )return(E); // EXIT ON ERROR
            		break;
    				case e_T_OBJECT_DATA:  if( ResizeUniStruct( &((*UNI)->d->Obj[i]), M ) )return(E); // EXIT ON ERROR
            		break;
    				case e_T_ITEM_DATA:    if( ResizeUniStruct( &((*UNI)->d->Item[i]), M ) )return(E); // EXIT ON ERROR
            		break;
    				case e_T_DATASET_DATA: if( ResizeUniStruct( &((*UNI)->d->DSet[i]), M ) )return(E); // EXIT ON ERROR
            		break;
    				case e_T_SERIES_DATA:  if( ResizeUniStruct( &((*UNI)->d->Ser[i]), M ) )return(E); // EXIT ON ERROR
            		break;
    			} // switch((*UNI)->dType).. 	
    		} // for(i=0;i<N;i++)..	
    		
    	 // TRANSPOSE(=MOVE!) OUTER VALUES 	            
    		for( i=N; i<M; i++ ) { // loop over 'rows'/'lines'
	    		for( j=0; j<N; j++ ) { // loop over 'columns'

	    			XchangeSubElemContent( 1 /*->MOVE*/ , UNI , i,j, Sub_dType );
	    			
	    		} // for(j=0;j<DiffSize;j++)..		
    		} // for(i=0;i<M;i++)..	            
            
    	 // POST-TRANSPOSE-OPERATIONS --> FREE (TRANSPOSED) SOURCE MEMORY
            // remove transferred rows/lines 
            for( i=N; i<M; i++ ) {
            	switch( (*UNI)->dType ) {
            		case e_T_MATRIX_DATA:  if( DestroyUniStruct( &((*UNI)->d->Mat[i]) ) )return(E); // EXIT ON ERROR
            		break;
            		case e_T_VECTOR_DATA:  if( DestroyUniStruct( &((*UNI)->d->Vec[i]) ) )return(E); // EXIT ON ERROR
            		break;
            		case e_T_OBJECT_DATA:  if( DestroyUniStruct( &((*UNI)->d->Obj[i]) ) )return(E); // EXIT ON ERROR
            		break;
            		case e_T_ITEM_DATA:    if( DestroyUniStruct( &((*UNI)->d->Item[i]) ) )return(E); // EXIT ON ERROR
            		break;
            		case e_T_DATASET_DATA: if( DestroyUniStruct( &((*UNI)->d->DSet[i]) ) )return(E); // EXIT ON ERROR
            		break;
            		case e_T_SERIES_DATA:  if( DestroyUniStruct( &((*UNI)->d->Ser[i]) ) )return(E); // EXIT ON ERROR
            		break;
            	} // switch( (*UNI)->dType )	
            }	
    	    // remove pointers of transferred rows/lines at the end
    		if( ResizeUniStruct( UNI , N ) )return(E); // EXIT ON ERROR
    	  
    	break; // end of case M > N:
    	
    } // switch( M_x_N )
 // END OF TRANSPOSE/MOVE 'OUTER' ELEMENTS   
 // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -   
    
 // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -       
 // FINALLY:  T R A N S P O S E  ( X C H N G E )  ' I N N E R '   E L E M E N T S   : lower tiangular half <--> upper triangular half 		         			 
	for( i=0; i<L; i++ ) { // loop over 'rows'/'lines'
		for( j=i+1; j<L; j++ ) { // loop over 'columns'
			
	    	XchangeSubElemContent( 0 /*->XCHNGE*/ , UNI , i,j, Sub_dType );
	    						
		} // for(j=i+1;j<L;j++)..
	} // for(i=0;i<L;i++)..	
 // END OF TRANSPOSE 'INNER' ELEMENTS	
 // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -   
	
	E = 0; // indicate SUCCESS
	return(E);		
} // TransformUniStruct	


static void
XchangeSubElemContent( int MOVE,  TpointerUniStruct *UNI,  unsigned long i,  unsigned long j,  short Sub_dType ) {
	            // commad  XCHANGE = !MOVE
		
	// temporary help variables for transpose operation
	TpointerUniStruct  Mat,Vec, Obj,Item, DSet,Ser;  
    char            Xc;   
    unsigned char   Xuc;  
    short           Xs;   
    unsigned short  Xus;  
    int             Xi;
    unsigned int    Xui;  
    long            Xl;
    unsigned long   Xul;  
    float           Xf;   
    double          Xd;
    long double     Xld;


	switch( (*UNI)->dType ) {
		case e_T_MATRIX_DATA:
		    switch( Sub_dType ) {                                                                                     
		            case e_T_MATRIX_DATA:  if(!MOVE) Mat  =  (*UNI)->d->Mat[j]->d->Mat [i];    (*UNI)->d->Mat[j]->d->Mat [i] =  (*UNI)->d->Mat[i]->d->Mat [j];    if(!MOVE) (*UNI)->d->Mat[i]->d->Mat [j] = Mat  ;  else  (*UNI)->d->Mat[i]->d->Mat [j] = NULL ;     
		      break;case e_T_VECTOR_DATA:  if(!MOVE) Vec  =  (*UNI)->d->Mat[j]->d->Vec [i];    (*UNI)->d->Mat[j]->d->Vec [i] =  (*UNI)->d->Mat[i]->d->Vec [j];    if(!MOVE) (*UNI)->d->Mat[i]->d->Vec [j] = Vec  ;  else  (*UNI)->d->Mat[i]->d->Vec [j] = NULL ;     
		      break;case e_T_OBJECT_DATA:  if(!MOVE) Obj  =  (*UNI)->d->Mat[j]->d->Obj [i];    (*UNI)->d->Mat[j]->d->Obj [i] =  (*UNI)->d->Mat[i]->d->Obj [j];    if(!MOVE) (*UNI)->d->Mat[i]->d->Obj [j] = Obj  ;  else  (*UNI)->d->Mat[i]->d->Obj [j] = NULL ;     
		      break;case e_T_ITEM_DATA:    if(!MOVE) Item =  (*UNI)->d->Mat[j]->d->Item[i];    (*UNI)->d->Mat[j]->d->Item[i] =  (*UNI)->d->Mat[i]->d->Item[j];    if(!MOVE) (*UNI)->d->Mat[i]->d->Item[j] = Item ;  else  (*UNI)->d->Mat[i]->d->Item[j] = NULL ;     
		      break;case e_T_DATASET_DATA: if(!MOVE) DSet =  (*UNI)->d->Mat[j]->d->DSet[i];    (*UNI)->d->Mat[j]->d->DSet[i] =  (*UNI)->d->Mat[i]->d->DSet[j];    if(!MOVE) (*UNI)->d->Mat[i]->d->DSet[j] = DSet ;  else  (*UNI)->d->Mat[i]->d->DSet[j] = NULL ;     
		      break;case e_T_SERIES_DATA:  if(!MOVE) Ser  =  (*UNI)->d->Mat[j]->d->Ser [i];    (*UNI)->d->Mat[j]->d->Ser [i] =  (*UNI)->d->Mat[i]->d->Ser [j];    if(!MOVE) (*UNI)->d->Mat[i]->d->Ser [j] = Ser  ;  else  (*UNI)->d->Mat[i]->d->Ser [j] = NULL ;     
			  break;case e_T_CHAR:         if(!MOVE) Xc   =  (*UNI)->d->Mat[j]->d->Xc  [i];    (*UNI)->d->Mat[j]->d->Xc  [i] =  (*UNI)->d->Mat[i]->d->Xc  [j];    if(!MOVE) (*UNI)->d->Mat[i]->d->Xc  [j] = Xc   ;  else  (*UNI)->d->Mat[i]->d->Xc  [j] = 0 ;        
			  break;case e_T_UCHAR:        if(!MOVE) Xuc  =  (*UNI)->d->Mat[j]->d->Xuc [i];    (*UNI)->d->Mat[j]->d->Xuc [i] =  (*UNI)->d->Mat[i]->d->Xuc [j];    if(!MOVE) (*UNI)->d->Mat[i]->d->Xuc [j] = Xuc  ;  else  (*UNI)->d->Mat[i]->d->Xuc [j] = 0 ;        
			  break;case e_T_SHORT:        if(!MOVE) Xs   =  (*UNI)->d->Mat[j]->d->Xs  [i];    (*UNI)->d->Mat[j]->d->Xs  [i] =  (*UNI)->d->Mat[i]->d->Xs  [j];    if(!MOVE) (*UNI)->d->Mat[i]->d->Xs  [j] = Xs   ;  else  (*UNI)->d->Mat[i]->d->Xs  [j] = 0 ;        
			  break;case e_T_USHORT:       if(!MOVE) Xus  =  (*UNI)->d->Mat[j]->d->Xus [i];    (*UNI)->d->Mat[j]->d->Xus [i] =  (*UNI)->d->Mat[i]->d->Xus [j];    if(!MOVE) (*UNI)->d->Mat[i]->d->Xus [j] = Xus  ;  else  (*UNI)->d->Mat[i]->d->Xus [j] = 0 ;        
			  break;case e_T_INT:          if(!MOVE) Xi   =  (*UNI)->d->Mat[j]->d->Xi  [i];    (*UNI)->d->Mat[j]->d->Xi  [i] =  (*UNI)->d->Mat[i]->d->Xi  [j];    if(!MOVE) (*UNI)->d->Mat[i]->d->Xi  [j] = Xi   ;  else  (*UNI)->d->Mat[i]->d->Xi  [j] = 0 ;        
			  break;case e_T_UINT:         if(!MOVE) Xui  =  (*UNI)->d->Mat[j]->d->Xui [i];    (*UNI)->d->Mat[j]->d->Xui [i] =  (*UNI)->d->Mat[i]->d->Xui [j];    if(!MOVE) (*UNI)->d->Mat[i]->d->Xui [j] = Xui  ;  else  (*UNI)->d->Mat[i]->d->Xui [j] = 0 ;        
			  break;case e_T_LONG:         if(!MOVE) Xl   =  (*UNI)->d->Mat[j]->d->Xl  [i];    (*UNI)->d->Mat[j]->d->Xl  [i] =  (*UNI)->d->Mat[i]->d->Xl  [j];    if(!MOVE) (*UNI)->d->Mat[i]->d->Xl  [j] = Xl   ;  else  (*UNI)->d->Mat[i]->d->Xl  [j] = 0 ;        
			  break;case e_T_ULONG:        if(!MOVE) Xul  =  (*UNI)->d->Mat[j]->d->Xul [i];    (*UNI)->d->Mat[j]->d->Xul [i] =  (*UNI)->d->Mat[i]->d->Xul [j];    if(!MOVE) (*UNI)->d->Mat[i]->d->Xul [j] = Xul  ;  else  (*UNI)->d->Mat[i]->d->Xul [j] = 0 ;        
			  break;case e_T_FLOAT:        if(!MOVE) Xf   =  (*UNI)->d->Mat[j]->d->Xf  [i];    (*UNI)->d->Mat[j]->d->Xf  [i] =  (*UNI)->d->Mat[i]->d->Xf  [j];    if(!MOVE) (*UNI)->d->Mat[i]->d->Xf  [j] = Xf   ;  else  (*UNI)->d->Mat[i]->d->Xf  [j] = 0.0 ;      
			  break;case e_T_DOUBLE:       if(!MOVE) Xd   =  (*UNI)->d->Mat[j]->d->Xd  [i];    (*UNI)->d->Mat[j]->d->Xd  [i] =  (*UNI)->d->Mat[i]->d->Xd  [j];    if(!MOVE) (*UNI)->d->Mat[i]->d->Xd  [j] = Xd   ;  else  (*UNI)->d->Mat[i]->d->Xd  [j] = 0.0 ;      
			  break;case e_T_LONG_DOUBLE:  if(!MOVE) Xld  =  (*UNI)->d->Mat[j]->d->Xld [i];    (*UNI)->d->Mat[j]->d->Xld [i] =  (*UNI)->d->Mat[i]->d->Xld [j];    if(!MOVE) (*UNI)->d->Mat[i]->d->Xld [j] = Xld  ;  else  (*UNI)->d->Mat[i]->d->Xld [j] = 0.0 ;      
			  break;                                                                                                                                                                                             
		    } // switch Sub_dType	                                                                                                                                                                             
		break;	                                                                                                                                                                                                 
		case e_T_VECTOR_DATA:                                                                                                                                                                                    
		    switch( Sub_dType ) {                                                                                                                                                                                
		            case e_T_MATRIX_DATA:  if(!MOVE) Mat  =  (*UNI)->d->Vec[j]->d->Mat [i];    (*UNI)->d->Vec[j]->d->Mat [i] =  (*UNI)->d->Vec[i]->d->Mat [j];    if(!MOVE) (*UNI)->d->Vec[i]->d->Mat [j] = Mat  ;  else  (*UNI)->d->Vec[i]->d->Mat [j] = NULL ;     
		      break;case e_T_VECTOR_DATA:  if(!MOVE) Vec  =  (*UNI)->d->Vec[j]->d->Vec [i];    (*UNI)->d->Vec[j]->d->Vec [i] =  (*UNI)->d->Vec[i]->d->Vec [j];    if(!MOVE) (*UNI)->d->Vec[i]->d->Vec [j] = Vec  ;  else  (*UNI)->d->Vec[i]->d->Vec [j] = NULL ;     
		      break;case e_T_OBJECT_DATA:  if(!MOVE) Obj  =  (*UNI)->d->Vec[j]->d->Obj [i];    (*UNI)->d->Vec[j]->d->Obj [i] =  (*UNI)->d->Vec[i]->d->Obj [j];    if(!MOVE) (*UNI)->d->Vec[i]->d->Obj [j] = Obj  ;  else  (*UNI)->d->Vec[i]->d->Obj [j] = NULL ;     
		      break;case e_T_ITEM_DATA:    if(!MOVE) Item =  (*UNI)->d->Vec[j]->d->Item[i];    (*UNI)->d->Vec[j]->d->Item[i] =  (*UNI)->d->Vec[i]->d->Item[j];    if(!MOVE) (*UNI)->d->Vec[i]->d->Item[j] = Item ;  else  (*UNI)->d->Vec[i]->d->Item[j] = NULL ;     
		      break;case e_T_DATASET_DATA: if(!MOVE) DSet =  (*UNI)->d->Vec[j]->d->DSet[i];    (*UNI)->d->Vec[j]->d->DSet[i] =  (*UNI)->d->Vec[i]->d->DSet[j];    if(!MOVE) (*UNI)->d->Vec[i]->d->DSet[j] = DSet ;  else  (*UNI)->d->Vec[i]->d->DSet[j] = NULL ;     
		      break;case e_T_SERIES_DATA:  if(!MOVE) Ser  =  (*UNI)->d->Vec[j]->d->Ser [i];    (*UNI)->d->Vec[j]->d->Ser [i] =  (*UNI)->d->Vec[i]->d->Ser [j];    if(!MOVE) (*UNI)->d->Vec[i]->d->Ser [j] = Ser  ;  else  (*UNI)->d->Vec[i]->d->Ser [j] = NULL ;     
			  break;case e_T_CHAR:         if(!MOVE) Xc   =  (*UNI)->d->Vec[j]->d->Xc  [i];    (*UNI)->d->Vec[j]->d->Xc  [i] =  (*UNI)->d->Vec[i]->d->Xc  [j];    if(!MOVE) (*UNI)->d->Vec[i]->d->Xc  [j] = Xc   ;  else  (*UNI)->d->Vec[i]->d->Xc  [j] = 0 ;        
			  break;case e_T_UCHAR:        if(!MOVE) Xuc  =  (*UNI)->d->Vec[j]->d->Xuc [i];    (*UNI)->d->Vec[j]->d->Xuc [i] =  (*UNI)->d->Vec[i]->d->Xuc [j];    if(!MOVE) (*UNI)->d->Vec[i]->d->Xuc [j] = Xuc  ;  else  (*UNI)->d->Vec[i]->d->Xuc [j] = 0 ;        
			  break;case e_T_SHORT:        if(!MOVE) Xs   =  (*UNI)->d->Vec[j]->d->Xs  [i];    (*UNI)->d->Vec[j]->d->Xs  [i] =  (*UNI)->d->Vec[i]->d->Xs  [j];    if(!MOVE) (*UNI)->d->Vec[i]->d->Xs  [j] = Xs   ;  else  (*UNI)->d->Vec[i]->d->Xs  [j] = 0 ;        
			  break;case e_T_USHORT:       if(!MOVE) Xus  =  (*UNI)->d->Vec[j]->d->Xus [i];    (*UNI)->d->Vec[j]->d->Xus [i] =  (*UNI)->d->Vec[i]->d->Xus [j];    if(!MOVE) (*UNI)->d->Vec[i]->d->Xus [j] = Xus  ;  else  (*UNI)->d->Vec[i]->d->Xus [j] = 0 ;        
			  break;case e_T_INT:          if(!MOVE) Xi   =  (*UNI)->d->Vec[j]->d->Xi  [i];    (*UNI)->d->Vec[j]->d->Xi  [i] =  (*UNI)->d->Vec[i]->d->Xi  [j];    if(!MOVE) (*UNI)->d->Vec[i]->d->Xi  [j] = Xi   ;  else  (*UNI)->d->Vec[i]->d->Xi  [j] = 0 ;        
			  break;case e_T_UINT:         if(!MOVE) Xui  =  (*UNI)->d->Vec[j]->d->Xui [i];    (*UNI)->d->Vec[j]->d->Xui [i] =  (*UNI)->d->Vec[i]->d->Xui [j];    if(!MOVE) (*UNI)->d->Vec[i]->d->Xui [j] = Xui  ;  else  (*UNI)->d->Vec[i]->d->Xui [j] = 0 ;        
			  break;case e_T_LONG:         if(!MOVE) Xl   =  (*UNI)->d->Vec[j]->d->Xl  [i];    (*UNI)->d->Vec[j]->d->Xl  [i] =  (*UNI)->d->Vec[i]->d->Xl  [j];    if(!MOVE) (*UNI)->d->Vec[i]->d->Xl  [j] = Xl   ;  else  (*UNI)->d->Vec[i]->d->Xl  [j] = 0 ;        
			  break;case e_T_ULONG:        if(!MOVE) Xul  =  (*UNI)->d->Vec[j]->d->Xul [i];    (*UNI)->d->Vec[j]->d->Xul [i] =  (*UNI)->d->Vec[i]->d->Xul [j];    if(!MOVE) (*UNI)->d->Vec[i]->d->Xul [j] = Xul  ;  else  (*UNI)->d->Vec[i]->d->Xul [j] = 0 ;        
			  break;case e_T_FLOAT:        if(!MOVE) Xf   =  (*UNI)->d->Vec[j]->d->Xf  [i];    (*UNI)->d->Vec[j]->d->Xf  [i] =  (*UNI)->d->Vec[i]->d->Xf  [j];    if(!MOVE) (*UNI)->d->Vec[i]->d->Xf  [j] = Xf   ;  else  (*UNI)->d->Vec[i]->d->Xf  [j] = 0.0 ;      
			  break;case e_T_DOUBLE:       if(!MOVE) Xd   =  (*UNI)->d->Vec[j]->d->Xd  [i];    (*UNI)->d->Vec[j]->d->Xd  [i] =  (*UNI)->d->Vec[i]->d->Xd  [j];    if(!MOVE) (*UNI)->d->Vec[i]->d->Xd  [j] = Xd   ;  else  (*UNI)->d->Vec[i]->d->Xd  [j] = 0.0 ;      
			  break;case e_T_LONG_DOUBLE:  if(!MOVE) Xld  =  (*UNI)->d->Vec[j]->d->Xld [i];    (*UNI)->d->Vec[j]->d->Xld [i] =  (*UNI)->d->Vec[i]->d->Xld [j];    if(!MOVE) (*UNI)->d->Vec[i]->d->Xld [j] = Xld  ;  else  (*UNI)->d->Vec[i]->d->Xld [j] = 0.0 ;      
			  break;                                                                                                                                                                                             
		    } // switch Sub_dType	                                                                                                                                                                             
		break;	                                                                                                                                                                                                 
		case e_T_OBJECT_DATA:                                                                                                                                                                                    
		    switch( Sub_dType ) {                                                                                                                                                                                
		            case e_T_MATRIX_DATA:  if(!MOVE) Mat  =  (*UNI)->d->Obj[j]->d->Mat [i];    (*UNI)->d->Obj[j]->d->Mat [i] =  (*UNI)->d->Obj[i]->d->Mat [j];    if(!MOVE) (*UNI)->d->Obj[i]->d->Mat [j] = Mat  ;  else  (*UNI)->d->Obj[i]->d->Mat [j] = NULL ;     
		      break;case e_T_VECTOR_DATA:  if(!MOVE) Vec  =  (*UNI)->d->Obj[j]->d->Vec [i];    (*UNI)->d->Obj[j]->d->Vec [i] =  (*UNI)->d->Obj[i]->d->Vec [j];    if(!MOVE) (*UNI)->d->Obj[i]->d->Vec [j] = Vec  ;  else  (*UNI)->d->Obj[i]->d->Vec [j] = NULL ;     
		      break;case e_T_OBJECT_DATA:  if(!MOVE) Obj  =  (*UNI)->d->Obj[j]->d->Obj [i];    (*UNI)->d->Obj[j]->d->Obj [i] =  (*UNI)->d->Obj[i]->d->Obj [j];    if(!MOVE) (*UNI)->d->Obj[i]->d->Obj [j] = Obj  ;  else  (*UNI)->d->Obj[i]->d->Obj [j] = NULL ;     
		      break;case e_T_ITEM_DATA:    if(!MOVE) Item =  (*UNI)->d->Obj[j]->d->Item[i];    (*UNI)->d->Obj[j]->d->Item[i] =  (*UNI)->d->Obj[i]->d->Item[j];    if(!MOVE) (*UNI)->d->Obj[i]->d->Item[j] = Item ;  else  (*UNI)->d->Obj[i]->d->Item[j] = NULL ;     
		      break;case e_T_DATASET_DATA: if(!MOVE) DSet =  (*UNI)->d->Obj[j]->d->DSet[i];    (*UNI)->d->Obj[j]->d->DSet[i] =  (*UNI)->d->Obj[i]->d->DSet[j];    if(!MOVE) (*UNI)->d->Obj[i]->d->DSet[j] = DSet ;  else  (*UNI)->d->Obj[i]->d->DSet[j] = NULL ;     
		      break;case e_T_SERIES_DATA:  if(!MOVE) Ser  =  (*UNI)->d->Obj[j]->d->Ser [i];    (*UNI)->d->Obj[j]->d->Ser [i] =  (*UNI)->d->Obj[i]->d->Ser [j];    if(!MOVE) (*UNI)->d->Obj[i]->d->Ser [j] = Ser  ;  else  (*UNI)->d->Obj[i]->d->Ser [j] = NULL ;     
			  break;case e_T_CHAR:         if(!MOVE) Xc   =  (*UNI)->d->Obj[j]->d->Xc  [i];    (*UNI)->d->Obj[j]->d->Xc  [i] =  (*UNI)->d->Obj[i]->d->Xc  [j];    if(!MOVE) (*UNI)->d->Obj[i]->d->Xc  [j] = Xc   ;  else  (*UNI)->d->Obj[i]->d->Xc  [j] = 0 ;        
			  break;case e_T_UCHAR:        if(!MOVE) Xuc  =  (*UNI)->d->Obj[j]->d->Xuc [i];    (*UNI)->d->Obj[j]->d->Xuc [i] =  (*UNI)->d->Obj[i]->d->Xuc [j];    if(!MOVE) (*UNI)->d->Obj[i]->d->Xuc [j] = Xuc  ;  else  (*UNI)->d->Obj[i]->d->Xuc [j] = 0 ;        
			  break;case e_T_SHORT:        if(!MOVE) Xs   =  (*UNI)->d->Obj[j]->d->Xs  [i];    (*UNI)->d->Obj[j]->d->Xs  [i] =  (*UNI)->d->Obj[i]->d->Xs  [j];    if(!MOVE) (*UNI)->d->Obj[i]->d->Xs  [j] = Xs   ;  else  (*UNI)->d->Obj[i]->d->Xs  [j] = 0 ;        
			  break;case e_T_USHORT:       if(!MOVE) Xus  =  (*UNI)->d->Obj[j]->d->Xus [i];    (*UNI)->d->Obj[j]->d->Xus [i] =  (*UNI)->d->Obj[i]->d->Xus [j];    if(!MOVE) (*UNI)->d->Obj[i]->d->Xus [j] = Xus  ;  else  (*UNI)->d->Obj[i]->d->Xus [j] = 0 ;        
			  break;case e_T_INT:          if(!MOVE) Xi   =  (*UNI)->d->Obj[j]->d->Xi  [i];    (*UNI)->d->Obj[j]->d->Xi  [i] =  (*UNI)->d->Obj[i]->d->Xi  [j];    if(!MOVE) (*UNI)->d->Obj[i]->d->Xi  [j] = Xi   ;  else  (*UNI)->d->Obj[i]->d->Xi  [j] = 0 ;        
			  break;case e_T_UINT:         if(!MOVE) Xui  =  (*UNI)->d->Obj[j]->d->Xui [i];    (*UNI)->d->Obj[j]->d->Xui [i] =  (*UNI)->d->Obj[i]->d->Xui [j];    if(!MOVE) (*UNI)->d->Obj[i]->d->Xui [j] = Xui  ;  else  (*UNI)->d->Obj[i]->d->Xui [j] = 0 ;        
			  break;case e_T_LONG:         if(!MOVE) Xl   =  (*UNI)->d->Obj[j]->d->Xl  [i];    (*UNI)->d->Obj[j]->d->Xl  [i] =  (*UNI)->d->Obj[i]->d->Xl  [j];    if(!MOVE) (*UNI)->d->Obj[i]->d->Xl  [j] = Xl   ;  else  (*UNI)->d->Obj[i]->d->Xl  [j] = 0 ;        
			  break;case e_T_ULONG:        if(!MOVE) Xul  =  (*UNI)->d->Obj[j]->d->Xul [i];    (*UNI)->d->Obj[j]->d->Xul [i] =  (*UNI)->d->Obj[i]->d->Xul [j];    if(!MOVE) (*UNI)->d->Obj[i]->d->Xul [j] = Xul  ;  else  (*UNI)->d->Obj[i]->d->Xul [j] = 0 ;        
			  break;case e_T_FLOAT:        if(!MOVE) Xf   =  (*UNI)->d->Obj[j]->d->Xf  [i];    (*UNI)->d->Obj[j]->d->Xf  [i] =  (*UNI)->d->Obj[i]->d->Xf  [j];    if(!MOVE) (*UNI)->d->Obj[i]->d->Xf  [j] = Xf   ;  else  (*UNI)->d->Obj[i]->d->Xf  [j] = 0.0 ;      
			  break;case e_T_DOUBLE:       if(!MOVE) Xd   =  (*UNI)->d->Obj[j]->d->Xd  [i];    (*UNI)->d->Obj[j]->d->Xd  [i] =  (*UNI)->d->Obj[i]->d->Xd  [j];    if(!MOVE) (*UNI)->d->Obj[i]->d->Xd  [j] = Xd   ;  else  (*UNI)->d->Obj[i]->d->Xd  [j] = 0.0 ;      
			  break;case e_T_LONG_DOUBLE:  if(!MOVE) Xld  =  (*UNI)->d->Obj[j]->d->Xld [i];    (*UNI)->d->Obj[j]->d->Xld [i] =  (*UNI)->d->Obj[i]->d->Xld [j];    if(!MOVE) (*UNI)->d->Obj[i]->d->Xld [j] = Xld  ;  else  (*UNI)->d->Obj[i]->d->Xld [j] = 0.0 ;      
			  break;                                                                                                                                                                                             
		    } // switch Sub_dType	                                                                                                                                                                             
		break;	                                                                                                                                                                                                 
		case e_T_ITEM_DATA:                                                                                                                                                                                      
		    switch( Sub_dType ) {                                                                                                                                                                                
		            case e_T_MATRIX_DATA:  if(!MOVE) Mat  = (*UNI)->d->Item[j]->d->Mat [i];   (*UNI)->d->Item[j]->d->Mat [i] = (*UNI)->d->Item[i]->d->Mat [j];    if(!MOVE) (*UNI)->d->Item[i]->d->Mat [j] = Mat ;  else  (*UNI)->d->Item[i]->d->Mat [j] = NULL ;;  
		      break;case e_T_VECTOR_DATA:  if(!MOVE) Vec  = (*UNI)->d->Item[j]->d->Vec [i];   (*UNI)->d->Item[j]->d->Vec [i] = (*UNI)->d->Item[i]->d->Vec [j];    if(!MOVE) (*UNI)->d->Item[i]->d->Vec [j] = Vec ;  else  (*UNI)->d->Item[i]->d->Vec [j] = NULL ;;  
		      break;case e_T_OBJECT_DATA:  if(!MOVE) Obj  = (*UNI)->d->Item[j]->d->Obj [i];   (*UNI)->d->Item[j]->d->Obj [i] = (*UNI)->d->Item[i]->d->Obj [j];    if(!MOVE) (*UNI)->d->Item[i]->d->Obj [j] = Obj ;  else  (*UNI)->d->Item[i]->d->Obj [j] = NULL ;;  
		      break;case e_T_ITEM_DATA:    if(!MOVE) Item = (*UNI)->d->Item[j]->d->Item[i];   (*UNI)->d->Item[j]->d->Item[i] = (*UNI)->d->Item[i]->d->Item[j];    if(!MOVE) (*UNI)->d->Item[i]->d->Item[j] = Item;  else  (*UNI)->d->Item[i]->d->Item[j] = NULL ;;  
		      break;case e_T_DATASET_DATA: if(!MOVE) DSet = (*UNI)->d->Item[j]->d->DSet[i];   (*UNI)->d->Item[j]->d->DSet[i] = (*UNI)->d->Item[i]->d->DSet[j];    if(!MOVE) (*UNI)->d->Item[i]->d->DSet[j] = DSet;  else  (*UNI)->d->Item[i]->d->DSet[j] = NULL ;;  
		      break;case e_T_SERIES_DATA:  if(!MOVE) Ser  = (*UNI)->d->Item[j]->d->Ser [i];   (*UNI)->d->Item[j]->d->Ser [i] = (*UNI)->d->Item[i]->d->Ser [j];    if(!MOVE) (*UNI)->d->Item[i]->d->Ser [j] = Ser ;  else  (*UNI)->d->Item[i]->d->Ser [j] = NULL ;;  
			  break;case e_T_CHAR:         if(!MOVE) Xc   = (*UNI)->d->Item[j]->d->Xc  [i];   (*UNI)->d->Item[j]->d->Xc  [i] = (*UNI)->d->Item[i]->d->Xc  [j];    if(!MOVE) (*UNI)->d->Item[i]->d->Xc  [j] = Xc  ;  else  (*UNI)->d->Item[i]->d->Xc  [j] = 0 ;   ;  
			  break;case e_T_UCHAR:        if(!MOVE) Xuc  = (*UNI)->d->Item[j]->d->Xuc [i];   (*UNI)->d->Item[j]->d->Xuc [i] = (*UNI)->d->Item[i]->d->Xuc [j];    if(!MOVE) (*UNI)->d->Item[i]->d->Xuc [j] = Xuc ;  else  (*UNI)->d->Item[i]->d->Xuc [j] = 0 ;   ;  
			  break;case e_T_SHORT:        if(!MOVE) Xs   = (*UNI)->d->Item[j]->d->Xs  [i];   (*UNI)->d->Item[j]->d->Xs  [i] = (*UNI)->d->Item[i]->d->Xs  [j];    if(!MOVE) (*UNI)->d->Item[i]->d->Xs  [j] = Xs  ;  else  (*UNI)->d->Item[i]->d->Xs  [j] = 0 ;   ;  
			  break;case e_T_USHORT:       if(!MOVE) Xus  = (*UNI)->d->Item[j]->d->Xus [i];   (*UNI)->d->Item[j]->d->Xus [i] = (*UNI)->d->Item[i]->d->Xus [j];    if(!MOVE) (*UNI)->d->Item[i]->d->Xus [j] = Xus ;  else  (*UNI)->d->Item[i]->d->Xus [j] = 0 ;   ;  
			  break;case e_T_INT:          if(!MOVE) Xi   = (*UNI)->d->Item[j]->d->Xi  [i];   (*UNI)->d->Item[j]->d->Xi  [i] = (*UNI)->d->Item[i]->d->Xi  [j];    if(!MOVE) (*UNI)->d->Item[i]->d->Xi  [j] = Xi  ;  else  (*UNI)->d->Item[i]->d->Xi  [j] = 0 ;   ;  
			  break;case e_T_UINT:         if(!MOVE) Xui  = (*UNI)->d->Item[j]->d->Xui [i];   (*UNI)->d->Item[j]->d->Xui [i] = (*UNI)->d->Item[i]->d->Xui [j];    if(!MOVE) (*UNI)->d->Item[i]->d->Xui [j] = Xui ;  else  (*UNI)->d->Item[i]->d->Xui [j] = 0 ;   ;  
			  break;case e_T_LONG:         if(!MOVE) Xl   = (*UNI)->d->Item[j]->d->Xl  [i];   (*UNI)->d->Item[j]->d->Xl  [i] = (*UNI)->d->Item[i]->d->Xl  [j];    if(!MOVE) (*UNI)->d->Item[i]->d->Xl  [j] = Xl  ;  else  (*UNI)->d->Item[i]->d->Xl  [j] = 0 ;   ;  
			  break;case e_T_ULONG:        if(!MOVE) Xul  = (*UNI)->d->Item[j]->d->Xul [i];   (*UNI)->d->Item[j]->d->Xul [i] = (*UNI)->d->Item[i]->d->Xul [j];    if(!MOVE) (*UNI)->d->Item[i]->d->Xul [j] = Xul ;  else  (*UNI)->d->Item[i]->d->Xul [j] = 0 ;   ;  
			  break;case e_T_FLOAT:        if(!MOVE) Xf   = (*UNI)->d->Item[j]->d->Xf  [i];   (*UNI)->d->Item[j]->d->Xf  [i] = (*UNI)->d->Item[i]->d->Xf  [j];    if(!MOVE) (*UNI)->d->Item[i]->d->Xf  [j] = Xf  ;  else  (*UNI)->d->Item[i]->d->Xf  [j] = 0.0 ; ;  
			  break;case e_T_DOUBLE:       if(!MOVE) Xd   = (*UNI)->d->Item[j]->d->Xd  [i];   (*UNI)->d->Item[j]->d->Xd  [i] = (*UNI)->d->Item[i]->d->Xd  [j];    if(!MOVE) (*UNI)->d->Item[i]->d->Xd  [j] = Xd  ;  else  (*UNI)->d->Item[i]->d->Xd  [j] = 0.0 ; ;  
			  break;case e_T_LONG_DOUBLE:  if(!MOVE) Xld  = (*UNI)->d->Item[j]->d->Xld [i];   (*UNI)->d->Item[j]->d->Xld [i] = (*UNI)->d->Item[i]->d->Xld [j];    if(!MOVE) (*UNI)->d->Item[i]->d->Xld [j] = Xld ;  else  (*UNI)->d->Item[i]->d->Xld [j] = 0.0 ; ;  
			  break;                                                                                                                                                                                            
		    } // switch Sub_dType	                                                                                                                                                                            
		break;	                                                                                                                                                                                                
		case e_T_DATASET_DATA:                                                                                                                                                                                  
		    switch( Sub_dType ) {                                                                                                                                                                               
		            case e_T_MATRIX_DATA:  if(!MOVE) Mat  = (*UNI)->d->DSet[j]->d->Mat [i];   (*UNI)->d->DSet[j]->d->Mat [i] = (*UNI)->d->DSet[i]->d->Mat [j];    if(!MOVE) (*UNI)->d->DSet[i]->d->Mat [j] = Mat ;  else  (*UNI)->d->DSet[i]->d->Mat [j] = NULL ;;  
		      break;case e_T_VECTOR_DATA:  if(!MOVE) Vec  = (*UNI)->d->DSet[j]->d->Vec [i];   (*UNI)->d->DSet[j]->d->Vec [i] = (*UNI)->d->DSet[i]->d->Vec [j];    if(!MOVE) (*UNI)->d->DSet[i]->d->Vec [j] = Vec ;  else  (*UNI)->d->DSet[i]->d->Vec [j] = NULL ;;  
		      break;case e_T_OBJECT_DATA:  if(!MOVE) Obj  = (*UNI)->d->DSet[j]->d->Obj [i];   (*UNI)->d->DSet[j]->d->Obj [i] = (*UNI)->d->DSet[i]->d->Obj [j];    if(!MOVE) (*UNI)->d->DSet[i]->d->Obj [j] = Obj ;  else  (*UNI)->d->DSet[i]->d->Obj [j] = NULL ;;  
		      break;case e_T_ITEM_DATA:    if(!MOVE) Item = (*UNI)->d->DSet[j]->d->Item[i];   (*UNI)->d->DSet[j]->d->Item[i] = (*UNI)->d->DSet[i]->d->Item[j];    if(!MOVE) (*UNI)->d->DSet[i]->d->Item[j] = Item;  else  (*UNI)->d->DSet[i]->d->Item[j] = NULL ;;  
		      break;case e_T_DATASET_DATA: if(!MOVE) DSet = (*UNI)->d->DSet[j]->d->DSet[i];   (*UNI)->d->DSet[j]->d->DSet[i] = (*UNI)->d->DSet[i]->d->DSet[j];    if(!MOVE) (*UNI)->d->DSet[i]->d->DSet[j] = DSet;  else  (*UNI)->d->DSet[i]->d->DSet[j] = NULL ;;  
		      break;case e_T_SERIES_DATA:  if(!MOVE) Ser  = (*UNI)->d->DSet[j]->d->Ser [i];   (*UNI)->d->DSet[j]->d->Ser [i] = (*UNI)->d->DSet[i]->d->Ser [j];    if(!MOVE) (*UNI)->d->DSet[i]->d->Ser [j] = Ser ;  else  (*UNI)->d->DSet[i]->d->Ser [j] = NULL ;;  
			  break;case e_T_CHAR:         if(!MOVE) Xc   = (*UNI)->d->DSet[j]->d->Xc  [i];   (*UNI)->d->DSet[j]->d->Xc  [i] = (*UNI)->d->DSet[i]->d->Xc  [j];    if(!MOVE) (*UNI)->d->DSet[i]->d->Xc  [j] = Xc  ;  else  (*UNI)->d->DSet[i]->d->Xc  [j] = 0 ;   ;  
			  break;case e_T_UCHAR:        if(!MOVE) Xuc  = (*UNI)->d->DSet[j]->d->Xuc [i];   (*UNI)->d->DSet[j]->d->Xuc [i] = (*UNI)->d->DSet[i]->d->Xuc [j];    if(!MOVE) (*UNI)->d->DSet[i]->d->Xuc [j] = Xuc ;  else  (*UNI)->d->DSet[i]->d->Xuc [j] = 0 ;   ;  
			  break;case e_T_SHORT:        if(!MOVE) Xs   = (*UNI)->d->DSet[j]->d->Xs  [i];   (*UNI)->d->DSet[j]->d->Xs  [i] = (*UNI)->d->DSet[i]->d->Xs  [j];    if(!MOVE) (*UNI)->d->DSet[i]->d->Xs  [j] = Xs  ;  else  (*UNI)->d->DSet[i]->d->Xs  [j] = 0 ;   ;  
			  break;case e_T_USHORT:       if(!MOVE) Xus  = (*UNI)->d->DSet[j]->d->Xus [i];   (*UNI)->d->DSet[j]->d->Xus [i] = (*UNI)->d->DSet[i]->d->Xus [j];    if(!MOVE) (*UNI)->d->DSet[i]->d->Xus [j] = Xus ;  else  (*UNI)->d->DSet[i]->d->Xus [j] = 0 ;   ;  
			  break;case e_T_INT:          if(!MOVE) Xi   = (*UNI)->d->DSet[j]->d->Xi  [i];   (*UNI)->d->DSet[j]->d->Xi  [i] = (*UNI)->d->DSet[i]->d->Xi  [j];    if(!MOVE) (*UNI)->d->DSet[i]->d->Xi  [j] = Xi  ;  else  (*UNI)->d->DSet[i]->d->Xi  [j] = 0 ;   ;  
			  break;case e_T_UINT:         if(!MOVE) Xui  = (*UNI)->d->DSet[j]->d->Xui [i];   (*UNI)->d->DSet[j]->d->Xui [i] = (*UNI)->d->DSet[i]->d->Xui [j];    if(!MOVE) (*UNI)->d->DSet[i]->d->Xui [j] = Xui ;  else  (*UNI)->d->DSet[i]->d->Xui [j] = 0 ;   ;  
			  break;case e_T_LONG:         if(!MOVE) Xl   = (*UNI)->d->DSet[j]->d->Xl  [i];   (*UNI)->d->DSet[j]->d->Xl  [i] = (*UNI)->d->DSet[i]->d->Xl  [j];    if(!MOVE) (*UNI)->d->DSet[i]->d->Xl  [j] = Xl  ;  else  (*UNI)->d->DSet[i]->d->Xl  [j] = 0 ;   ;  
			  break;case e_T_ULONG:        if(!MOVE) Xul  = (*UNI)->d->DSet[j]->d->Xul [i];   (*UNI)->d->DSet[j]->d->Xul [i] = (*UNI)->d->DSet[i]->d->Xul [j];    if(!MOVE) (*UNI)->d->DSet[i]->d->Xul [j] = Xul ;  else  (*UNI)->d->DSet[i]->d->Xul [j] = 0 ;   ;  
			  break;case e_T_FLOAT:        if(!MOVE) Xf   = (*UNI)->d->DSet[j]->d->Xf  [i];   (*UNI)->d->DSet[j]->d->Xf  [i] = (*UNI)->d->DSet[i]->d->Xf  [j];    if(!MOVE) (*UNI)->d->DSet[i]->d->Xf  [j] = Xf  ;  else  (*UNI)->d->DSet[i]->d->Xf  [j] = 0.0 ; ;  
			  break;case e_T_DOUBLE:       if(!MOVE) Xd   = (*UNI)->d->DSet[j]->d->Xd  [i];   (*UNI)->d->DSet[j]->d->Xd  [i] = (*UNI)->d->DSet[i]->d->Xd  [j];    if(!MOVE) (*UNI)->d->DSet[i]->d->Xd  [j] = Xd  ;  else  (*UNI)->d->DSet[i]->d->Xd  [j] = 0.0 ; ;  
			  break;case e_T_LONG_DOUBLE:  if(!MOVE) Xld  = (*UNI)->d->DSet[j]->d->Xld [i];   (*UNI)->d->DSet[j]->d->Xld [i] = (*UNI)->d->DSet[i]->d->Xld [j];    if(!MOVE) (*UNI)->d->DSet[i]->d->Xld [j] = Xld ;  else  (*UNI)->d->DSet[i]->d->Xld [j] = 0.0 ; ;  
			  break;                                                                                                                                                                                            
		    } // switch Sub_dType	                                                                                                                                                                            
		break;	                                                                                                                                                                                                
		case e_T_SERIES_DATA:                                                                                                                                                                                   
		    switch( Sub_dType ) {                                                                                                                                                                               
		            case e_T_MATRIX_DATA:  if(!MOVE) Mat  =  (*UNI)->d->Ser[j]->d->Mat [i];    (*UNI)->d->Ser[j]->d->Mat [i] =  (*UNI)->d->Ser[i]->d->Mat [j];    if(!MOVE) (*UNI)->d->Ser[i]->d->Mat [j] = Mat  ;  else  (*UNI)->d->Ser[i]->d->Mat [j] = NULL ;    
		      break;case e_T_VECTOR_DATA:  if(!MOVE) Vec  =  (*UNI)->d->Ser[j]->d->Vec [i];    (*UNI)->d->Ser[j]->d->Vec [i] =  (*UNI)->d->Ser[i]->d->Vec [j];    if(!MOVE) (*UNI)->d->Ser[i]->d->Vec [j] = Vec  ;  else  (*UNI)->d->Ser[i]->d->Vec [j] = NULL ;    
		      break;case e_T_OBJECT_DATA:  if(!MOVE) Obj  =  (*UNI)->d->Ser[j]->d->Obj [i];    (*UNI)->d->Ser[j]->d->Obj [i] =  (*UNI)->d->Ser[i]->d->Obj [j];    if(!MOVE) (*UNI)->d->Ser[i]->d->Obj [j] = Obj  ;  else  (*UNI)->d->Ser[i]->d->Obj [j] = NULL ;    
		      break;case e_T_ITEM_DATA:    if(!MOVE) Item =  (*UNI)->d->Ser[j]->d->Item[i];    (*UNI)->d->Ser[j]->d->Item[i] =  (*UNI)->d->Ser[i]->d->Item[j];    if(!MOVE) (*UNI)->d->Ser[i]->d->Item[j] = Item ;  else  (*UNI)->d->Ser[i]->d->Item[j] = NULL ;    
		      break;case e_T_DATASET_DATA: if(!MOVE) DSet =  (*UNI)->d->Ser[j]->d->DSet[i];    (*UNI)->d->Ser[j]->d->DSet[i] =  (*UNI)->d->Ser[i]->d->DSet[j];    if(!MOVE) (*UNI)->d->Ser[i]->d->DSet[j] = DSet ;  else  (*UNI)->d->Ser[i]->d->DSet[j] = NULL ;    
		      break;case e_T_SERIES_DATA:  if(!MOVE) Ser  =  (*UNI)->d->Ser[j]->d->Ser [i];    (*UNI)->d->Ser[j]->d->Ser [i] =  (*UNI)->d->Ser[i]->d->Ser [j];    if(!MOVE) (*UNI)->d->Ser[i]->d->Ser [j] = Ser  ;  else  (*UNI)->d->Ser[i]->d->Ser [j] = NULL ;    
			  break;case e_T_CHAR:         if(!MOVE) Xc   =  (*UNI)->d->Ser[j]->d->Xc  [i];    (*UNI)->d->Ser[j]->d->Xc  [i] =  (*UNI)->d->Ser[i]->d->Xc  [j];    if(!MOVE) (*UNI)->d->Ser[i]->d->Xc  [j] = Xc   ;  else  (*UNI)->d->Ser[i]->d->Xc  [j] = 0 ;       
			  break;case e_T_UCHAR:        if(!MOVE) Xuc  =  (*UNI)->d->Ser[j]->d->Xuc [i];    (*UNI)->d->Ser[j]->d->Xuc [i] =  (*UNI)->d->Ser[i]->d->Xuc [j];    if(!MOVE) (*UNI)->d->Ser[i]->d->Xuc [j] = Xuc  ;  else  (*UNI)->d->Ser[i]->d->Xuc [j] = 0 ;       
			  break;case e_T_SHORT:        if(!MOVE) Xs   =  (*UNI)->d->Ser[j]->d->Xs  [i];    (*UNI)->d->Ser[j]->d->Xs  [i] =  (*UNI)->d->Ser[i]->d->Xs  [j];    if(!MOVE) (*UNI)->d->Ser[i]->d->Xs  [j] = Xs   ;  else  (*UNI)->d->Ser[i]->d->Xs  [j] = 0 ;       
			  break;case e_T_USHORT:       if(!MOVE) Xus  =  (*UNI)->d->Ser[j]->d->Xus [i];    (*UNI)->d->Ser[j]->d->Xus [i] =  (*UNI)->d->Ser[i]->d->Xus [j];    if(!MOVE) (*UNI)->d->Ser[i]->d->Xus [j] = Xus  ;  else  (*UNI)->d->Ser[i]->d->Xus [j] = 0 ;       
			  break;case e_T_INT:          if(!MOVE) Xi   =  (*UNI)->d->Ser[j]->d->Xi  [i];    (*UNI)->d->Ser[j]->d->Xi  [i] =  (*UNI)->d->Ser[i]->d->Xi  [j];    if(!MOVE) (*UNI)->d->Ser[i]->d->Xi  [j] = Xi   ;  else  (*UNI)->d->Ser[i]->d->Xi  [j] = 0 ;       
			  break;case e_T_UINT:         if(!MOVE) Xui  =  (*UNI)->d->Ser[j]->d->Xui [i];    (*UNI)->d->Ser[j]->d->Xui [i] =  (*UNI)->d->Ser[i]->d->Xui [j];    if(!MOVE) (*UNI)->d->Ser[i]->d->Xui [j] = Xui  ;  else  (*UNI)->d->Ser[i]->d->Xui [j] = 0 ;       
			  break;case e_T_LONG:         if(!MOVE) Xl   =  (*UNI)->d->Ser[j]->d->Xl  [i];    (*UNI)->d->Ser[j]->d->Xl  [i] =  (*UNI)->d->Ser[i]->d->Xl  [j];    if(!MOVE) (*UNI)->d->Ser[i]->d->Xl  [j] = Xl   ;  else  (*UNI)->d->Ser[i]->d->Xl  [j] = 0 ;       
			  break;case e_T_ULONG:        if(!MOVE) Xul  =  (*UNI)->d->Ser[j]->d->Xul [i];    (*UNI)->d->Ser[j]->d->Xul [i] =  (*UNI)->d->Ser[i]->d->Xul [j];    if(!MOVE) (*UNI)->d->Ser[i]->d->Xul [j] = Xul  ;  else  (*UNI)->d->Ser[i]->d->Xul [j] = 0 ;       
			  break;case e_T_FLOAT:        if(!MOVE) Xf   =  (*UNI)->d->Ser[j]->d->Xf  [i];    (*UNI)->d->Ser[j]->d->Xf  [i] =  (*UNI)->d->Ser[i]->d->Xf  [j];    if(!MOVE) (*UNI)->d->Ser[i]->d->Xf  [j] = Xf   ;  else  (*UNI)->d->Ser[i]->d->Xf  [j] = 0.0 ;     
			  break;case e_T_DOUBLE:       if(!MOVE) Xd   =  (*UNI)->d->Ser[j]->d->Xd  [i];    (*UNI)->d->Ser[j]->d->Xd  [i] =  (*UNI)->d->Ser[i]->d->Xd  [j];    if(!MOVE) (*UNI)->d->Ser[i]->d->Xd  [j] = Xd   ;  else  (*UNI)->d->Ser[i]->d->Xd  [j] = 0.0 ;     
			  break;case e_T_LONG_DOUBLE:  if(!MOVE) Xld  =  (*UNI)->d->Ser[j]->d->Xld [i];    (*UNI)->d->Ser[j]->d->Xld [i] =  (*UNI)->d->Ser[i]->d->Xld [j];    if(!MOVE) (*UNI)->d->Ser[i]->d->Xld [j] = Xld  ;  else  (*UNI)->d->Ser[i]->d->Xld [j] = 0.0 ;     
			  break;                                                                                                                                                                                                                                           
		    } // switch Sub_dType	                                                                                                                                                                                                                           
		break;	                                                                                                                                                                                                                                               
	} // switch( (*UNI)->dType )	                                                                                                                                                                                                                           
   	
} // XchangeSubElemContent


FILE *
OpenFileUniStruct( int MODE, const char* FileName ) {
	
	enum{ CREATE = 3,  // creates !ALWAYS! a new empty file  --> (previous CONTENT of an existing file WILL BE LOST !!!)
	                   // and opens it   for  READING + WRITING  	                       
	      WRITE  = 2,  // opens the file for  READING + WRITING  (previous content will NOT be deleted)
	      READ   = 1 }; // opens the file for  RADING ONLY
 	
 	FILE* F = NULL;
 	
 	switch( MODE ) { 
		case READ:
		 	F = fopen( FileName , "rb" );  // open file for READING ONLY 
		break;
		case WRITE:
		 	F = fopen( FileName , "rb+" );  // open file for READING + WRITING (! NO TRUNCATION: previous content will not be deleted !)
		break;
 		case CREATE:
		 	if( (F = fopen( FileName , "wb" )) == NULL ) break; // !CREATE! an empty file..		 
		 	fclose(F); //..close it..	
		 	F = fopen( FileName , "rb+" );  // re-open file for READING + WRITING
		break;
 	}
 					 	
 	return(F);
} // OpenFileUniStruct
 	
 	
long
BlockReadUniStruct( FILE *F,  long Fpos_0, // implicitly limits the FILE SIZE to < 2GB
                     TpointerUniStruct *UNI,  
                     unsigned long L0,  unsigned long NL,  unsigned long *NR,  int *E ) {

	const long E_pos = -1;  // ERROR-INDICATOR:  unphysical value for a file position
	
	long Fpos;
	
	int Seek_OK;
	int  err = 0;	
	unsigned long NR_sub;
	size_t    N_r;
	u_long_t  L_r = 0;  // accumulated number of BYTES read
	u_long_t  i;	
	u_long_t  F_UniSize, UniSize_Old;
	short dType, pType;
	long bookmark_dp_SeekPos;
	long *d_SeekPos = NULL;
	long *p_SeekPos = NULL;
	long  dummy_SeekPos = -1;

	Fpos = E_pos; // indicate ERROR
	
	*E = -1; // raise ERROR flag
	*NR = 0;

    // CHECK ARGUMENTS:  ON ERROR --> EXIT
    
    // is file pointer valid ?  
    if( F == NULL )return(E_pos);    
    // seek file to writing start position
		Seek_OK = -1;
		if( Fpos_0 < 0 ) {
		// actually DO NOTHING
		// write at actual file position	
			Seek_OK = 1;
			// seek LINE 
			//	Fpos_0 = fSeekLine( F , L0 );
			//	if( Fpos >= 0 )  Seek_OK = 1;
		}else{
		// seek file position	
		    if( Fpos_0 == LONG_MAX ) {
		    	err = fseek( F , 0L , SEEK_END );			    	
		    }else{
		    	err = fseek( F , Fpos_0 , SEEK_SET );
		    }	
			if( !err )  Seek_OK = 1;
		}
	if( !Seek_OK )return(E_pos);
	
	// is there something to be done ?
	if( NL == 0 ) { //..oh - nothing to do --> we're finished :)
		*E = 0;  // indicate SUCCESS
		Fpos = ftell(F);    return(Fpos); //  --> EXIT SUCCESSFULLY
	}
			
	// NEXT: start reading the first information from file to see what's inside
	L_r += fREAD( F, &F_UniSize, u_long_t, 1, &N_r, &err );    if(err)return(E_pos); // EXIT ON ERROR
	L_r += fREAD( F, &dType, short,   1, &N_r, &err );    if(err)return(E_pos); // EXIT ON ERROR	
	L_r += fREAD( F, &pType, short,   1, &N_r, &err );    if(err)return(E_pos); // EXIT ON ERROR
	
    // if the intention was to read ALL elements, correct  NL 
    // to actual number of elements contained in the file
    if( (NL > F_UniSize) || (NL == ULONG_MAX) ) { 
    	NL = F_UniSize;
    }	
	
	// is dType information valid ?
	switch (dType ) {       
		//   UNI-STRUCTURE-TYPES    +     ELEMENTARY DATA-TYPES (1 - DIMENSIONAL ARRAYS OF GENERIC C-TYPES)
	 	case e_T_VECTOR_DATA:        case e_T_CHAR:    case e_T_UCHAR:
	    case e_T_MATRIX_DATA:        case e_T_SHORT:   case e_T_USHORT:
	    case e_T_ITEM_DATA:          case e_T_INT:     case e_T_UINT:
	    case e_T_OBJECT_DATA:        case e_T_LONG:    case e_T_ULONG:
	    case e_T_SERIES_DATA:        case e_T_FLOAT:
	    case e_T_DATASET_DATA:       case e_T_DOUBLE: 
	                                 case e_T_LONG_DOUBLE: { /* O.K all data types supported! */ }                             	 
          break;        
        default:  // unsupported type detected	  
        	return(E_pos);  // EXIT ON ERROR
          break;  
	} // switch (dType )
	
	// is pType information valid ?
	switch (pType ) {       
	 	case e_T_NO_PROP:       		
	 	case e_T_BASE_PROP:       
	 	case e_T_VECTOR_PROP:       
	    case e_T_MATRIX_PROP:       
	    case e_T_ITEM_PROP:         
	    case e_T_OBJECT_PROP:       
	    case e_T_SERIES_PROP:       
	    case e_T_DATASET_PROP: { /* O.K all property types supported! */ }                             	 	                                
          break;        
        default:  // unsupported type detected	  
        	return(E_pos);  // EXIT ON ERROR
          break;  
	} // switch (pType )
	
		
    // CONTINUE ARGUMENT CHECK  &  PREPARE UNI-STRUCT
        
    // UniStruct - OBJECT MUST EXIST !!  -->  evtl. allocate memory or destroy old elements
	// does the !pointer! to UniStruct exist ?	
	if( UNI == NULL )return(E_pos);  
	// does UniStruct exist ?	
	if( *UNI == NULL ) { // if not --> create one of size  NL 
		// if a new object will be created, then index L0 must be 0
		if( L0 != 0 )return(E_pos); // EXIT ON ERROR
		
		if( CreateUniStruct( UNI , NL , dType , pType ) )return(E_pos);
		
	}else{ // --> UniStruct exists
		
		if( (*UNI)->dType != dType)return(E_pos);
		if( (*UNI)->pType != pType)return(E_pos);
		
		UniSize_Old = (*UNI)->Size;  
		
		if( UniSize_Old == 0 ) {
			
			if( ResizeUniStruct( UNI , NL ) )return(E_pos);   // EXIT ON ERROR		
			
		}else{
			
			// destroy existing sub-elements which are intended to be overwritten
			for( i=L0; i<UniSize_Old; i++ ) { // execute only if index L0 points inside actual size
				switch( dType ) {
						  case e_T_MATRIX_DATA:  if( DestroyUniStruct( &((*UNI)->d->Mat[i]) ) )return(E_pos);   // EXIT ON ERROR		 
					break;case e_T_OBJECT_DATA:  if( DestroyUniStruct( &((*UNI)->d->Obj[i]) ) )return(E_pos);   // EXIT ON ERROR		 
					break;case e_T_DATASET_DATA: if( DestroyUniStruct( &((*UNI)->d->DSet[i]) ) )return(E_pos);   // EXIT ON ERROR		 
					break;case e_T_VECTOR_DATA:  if( DestroyUniStruct( &((*UNI)->d->Vec[i]) ) )return(E_pos);   // EXIT ON ERROR		 
					break;case e_T_ITEM_DATA:    if( DestroyUniStruct( &((*UNI)->d->Item[i]) ) )return(E_pos);   // EXIT ON ERROR		 
					break;case e_T_SERIES_DATA:  if( DestroyUniStruct( &((*UNI)->d->Ser[i]) ) )return(E_pos);   // EXIT ON ERROR		 
				} // switch( dType ) 
				switch( pType ) {
						  case e_T_MATRIX_PROP:  if( DestroyGroupProp( &((*UNI)->p->Mat[i]) ) )return(E_pos);   // EXIT ON ERROR		 
					break;case e_T_OBJECT_PROP:  if( DestroyGroupProp( &((*UNI)->p->Obj[i]) ) )return(E_pos);   // EXIT ON ERROR		 
					break;case e_T_DATASET_PROP: if( DestroyGroupProp( &((*UNI)->p->DSet[i]) ) )return(E_pos);   // EXIT ON ERROR		 
					break;case e_T_VECTOR_PROP:  if( DestroyEntityProp( &((*UNI)->p->Vec[i]) ) )return(E_pos);   // EXIT ON ERROR		 
					break;case e_T_ITEM_PROP:    if( DestroyEntityProp( &((*UNI)->p->Item[i]) ) )return(E_pos);   // EXIT ON ERROR		 
					break;case e_T_SERIES_PROP:  if( DestroyEntityProp( &((*UNI)->p->Ser[i]) ) )return(E_pos);   // EXIT ON ERROR		 
					break;case e_T_BASE_PROP:    if( DestroyBaseProp( &((*UNI)->p->Xp[i]) ) )return(E_pos);   // EXIT ON ERROR		 
				} // switch( pType ) 
			} // for(i=L0;i<UniSize_Old;i++)				 			
			
			if( L0+NL > UniSize_Old ) {
				
				if( ResizeUniStruct( UNI , L0+NL ) )return(E_pos);   // EXIT ON ERROR		 
				
			}	
		} // if( UniSize_Old == 0 )	
						
	} // if( *UNI == NULL )..else..       
	
	// NOW UNI-STRUCT SHOULD EXISTS AND HAVE PROPER DIMENSIONS

	
	// bookmark actual file position for later return to update  d_SeekPos , p_SeekPos 
	bookmark_dp_SeekPos = ftell(F);  
	
	// allocate memory and read  d_SeekPos[0..(F_UniSize-1)]	
	if( !(d_SeekPos = Xmalloc( long, F_UniSize )) )return(E_pos); // EXIT ON ERROR
	L_r += fREAD( F, d_SeekPos, long, F_UniSize, &N_r, &err );    if(err)return(E_pos); // EXIT ON ERROR	
		
		
	if( (*UNI)->pType != e_T_NO_PROP ) {
		
		// allocate memory and read  p_SeekPos[0..(F_UniSize-1)]	
		if( !(p_SeekPos = Xmalloc( long, F_UniSize )) )return(E_pos); // EXIT ON ERROR
		L_r += fREAD( F, p_SeekPos, long, F_UniSize, &N_r, &err );    if(err)return(E_pos); // EXIT ON ERROR	
	
		for( i = L0;  i < L0+NL;  i++ ) {			
			// seek to BEGIN of   P R O P E R T I E S   of ELEMENT[i]
			
			dummy_SeekPos = p_SeekPos[i]; // for debugging puposes
			
			fseek( F , p_SeekPos[i] , SEEK_SET );
			
			switch((*UNI)->pType) {
				
					  case e_T_MATRIX_PROP:    L_r += ReadGroupProp( F, &((*UNI)->p->Mat[i]), &err );
				break;case e_T_OBJECT_PROP:    L_r += ReadGroupProp( F, &((*UNI)->p->Obj[i]), &err );
				break;case e_T_DATASET_PROP:   L_r += ReadGroupProp( F, &((*UNI)->p->DSet[i]), &err );
				
				break;case e_T_VECTOR_PROP:  //ReadEntityProp( F, )
				break;case e_T_ITEM_PROP:
				break;case e_T_SERIES_PROP: {}
				
				break;case e_T_BASE_PROP:   L_r += ReadBaseProp( F, &((*UNI)->p->Xp[i]), &err );
				
			} // switch((*UNI)->pType)	
			
			if(err)return(E_pos);
			
		} // for(i=L0;i<L0+NL;i++)
	} // if( (*UNI)->pType != e_T_NO_PROP ) 	


 !!!  W I C H T I G   bei den elementaren Typen mu� vorher noch 
                      ein  seek-to-data-begin  an die Position
                      d_SeekPos[0]  erfolgen.  
                      AUSSERDEM GIBT ES IN DIESEM FALL AUCH NUR
                      EINE EINZIGE POSITIONS-MARKE  d_SeekPos[0]  !!
  

  //  A L L O C A T E   M E M O R Y   FOR ELEMENTARY DATA-TYPES:  1 - DIMENSIONAL ARRAYS OF GENERIC C-TYPES
  //  S E E K   F I L E   TO START ELEMENT  L0   
    switch( (*UNI)->dType ) {
	  //   allocate space for  NL  elements and step over elements 0..L0-1
	      case   e_T_CHAR:  if( !( (*UNI)->d->Xc= Xmalloc( char, NL )) )return(E_pos); // EXIT ON ERROR
	                        if( !fseek( F , (long)(L0 * sizeof(char)), SEEK_CUR ) )return(E_pos);
	break;case e_T_UCHAR:   if( !( (*UNI)->d->Xuc= Xmalloc( u_char_t, NL )) )return(E_pos); // EXIT ON ERROR
	                        if( !fseek( F , (long)(L0 * sizeof(u_char_t)), SEEK_CUR ) )return(E_pos);
	break;case   e_T_SHORT: if( !( (*UNI)->d->Xs= Xmalloc( short, NL )) )return(E_pos); // EXIT ON ERROR
	                        if( !fseek( F , (long)(L0 * sizeof(short)), SEEK_CUR ) )return(E_pos);
	break;case e_T_USHORT:  if( !( (*UNI)->d->Xus= Xmalloc( u_short_t, NL )) )return(E_pos); // EXIT ON ERROR
	                        if( !fseek( F , (long)(L0 * sizeof(u_short_t)), SEEK_CUR ) )return(E_pos);
	break;case   e_T_INT:   if( !( (*UNI)->d->Xi= Xmalloc( int, NL )) )return(E_pos); // EXIT ON ERROR
	                        if( !fseek( F , (long)(L0 * sizeof(int)), SEEK_CUR ) )return(E_pos);
	break;case e_T_UINT:    if( !( (*UNI)->d->Xui= Xmalloc( u_int_t, NL )) )return(E_pos); // EXIT ON ERROR
	                        if( !fseek( F , (long)(L0 * sizeof(u_int_t)), SEEK_CUR ) )return(E_pos);
	break;case   e_T_LONG:  if( !( (*UNI)->d->Xl= Xmalloc( long, NL )) )return(E_pos); // EXIT ON ERROR
	                        if( !fseek( F , (long)(L0 * sizeof(long)), SEEK_CUR ) )return(E_pos);
	break;case e_T_ULONG:   if( !( (*UNI)->d->Xul= Xmalloc( u_long_t, NL )) )return(E_pos); // EXIT ON ERROR
	                        if( !fseek( F , (long)(L0 * sizeof(u_long_t)), SEEK_CUR ) )return(E_pos);
	
	break;case e_T_FLOAT:       if( !( (*UNI)->d->Xf= Xmalloc( float, NL )) )return(E_pos); // EXIT ON ERROR
	                            if( !fseek( F , (long)(L0 * sizeof(float)), SEEK_CUR ) )return(E_pos);
	break;case e_T_DOUBLE:      if( !( (*UNI)->d->Xd= Xmalloc( double, NL )) )return(E_pos); // EXIT ON ERROR
	                            if( !fseek( F , (long)(L0 * sizeof(double)), SEEK_CUR ) )return(E_pos);
	break;case e_T_LONG_DOUBLE: if( !( (*UNI)->d->Xld= Xmalloc( long double, NL )) )return(E_pos); // EXIT ON ERROR
	                            if( !fseek( F , (long)(L0 * sizeof(long double)), SEEK_CUR ) )return(E_pos);
    } //  // switch((*UNI)->dType)
		
    
  //  S T A R T   R E A D I N G
    switch( (*UNI)->dType ) {
	  // READ ELEMENTARY DATA-TYPES:  1 - DIMENSIONAL ARRAYS OF GENERIC C-TYPES
	  //   read  NL  elements starting at index  L0  
	      case   e_T_CHAR:  L_r += fREAD( F, (*UNI)->d->Xc, char, NL, &N_r, &err );    if(err)return(E_pos); // EXIT ON ERROR			  
	break;case e_T_UCHAR:   L_r += fREAD( F, (*UNI)->d->Xuc, u_char_t, NL, &N_r, &err );    if(err)return(E_pos); // EXIT ON ERROR			    
	break;case   e_T_SHORT: L_r += fREAD( F, (*UNI)->d->Xs, short, NL, &N_r, &err );    if(err)return(E_pos); // EXIT ON ERROR			    
	break;case e_T_USHORT:  L_r += fREAD( F, (*UNI)->d->Xus, u_short_t, NL, &N_r, &err );    if(err)return(E_pos); // EXIT ON ERROR			     
	break;case   e_T_INT:   L_r += fREAD( F, (*UNI)->d->Xi, int, NL, &N_r, &err );    if(err)return(E_pos); // EXIT ON ERROR			     
	break;case e_T_UINT:    L_r += fREAD( F, (*UNI)->d->Xui, u_int_t, NL, &N_r, &err );    if(err)return(E_pos); // EXIT ON ERROR			     
	break;case   e_T_LONG:  L_r += fREAD( F, (*UNI)->d->Xl, long, NL, &N_r, &err );    if(err)return(E_pos); // EXIT ON ERROR			     
	break;case e_T_ULONG:   L_r += fREAD( F, (*UNI)->d->Xul, u_long_t, NL, &N_r, &err );    if(err)return(E_pos); // EXIT ON ERROR			     
	
	break;case e_T_FLOAT:       L_r += fREAD( F, (*UNI)->d->Xf, float, NL, &N_r, &err );    if(err)return(E_pos); // EXIT ON ERROR			     
	break;case e_T_DOUBLE:      L_r += fREAD( F, (*UNI)->d->Xd, double, NL, &N_r, &err );    if(err)return(E_pos); // EXIT ON ERROR			     
	break;case e_T_LONG_DOUBLE: L_r += fREAD( F, (*UNI)->d->Xld, long double, NL, &N_r, &err );    if(err)return(E_pos); // EXIT ON ERROR			      
	    	
    default: // READ  R E C U R S I V E  STRUCTURES

		for( i = L0;  i < L0+NL;  i++ ) {		
	 		// seek to position:  BEGIN of   D A T A   of ELEMENT[i]
	
			dummy_SeekPos = d_SeekPos[i]; // for debugging puposes
				
			fseek( F , d_SeekPos[i] , SEEK_SET ); // SEEK TO ELEMENT INDEX  L0 
			
			switch((*UNI)->dType) {
				// TYPE OF MAIN STRUCTURE  UniStruct  =>  R E C U R S I V E   SUB-STRUCTURING      
				//   read the complete content of element[i] continuing
				//   at actual fpos (=-1)  starting with sub-element index (:0)
				//   traversing through all sub-elments (:LONG_MAX).
					  case e_T_MATRIX_DATA:  BlockReadUniStruct( F, -1, &((*UNI)->d->Mat[i]), 0, LONG_MAX, &NR_sub, &err );
				break;case e_T_OBJECT_DATA:  BlockReadUniStruct( F, -1, &((*UNI)->d->Obj[i]), 0, LONG_MAX, &NR_sub, &err );			                             			 
				break;case e_T_DATASET_DATA: BlockReadUniStruct( F, -1, &((*UNI)->d->DSet[i]), 0, LONG_MAX, &NR_sub, &err );			                              
				
				break;case e_T_VECTOR_DATA:  BlockReadUniStruct( F, -1, &((*UNI)->d->Vec[i]), 0, LONG_MAX, &NR_sub, &err );			                             
				break;case e_T_ITEM_DATA:    BlockReadUniStruct( F, -1, &((*UNI)->d->Item[i]), 0, LONG_MAX, &NR_sub, &err );			                             
				break;case e_T_SERIES_DATA:  BlockReadUniStruct( F, -1, &((*UNI)->d->Ser[i]), 0, LONG_MAX, &NR_sub, &err );			                             				
			} // switch((*UNI)->dType)	
						
				if(err)return(E_pos);
						
		} // for(i=L0;i<L0+NL;i++)
    } // switch((*UNI)->dType)

	// TESTING :  read back DUMMY DATA at end of file
	//		for( k=1; k<100; k++) {
	//			L_r += fREAD( F, &i, u_long_t, 1, &N_r, &err );    if(err)return(E_pos); // EXIT ON ERROR
	//		}


    // finally clean up : free memory of temporary vars
	if( d_SeekPos != NULL ){ free(d_SeekPos);  d_SeekPos = NULL; }
	if( p_SeekPos != NULL ){ free(p_SeekPos);  p_SeekPos = NULL; }
	
	Fpos = ftell(F);
	
	*E = 0; // indicate SUCCESS
			
	return(Fpos);                 
                     	
} // BlockReadUniStruct                     	


long
BlockWriteUniStruct( FILE *F,  long Fpos_0, // implicitly limits the FILE SIZE to < 2GB
                     TpointerUniStruct *UNI,  
                     unsigned long L0,  unsigned long NL,  unsigned long *NW,  int *E ) {
                     	
	const long E_pos = -1;  // ERROR-INDICATOR:  unphysical value for a file position
	
	long Fpos;
	
	long Fpos_actual;	
	int Seek_OK;
	int  err;	
	unsigned long NW_sub;
	size_t    N_w;
	u_long_t  L_w = 0;  // accumulated number of BYTES written
	u_long_t  i, k ;
	long bookmark_dp_SeekPos;
	u_long_t  N_SeekPos;
	long *d_SeekPos = NULL;
	long *p_SeekPos = NULL;
	long  dummy_SeekPos = -1;

	Fpos = E_pos; // indicate ERROR
	
	*E = -1; // raise ERROR flag
	*NW = 0;

    // CHECK ARGUMENTS:  ON ERROR --> EXIT
    
    // is file pointer valid ?
    if( F == NULL )return(E_pos);    
    // seek file to writing start position
		Seek_OK = -1;
		if( Fpos_0 < 0 ) {
		// actually DO NOTHING
		// write at actual file position	
			Seek_OK = 1;
			// seek LINE 
			//	Fpos_0 = fSeekLine( F , L0 );
			//	if( Fpos >= 0 )  Seek_OK = 1;
		}else{
		// seek file position	
		    if( Fpos_0 == LONG_MAX ) {
		    	err = fseek( F , 0L , SEEK_END );			    	
		    }else{
		    	err = fseek( F , Fpos_0 , SEEK_SET );
		    }	
			if( !err )  Seek_OK = 1;
		}
	if( !Seek_OK )return(E_pos);	
	
    // CONTINUE ARGUMENT CHECK
    
	// does the !pointer! to UniStruct exist ?	
	if( UNI == NULL )return(E_pos);  
	// does UniStruct exist ?	
	if( *UNI == NULL )return(E_pos);       
    // is UniStruct empty ?
	if( (*UNI)->Size == 0 )return(E_pos);	
	// is start index valid ?
	if( L0 > (*UNI)->Size-1 )return(E_pos);	
	// is there something to be done ?
	if( NL == 0 ) { //..oh - nothing to do --> we're finished :)
		*E = 0;  // indicate SUCCESS
		Fpos = ftell(F);    return(Fpos); //  --> EXIT SUCCESSFULLY
	}else{ //..yes, there is some work 	
		// check stop index --> eventually correct  NL  if necessary
		if( L0+NL-1 > (*UNI)->Size-1 ) NL = (*UNI)->Size - L0;
	}	
	
		
    // NL will be the number of elements transferred!  NOT  (*UNI)->Size  !
	L_w += fWRITE( F, &NL, u_long_t, 1, &N_w, &err );    if(err)return(E_pos); // EXIT ON ERROR
	L_w += fWRITE( F, &((*UNI)->dType), short,   1, &N_w, &err );    if(err)return(E_pos); // EXIT ON ERROR	
	L_w += fWRITE( F, &((*UNI)->pType), short,   1, &N_w, &err );    if(err)return(E_pos); // EXIT ON ERROR
	
	// bookmark actual file position for later return to update  d_SeekPos , p_SeekPos 
	bookmark_dp_SeekPos = ftell(F);  
	
	// OCCUPY SPACE IN FILE FOR  d_SeekPos
	switch( (*UNI)->dType ) {
		// UniStruct - DATA TYPES with recursive data sub-structure
		//   -->  for each sub-element to be written a SeekPos-value is required !
		case e_T_MATRIX_DATA:  
		case e_T_OBJECT_DATA:     
		case e_T_DATASET_DATA:
		case e_T_VECTOR_DATA:
		case e_T_ITEM_DATA:
		case e_T_SERIES_DATA:
		
		    N_SeekPos  =  NL;
		    
		break;	
		
		// ELEMENTARY DATA TYPES
		//   --> just one single SeekPos is needed to protocollate the begin of the data
		case e_T_CHAR:     	case e_T_UCHAR:
		case e_T_SHORT:     case e_T_USHORT: 
		case e_T_INT:       case e_T_UINT:   
		case e_T_LONG:      case e_T_ULONG:  	
		case e_T_FLOAT:  
		case e_T_DOUBLE: 
		case e_T_LONG_DOUBLE:

		    N_SeekPos  =  1;
		
		break;
	} // switch( (*UNI)->dType ) {	

	// occupy space for  d_SeekPos[0..(N_SeekPos-1)]	
	for(i=0; i<N_SeekPos; i++) { // --> write  (1x or NLx) * dummy_SeekPos
		L_w += fWRITE( F, &dummy_SeekPos, long, 1, &N_w, &err );    if(err)return(E_pos); // EXIT ON ERROR	
	}
	// allocate memory for  d_SeekPos
	if( !(d_SeekPos = Xmalloc( long, N_SeekPos )) )return(E_pos); // EXIT ON ERROR
	for(i=0; i<N_SeekPos; i++) d_SeekPos[i] = -1;

  //=====================================================================
  //   W R I T E   P R O P E R T I E S  
  //=====================================================================
	if( (*UNI)->pType != e_T_NO_PROP ) { //..if there are any properties.. 	  
		
		// occupy space for  p_SeekPos[0..(N_SeekPos-1)]	
		for(i=0; i<N_SeekPos; i++) { // --> write  (1x or NLx) * dummy_SeekPos
			L_w += fWRITE( F, &dummy_SeekPos, long, 1, &N_w, &err );    if(err)return(E_pos); // EXIT ON ERROR	
		}
		// allocate memory for  p_SeekPos
		if( !(p_SeekPos = Xmalloc( long, N_SeekPos )) )return(E_pos); // EXIT ON ERROR
		for(i=0; i<N_SeekPos; i++) p_SeekPos[i] = -1;
		
		switch( (*UNI)->dType ) {	 // dType ! DATA-Type ! this is no mistake ! 
			// RECURSIVE UNISTRUCT DATA TYPES
			case e_T_MATRIX_DATA:    
			case e_T_OBJECT_DATA:    
			case e_T_DATASET_DATA:
			case e_T_VECTOR_DATA: 
			case e_T_ITEM_DATA:     // For each UniStruct - element an own
			case e_T_SERIES_DATA:   // set of properties will be written.
			   
				k = 0;  
				for( i = L0;  i < L0+NL;  i++ ) {  //  NL = N_SeekPos  runs			
					
					fflush( F ); // flush write buffer
					
					// bookmark file position:  BEGIN of   P R O P E R T I E S   of ELEMENT[i]
					p_SeekPos[k] = ftell(F);    k++;
					
					switch((*UNI)->pType) {
						      // NOTE:  GroupProp->Shared   results in a RECURSIVE STRUCTURE !!          
							  case e_T_MATRIX_PROP:   L_w += WriteGroupProp( F, &((*UNI)->p->Mat[i]), &err );
						break;case e_T_OBJECT_PROP:   L_w += WriteGroupProp( F, &((*UNI)->p->Obj[i]), &err ); 
						break;case e_T_DATASET_PROP:  L_w += WriteGroupProp( F, &((*UNI)->p->DSet[i]), &err );
						
						break;case e_T_VECTOR_PROP:  //WriteEntityProp( F, )
						break;case e_T_ITEM_PROP:
						break;case e_T_SERIES_PROP: {}
		
						break;case e_T_BASE_PROP:  L_w += WriteBaseProp( F, &((*UNI)->p->Xp[i]), &err );
						
					} // switch((*UNI)->pType)	
				
					if(err)return(E_pos); // EXIT ON ERROR		
				
				} // for(i=L0;i<L0+NL;i++)
			break;
			
			// ELEMENTARY DATA TYPES
			case   e_T_CHAR:		case e_T_UCHAR: 
			case   e_T_SHORT:       case e_T_USHORT:  
			case   e_T_INT:   		case e_T_UINT:    
			case   e_T_LONG:  		case e_T_ULONG:   			
			case e_T_FLOAT:   
			case e_T_DOUBLE:        // For the elementary data types only			
			case e_T_LONG_DOUBLE:   //  1  set of properties will written.
			
					fflush( F ); // flush write buffer					
					// bookmark file position:  BEGIN of   P R O P E R T I E S   of ELEMENT[i]
					p_SeekPos[k] = ftell(F);    k++;
					
					switch((*UNI)->pType) {						
						case e_T_BASE_PROP:  						
							L_w += WriteBaseProp( F, &((*UNI)->p->Xp[i]), &err );						   
						break;
					}
			break;				
		} // switch( (*UNI)->dType ) )
		
	} // if( (*UNI)->pType != e_T_NO_PROP ) 	


  //=====================================================================
  //   W R I T E   D A T A   
  //=====================================================================
    switch( (*UNI)->dType ) {
	  // WRITE ELEMENTARY DATA-TYPES:  1 - DIMENSIONAL ARRAYS OF GENERIC C-TYPES
	  //   write  NL  elements starting at index  L0  
	      case   e_T_CHAR:  L_w += fWRITE( F, &(*UNI)->d->Xc[L0], char, NL, &N_w, &err );    if(err)return(E_pos); // EXIT ON ERROR			  
	break;case e_T_UCHAR:   L_w += fWRITE( F, &(*UNI)->d->Xuc[L0], u_char_t, NL, &N_w, &err );    if(err)return(E_pos); // EXIT ON ERROR			    
	break;case   e_T_SHORT: L_w += fWRITE( F, &(*UNI)->d->Xs[L0], short, NL, &N_w, &err );    if(err)return(E_pos); // EXIT ON ERROR			    
	break;case e_T_USHORT:  L_w += fWRITE( F, &(*UNI)->d->Xus[L0], u_short_t, NL, &N_w, &err );    if(err)return(E_pos); // EXIT ON ERROR			     
	break;case   e_T_INT:   L_w += fWRITE( F, &(*UNI)->d->Xi[L0], int, NL, &N_w, &err );    if(err)return(E_pos); // EXIT ON ERROR			     
	break;case e_T_UINT:    L_w += fWRITE( F, &(*UNI)->d->Xui[L0], u_int_t, NL, &N_w, &err );    if(err)return(E_pos); // EXIT ON ERROR			     
	break;case   e_T_LONG:  L_w += fWRITE( F, &(*UNI)->d->Xl[L0], long, NL, &N_w, &err );    if(err)return(E_pos); // EXIT ON ERROR			     
	break;case e_T_ULONG:   L_w += fWRITE( F, &(*UNI)->d->Xul[L0], u_long_t, NL, &N_w, &err );    if(err)return(E_pos); // EXIT ON ERROR			     
	
	break;case e_T_FLOAT:       L_w += fWRITE( F, &(*UNI)->d->Xf[L0], float, NL, &N_w, &err );    if(err)return(E_pos); // EXIT ON ERROR			     
	break;case e_T_DOUBLE:      L_w += fWRITE( F, &(*UNI)->d->Xd[L0], double, NL, &N_w, &err );    if(err)return(E_pos); // EXIT ON ERROR			     
	break;case e_T_LONG_DOUBLE: L_w += fWRITE( F, &(*UNI)->d->Xld[L0], long double, NL, &N_w, &err );    if(err)return(E_pos); // EXIT ON ERROR			      

	// WRITE RECURSIVE UNISTRUCT DATA TYPES
	case e_T_MATRIX_DATA:    
	case e_T_OBJECT_DATA:    
	case e_T_DATASET_DATA:
	case e_T_VECTOR_DATA: 
	case e_T_ITEM_DATA:     
	case e_T_SERIES_DATA:   // WRITE  R E C U R S I V E  STRUCTURES
	    	    
		for( i = L0;  i < L0+NL;  i++ ) {	
			
			fflush( F ); // flush write buffer			
				
	 		// bookmark file position:  BEGIN of   D A T A   of ELEMENT[i]
			d_SeekPos[k] = ftell(F);    k++;
			
			switch((*UNI)->dType) {
				// TYPE OF MAIN STRUCTURE  UniStruct  =>  R E C U R S I V E   SUB-STRUCTURING      
				//   write the complete content of element[i] continuing
				//   at actual fpos (=-1)  starting with sub-element index (:0)
				//   traversing through all sub-elments (:LONG_MAX).
					  case e_T_MATRIX_DATA:  BlockWriteUniStruct( F, -1, &((*UNI)->d->Mat[i]), 0, LONG_MAX, &NW_sub, &err );
				break;case e_T_OBJECT_DATA:  BlockWriteUniStruct( F, -1, &((*UNI)->d->Obj[i]), 0, LONG_MAX, &NW_sub, &err );			                             			 
				break;case e_T_DATASET_DATA: BlockWriteUniStruct( F, -1, &((*UNI)->d->DSet[i]), 0, LONG_MAX, &NW_sub, &err );			                              
				
				break;case e_T_VECTOR_DATA:  BlockWriteUniStruct( F, -1, &((*UNI)->d->Vec[i]), 0, LONG_MAX, &NW_sub, &err );			                             
				break;case e_T_ITEM_DATA:    BlockWriteUniStruct( F, -1, &((*UNI)->d->Item[i]), 0, LONG_MAX, &NW_sub, &err );			                             
				break;case e_T_SERIES_DATA:  BlockWriteUniStruct( F, -1, &((*UNI)->d->Ser[i]), 0, LONG_MAX, &NW_sub, &err );			                             				
			} // switch((*UNI)->dType)	
			
			if(err)return(E_pos); // EXIT ON ERROR		
					
		} // for(i=L0;i<L0+NL;i++)
	break;
				
    } // switch((*UNI)->dType)
    

	// TESTING :  write some DUMMY DATA at end of file
	//		i = 1000;
	//		for( k=1; k<100; k++) {
	//			i++;  L_w += fWRITE( F, &i, u_long_t, 1, &N_w, &err );    if(err)return(E_pos); // EXIT ON ERROR
	//		}
	//		fflush( F );		
	//	
	// TESTING :  assign some value to  d_SeekPos + p_SeekPos  and..
	//		for(i=0; i<NL; i++) d_SeekPos[i] = 100+i+1;
	//	    if( (*UNI)->pType != e_T_NO_PROP ) {
	//			for(i=0; i<NL; i++) p_SeekPos[i] = 200+i+1;
	//		}	
	
    
    // FLUSH WRITE BUFFER !  B E F O R E   R E A D I N G  ! 
    fflush( F ); // flush last written data from buffer to file
    
	Fpos_actual = ftell(F); // remember last file position
	
    // NOW RETURN TO BOOKMARK AND UPDATE  d_SeekPos + p_SeekPos..
    if( !fseek( F, bookmark_dp_SeekPos, SEEK_SET ) )return(E_pos);
    
    //..OVERWRITE PLACE HOLDERS WITH ACTUAL VALUES   d_SeekPos
	for(i=0; i<N_SeekPos; i++) { // --> write  d_SeekPos[0..(N_SeekPos-1)]
		L_w += fWRITE( F, &d_SeekPos[i], long, 1, &N_w, &err );    if(err)return(E_pos); // EXIT ON ERROR	
	}
	if( (*UNI)->pType != e_T_NO_PROP ) {		
		    //..OVERWRITE PLACE HOLDERS WITH ACTUAL VALUES   p_SeekPos
		for(i=0; i<N_SeekPos; i++) { // --> write  p_SeekPos[0..(N_SeekPos-1)]
			L_w += fWRITE( F, &p_SeekPos[i], long, 1, &N_w, &err );    if(err)return(E_pos); // EXIT ON ERROR	
		}	
	}
	
    if( !fseek( F, Fpos_actual, SEEK_SET ) )return(E_pos); // go back to previous file position

    // finally clean up : free memory of temporary vars
	if( d_SeekPos != NULL ){ free(d_SeekPos);  d_SeekPos = NULL; }
	if( p_SeekPos != NULL ){ free(p_SeekPos);  p_SeekPos = NULL; }
	
	Fpos = ftell(F);
	
	*E = 0; // indicate SUCCESS
			
	return(Fpos);                 
} // BlockWriteUniStruct	
