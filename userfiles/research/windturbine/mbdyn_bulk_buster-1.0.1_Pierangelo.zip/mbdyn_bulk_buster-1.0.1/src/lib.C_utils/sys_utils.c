/*                      Copyright  (C)  2006    Patrick Rix 
 * sys_utils.c
 * ===========
 * Contains utilities for file system query and
 * manipulation like 
 *  - creating/removing/changing directories,
 *  - listing the content of a directy,
 *  - copying/moving of files/directories
 *  - querying the existance of a file/directory
 *  - getting file attributes like size modification date, etc.
 *   
 * 
 * LICENSE
 *                not yet defined
 * 
 * AUTHOR(S)
 *                Patrick Rix          e-mail: <patrick.rix@online.de>
 *
 * Modification History
 * ====================
 * Version      Date         Editor      Changes/Modifications/Improvements
 * -------------------------------------------------------------------------
 *   
 *  VERSION_SYS_UTILS  -->  remember to update version number in header file
 * 
 *  0.0.0    20.July 2006    Rix         Basic Version, 1st beta release.
 * 
 */
 
#include "sys_utils.h"

#include "str_utils.h"
#include "strlist.h"

//#include <windows.h>
//#define  SYS_UTILS_USE_WIN32_API // -->  define when WIN32-API functions
//                                       should be used in function   sys_dir()
//                                       requires  <windows.h> 
//                                       see below at NOT-UNIX-DEFINES

#include <ctype.h>    // for toupper
#include <limits.h>
#include <stdlib.h>   // for memory allocation
#include <string.h>   // for strcmp()
#include <time.h>     // for date/time routines
#include <utime.h>    // for !file!-date/time routines used in fcopy --> utime() , struct utimbuf 

// SET ONLY TO  1  FOR WINDOWS (required for distinguishing between regular file and link)
//#define   SYS_UTILS_TARGET_OS_WINDOWS    1
#define     SYS_UTILS_TARGET_OS_LINUX      1 

// local PRE-PROC CONSTANTS private to sys_utils.c
//       COMMANDS for function  sys_dir()
#define   cmd_LIST_DIR    1
#define   cmd_SIZE_DIR    2
#define   cmd_SZLS_DIR    3   // size + list
#define   cmd_SEARCH_DIR  4
#define   cmd_COPY_DIR    5
#define   cmd_MOVE_DIR    6
#define   cmd_REMOVE_DIR  7


#ifdef  __unix__    // ||  __CYGWIN__   /* UNIX & LINUX & CygWin */
  /////////////////////////////////////////////////////////////////////////////// 
  //////////      U N I X    +    L I N U X    +    C y g W i n        //////////   
  ///////////////////////////////////////////////////////////////////////////////

#  include <sys/stat.h>    // for mkdir()
#  include <sys/types.h>
#  include <sys/unistd.h>  // for getcwd(), rmdir(), chdir()
#  include <sys/dirent.h>  // for access(), opendir(),readdir(),resetdir(),closedir(),telldir(),seekdir()
  //default access rights for directory creation
#  define DFLT_MODE 0711  // !octal! value  0711 = rwx--x--x

#  define EXIST      F_OK      
#  define EXEC       X_OK
#  define READ       R_OK
#  define WRITE      W_OK
#  define READWRITE  W_OK|R_OK

//..think this is BULLSHIT..
	//	// set OS-specific string constants (see: str_utils.h)
	//	// e.g. PathDelim, DriveDelim, PathSep, LF, etc.
	//	#  ifdef STR_UTILS_OS_LINUX  
	//	#    undef  STR_UTILS_OS_LINUX
	//	#    define STR_UTILS_OS_LINUX    1
	//	#  endif
	//	#  ifdef STR_UTILS_OS_WINDOWS 
	//	#    undef  STR_UTILS_OS_WINDOWS
	//	#    define STR_UTILS_OS_WINDOWS  0
	//	#  endif

#else // = NOT UNIX or LINUX or CygWin --> means a  W I N D O W S - Derivatives
  ///////////////////////////////////////////////////////////////////////////////
  //////////                   W  I  N  D  O  W  S                     //////////   
  ///////////////////////////////////////////////////////////////////////////////

#  include <sys\stat.h>

//#  do not define MODE for Windows 

#  define EXIST      00  // octal values 
#  define EXEC       01
#  define READ       02
#  define WRITE      04
#  define READWRITE  06

//..more BULLSHIT..
	//	// set OS-specific string constants (see: str_utils.h)
	//	// e.g. PathDelim, DriveDelim, PathSep, LF, etc.
	//	#  ifdef STR_UTILS_OS_LINUX  
	//	#    undef  STR_UTILS_OS_LINUX
	//	#    define STR_UTILS_OS_LINUX    1
	//	#  endif
	//	#  ifdef STR_UTILS_OS_WINDOWS 
	//	#    undef  STR_UTILS_OS_WINDOWS
	//	#    define STR_UTILS_OS_WINDOWS  0
	//	#  endif


#  ifdef __WIN32__  ||  _MS_DOS_  ||  _MSC_VER 

#    include <dir.h>     // for getcwd(), mkdir(), rmdir(), chdir()
#    ifdef _MSC_VER
#      include <windows.h>  // for Win32-API - Functions: FindFirstFile(), FindNextFile(), FindClose()
#      define  SYS_UTILS_USE_WIN32_API // -->  define when WIN32-API functions
                                       //      should be used in function   sys_dir()
#    endif

#  else // Microsoft Visual C++

#    include <direct.h>  // for getcwd(), mkdir(), rmdir(), chdir()

#  endif

#endif // #ifdef __unix__  ...  #else  ...  


// static const char* module  = MODULE_SYS_UTILS;
// static const char* version = VERSION_SYS_UTILS;


////////////////////////////////////////////////////////////
// <<<  GLOBAL CONSTANTS  exported by  sys_utils.c  >>>  
////////////////////////////////////////////////////////////

  const int Nmax_attr = 10; // must correspond with length of  attr_t  !! --> see  sys_utils.h
  
////////////////////////////////////////////////////////////
// <<<  LOCAL CONSTANTS private to  sys_utils.c  >>>  
////////////////////////////////////////////////////////////

  const char*  Prefix_CygPath = "/cygdrive/";
  	
  const char*  DfltFmt_DateTime = "%d.%m.%Y %H:%M:%S";
  const char*  DfltFmt_Date     = "%d.%m.%Y";
  const char*  DfltFmt_Time     =          "%H:%M:%S";

////////////////////////////////////////////////////////////
// <<<  LOCAL FUNCTIONS private to  sys_utils.c  >>>  
////////////////////////////////////////////////////////////

static int
sys_DirCmd ( int command,  const char* dirname,  int recursive , /* Command + Target directory on which the command will be applied + Recursion-Switch */  
                           long long *size,                      /* Result of SIZE+SZLIST command */
                           TpointerStringList  *StringList,      /* Result of LIST+SZLIST */                       
                           const char* pattern,  int casens,     /* Input/ctrl-par. for SEARCH command */
                           TpointerStringList *FoundPatternList, /* Result of SEARCH command */
                           const char* destination  /* destination path for COPY_DIR + MOVE_DIR */             
                           ); 
////////////////////////////////////////////////////////////
// <<<  GLOBAL FUNCTIONS  exported by  sys_utils.c  >>>  
////////////////////////////////////////////////////////////

void *
x_malloc (size_t mem_size)
{
  void *new = malloc (mem_size);
  //if (!new) error ("Memory exhausted");
  return new;
}

void *
x_realloc (void *p, size_t mem_size)
{
  void *new;
  if(!p) return x_malloc (mem_size);
  new = realloc (p, mem_size);  
  //if (!new) error ("Memory exhausted");
  return new;
}

void *
x_calloc (size_t num, size_t size)
{
  void *new = x_malloc (num * size);
  bzero (new, num * size);
  return new;
}

  
u_long_t
x_fread( FILE* F,  void* var,  size_t size,  size_t num,  size_t *NR,  int *E ) {
	
	*NR = fread( var, size, num, F );    
	if(*NR == num) {*E = 0;}else{ if( feof(F) ){*E = 1;/*indicate END OF FILE*/}else{*E = -1;} }	 
	return( (u_long_t)((*NR) * size) ); // return number of BYTES read from file
}
   
u_long_t 
x_fwrite( FILE* F,  const void* var,  size_t size,  size_t num,  size_t *NW,  int *E ) {
	
	*NW = fwrite( var, size, num, F );    if(*NW == num) *E=0; else *E=-1;
	return( (u_long_t)((*NW) * size) ); // return number of BYTES written to file
}   


void wait ( int seconds )
{
  clock_t endwait;
  endwait = clock () + seconds * CLOCKS_PER_SEC ;
  while (clock() < endwait) {}
} // wait


struct tm*
sys_mktm( int year, int month, int day, int hour, int min, int sec ) {
	//  INPUT		year 	= 1999, 2001, etc.
	//				month	= 1..12
	//				day		= 1..31
	//				hour	= 0..23
	//				min		= 0..59
	//				sec		= 0..59
	//
	// members of structure  tm  :
	//	 	int tm_sec      /* seconds after minute [0-61] (61 allows for 2 leap-seconds)*/
	//	 	int tm_min      /* minutes after hour [0-59] */
	// 		int tm_hour     /* hours after midnight [0-23] */
	// 		int tm_mday     /* day of the month [1-31] */
	// 	!!	int tm_mon      /* month of year [0-11] */  
	// 	!!	int tm_year     /* current year-1900 */
	// 		int tm_wday     /* days since Sunday [0-6] */
	// 		int tm_yday     /* days since January 1st [0-365] */
	// 		int tm_isdst    /* daylight savings indicator */
	
    struct tm* timeptr = NULL; 
	
	if( (month < 1) || (12 < month) ) goto EXIT;
	if( (  day < 1) || (31 < day)   ) goto EXIT;
	if( ( hour < 0) || (23 < hour)  ) goto EXIT;
	if( (  min < 0) || (59 < min)   ) goto EXIT;
	if( (  sec < 0) || (59 < sec)   ) goto EXIT;
	
	timeptr = (struct tm*) malloc( sizeof(struct tm) );
	if( timeptr != NULL ) {
		timeptr->tm_year = year - 1900;
		timeptr->tm_mon  = month - 1;
		timeptr->tm_mday = day;
		timeptr->tm_hour = hour;
		timeptr->tm_min  = min;
		timeptr->tm_sec  = sec;

		timeptr->tm_wday  = 0;
		timeptr->tm_yday  = 0;
		timeptr->tm_isdst = 0;				
	}
	EXIT:
	return( timeptr );
} // sys_mktm	


struct tm*
sys_difftm( const struct tm* timeptr_1 , const struct tm* timeptr_2 ) {
	//
	// INPUT : two time stamps with   timeptr_2  >  timepetr_1
	//         i.e. the 2nd time stamp was taken some time later
	//              after the 1st time stamp.
	int year1, month1, day1, hour1, min1, sec1;
	int year2, month2, day2, hour2, min2, sec2;

    struct tm* difftimeptr = NULL;
    
    if( timeptr_1 == NULL ){ goto EXIT; }
    if( timeptr_2 == NULL ){ goto EXIT; }

    year1  = timeptr_1->tm_year;        year2  = timeptr_2->tm_year;
    month1 = timeptr_1->tm_mon;         month2 = timeptr_2->tm_mon;
    day1   = timeptr_1->tm_mday;        day2   = timeptr_2->tm_mday;
    hour1  = timeptr_1->tm_hour;        hour2  = timeptr_2->tm_hour;
    min1   = timeptr_1->tm_min;         min2   = timeptr_2->tm_min;
    sec1   = timeptr_1->tm_sec;         sec2   = timeptr_2->tm_sec;
        
	difftimeptr = (struct tm*) malloc( sizeof(struct tm) );
    
	if( difftimeptr != NULL ) {
		difftimeptr->tm_year = timeptr_2->tm_year - timeptr_1->tm_year;
		difftimeptr->tm_mon  = timeptr_2->tm_mon  - timeptr_1->tm_mon;
		difftimeptr->tm_mday = timeptr_2->tm_mday - timeptr_1->tm_mday;
		difftimeptr->tm_hour = timeptr_2->tm_hour - timeptr_1->tm_hour;
		difftimeptr->tm_min  = timeptr_2->tm_min  - timeptr_1->tm_min;
		difftimeptr->tm_sec  = timeptr_2->tm_sec  - timeptr_1->tm_sec;

		difftimeptr->tm_wday  = 0;
		difftimeptr->tm_yday  = 0;
		difftimeptr->tm_isdst = 0;				

		if( difftimeptr->tm_sec < 0 ){
			difftimeptr->tm_sec = difftimeptr->tm_sec + 60;
			difftimeptr->tm_min--;
		}
		if( difftimeptr->tm_min < 0 ){
			difftimeptr->tm_min = difftimeptr->tm_min + 60;
			difftimeptr->tm_hour--;
		}
		if( difftimeptr->tm_hour < 0 ){
			difftimeptr->tm_hour = difftimeptr->tm_hour + 24;
			difftimeptr->tm_mday--;
		}
		if( difftimeptr->tm_mday < 0 ){
			difftimeptr->tm_mday = difftimeptr->tm_mday + 31;
			difftimeptr->tm_mon--;
		}
		if( difftimeptr->tm_mon < 0 ){
			difftimeptr->tm_mon = difftimeptr->tm_mon + 12;
			difftimeptr->tm_year--;
		}

	}
	EXIT:
	return( difftimeptr );
} // sys_difftm


struct tm*
sys_Now( void ) {
	
    struct tm* timeptr = NULL; 
	time_t  timer;
	
	timeptr = (struct tm*) malloc( sizeof(struct tm) );
	if( timeptr != NULL ) {
		//timer = time( &timer );
		time( &timer );
		timeptr = localtime( &timer );
	}	
	return( timeptr );
} // sys_Now	


char*
sys_TimeToStr ( char* *s,  const struct tm* timeptr ) {
		
	sys_DateTimeToStrFmt( s, DfltFmt_Time, timeptr); 
	return(*s);
} // sys_TimeToStr


char*
sys_DateToStr ( char* *s,  const struct tm* timeptr ) {
		
	sys_DateTimeToStrFmt( s, DfltFmt_Date, timeptr); 
	return(*s);
} // sys_DateToStr


char*
sys_DateTimeToStr ( char* *s,  const struct tm* timeptr ) {
		
	sys_DateTimeToStrFmt( s, DfltFmt_DateTime, timeptr); 
	return(*s);
} // sys_DateTimeToStr


char*
sys_DateTimeToStrFmt ( char* *s,  const char* format,  const struct tm* timeptr ) {
	
	const size_t maxsize = 256;
	
	str_Nini( s, maxsize );
	strftime( *s, maxsize-1, format, timeptr); 
	str_memtrim( s );
	return(*s);
} // sys_DateTimeToStrFmt
	

int 
sys_fcopy ( const char* source,  const char* destination ) {
	// Copies  !1!  source file specified by its !full! path in source
	// to a destination file also specified by a !FULL! path.
	// No wildcards, no regular expressions, etc. !!!
	//
	// THE THING IN  destination  IS ASSUMED TO BE A FILENAME 
	//   --> NO DIRECTORY - CHECK !!!
	//
	// The original file date/time (of last modification) is kept.
	//
	const unsigned long BUFFER_SIZE = 1024*1024;
	
	int result = -1; // indicate FAILURE
	char buffer[BUFFER_SIZE];
	size_t Nread; 
	FILE* F1 = NULL; 
	FILE* F2 = NULL;
	struct stat  attribute; // for getting source file attributes by querying the file system with stat()
	struct utimbuf  source_time;
			
	if( stat( source, &attribute ) < 0 ) {
		return(result); // EXIT ON ERROR
	}else{
		// FILE SYSTEM QUERY SUCCESSFUL, now we should have the source file attributes
		source_time.actime  = attribute.st_atime;  // last access date/time
		source_time.modtime = attribute.st_mtime;  // last modify date/time
		F1 = fopen( source , "r" );
		F2 = fopen( destination , "w" );
		if( (F1 == NULL) || (F2 == NULL)) return(result); // EXIT ON ERROR
		while( (Nread = fread( buffer, 1, BUFFER_SIZE, F1 )) > 0 ) {
			fwrite( buffer, 1, Nread, F2 );
		}		
		fclose(F1);    fclose(F2);
		// now set date/time of dest.file to source file value
		if( utime( destination, &source_time ) < 0 ) return(result); // EXIT ON ERROR
		
		result = 0; // indicate SUCCESS
	}
	
	return(result)	;
} // sys_fcopy


int 
sys_fmove ( const char* source,  const char* destination ) {
	// Moves   !1!  source file specified by its !full! path in source
	// to a destination file also specified by a !FULL! path.
	// No wildcards, no regular expressions, etc. !!!
	//
	// THE THING IN  destination  IS ASSUMED TO BE A FILENAME 
	//   --> NO DIRECTORY - CHECK !!!
	// 	
	// The original file date/time (of last modification) is kept.
	//
	int result;
	result = sys_fcopy ( source, destination );
	if( result == 0 ) { // if source file was successfully copied..
		result = remove ( source ); // ..delete source file
	}	
	return(result);
} // sys_fmove	


int 
sys_CopyFile ( const char* source,  const char* destination ) {
	// Copies  !1!  source file specified by its !full! path in source
	// to a destination also specified by a !FULL! path.
	// No wildcards, no regular expressions, etc. !!!
	//
	// The thing in  destination  MAY BE A DIRECTORY.
	// In this case the name of the soure file is appended to destination
	// 	
	// The original file date/time (of last modification) is kept.
	//
	int result = -1; // indicate FAILURE
	int E;
	char* FileName = NULL;
	char* Delimiter = NULL;
	char* DestinationFNme = NULL;
	
	//..is destination a directory ?
	if( sys_DirExists( destination ) ) {
		sys_QueryPathDelimiter( &Delimiter );
		str_GetFileNameStr ( &FileName, source, &E );    if(E)return(result); // EXIT ON ERROR
		str_catenate4 ( &DestinationFNme, 
		                destination, Delimiter, FileName, &E);    if(E)return(result); // EXIT ON ERROR
	    free(FileName);    free(Delimiter);  
	    
	    result = sys_fcopy( source, DestinationFNme );
	    
	    free(DestinationFNme );
	}else{
		result = sys_fcopy( source, destination );
	}		
	return(result);
} // sys_CopyFile


int 
sys_MoveFile ( const char* source,  const char* destination ) {
	// Copies  !1!  source file specified by its !full! path in source
	// to a destination also specified by a !FULL! path.
	// No wildcards, no regular expressions, etc. !!!
	//
	// The thing in  destination  MAY BE A DIRECTORY.
	// In this case the name of the soure file is appended to destination
	// 		
	// The original file date/time (of last modification) is kept.
	//
	int result;
	result = sys_CopyFile ( source, destination );
	if( result == 0 ) { // if source file was successfully copied..
		result = remove ( source ); // ..delete source file
	}	
	return(result);
} // sys_MoveFile


int
sys_mkdir ( const char* path ) {
	
	int result = -1;
	
#ifdef __unix__  // when working under Cygwin on Windows the __unix__ flag is defined
		result = mkdir( path , DFLT_MODE );  // mkdir from <sys/stat.h>		
#else // WINDOWS
		result = mkdir( path );	  // mkdir from <dir.h> or <mingw/dir.h>
#endif
	return(result);
} // sys_mkdir 


int
sys_mkdir_forced ( const char* path ) {
	
	int result = -1; // raise ERROR flag
	int  E, REPEAT;
	long L, p,p0,p1,p2,
	             q1,q2,q3;
	char* S = NULL;
	char* SS = NULL;
	
	L = str_len( path );
	
	if( L > 0 ) {
		
		str_ini( &S );    str_ini( &SS );
		
		str_copy( &S , path, &E );    if( E ) goto EXIT;
		str_trimStr( &S , &E );       if( E ) goto EXIT; 
		
		if( !sys_DirExists( S ) ) { // create dir(s) UNLESS path already exists
						          
			if( sys_IsRelativePath( S ) ) {
			    	sys_GetAbsolutePath( &SS, S );
			}else{
				str_copy( &SS, S, &E );    if( E ) goto EXIT;
			}	
			    	
#ifdef __unix__		
            //when developing under Cygwin on Windows the __unix__ flag is defined	
			sys_WinPathToCygPath( &SS ); // has only an effect if SS contains some Windows-style-path 				
#else			
			sys_CygPathToWinPath( &SS );				
#endif			
			
// some more pattern searching			
// pattern:  / , // , \  , \\ , :\ ,
		  	p1 = p2 = q1 = q2 = q3 = -1;
			               p2 = str_pos( SS , "//"  , 0, 0 ); // search for   //  in path string 
			if( p2<0 ) {   q2 = str_pos( SS , "\\\\", 0, 0 ); // search for   \\  in path string 
		   	  if( q1<0 ) { q3 = str_pos( SS , ":\\" , 0, 0 ); // search for   :\  in path string 
		  	  }
			}
			// set start index p0 for searching the next delimiter
			p0 = 0;
    			 if( p2 == 0 ) p0 = 1; // correct if  // UNC-path			
			else if( q2 == 0 ) p0 = 1; // correct if  \\ UNC-path			
			else if( q3 == 1 ) p0 = 2; // correct if C:\ Windows-path			
			L = str_len( SS );
			
			E = 0; REPEAT = 1;  
			while( REPEAT && !E ) {
				
	                    p = str_posnext( p0+1, SS , "/"   , 0, 0 );  // search ist   /  in path string 
			    if(p<0) p = str_posnext( p0+1, SS , "\\"  , 0, 0 );  // search for   \  in path string 
							
				if( (p > p0) && (p < L) ) {
					str_Ncopy( &S , SS , 0, p, &E );    if( E ) goto EXIT;
				}else{
					str_copy( &S, SS , &E );    if( E ) goto EXIT;
					REPEAT = 0;
				}
				
				if( !sys_DirExists( S ) ) {
					// CREATE DIR
					E = sys_mkdir( S );    if( E ) goto EXIT;
				}	
				  
				p0 = p;
			}	
			
			result = 0; // indicate SUCCESS
		}	
		EXIT: 
		free( S );    S  = NULL;
		free( SS );   SS = NULL;
	}	
	
	return(result);
} // sys_mkdir_forced	


int
sys_rmdir_forced ( const char* path ) {
	
	const int recursive = 1;
	
	int result; 
	
	result = sys_RemoveDir( path, recursive );
	
	return(result);
} // sys_rmdir_forced
		

int
sys_lsdir ( TpointerStringList  *StringList,  const char* dirname,  int recursive ) {
		
	int result;
	long long dummy_size = (long long)0;
	int   dummy_int = 0;
	char* dummy_pchar = NULL;
	TpointerStringList  *dummy_pStrLst = NULL;
		
	result = sys_DirCmd( cmd_LIST_DIR, dirname, recursive, &dummy_size, StringList, 
	                                   dummy_pchar, dummy_int, dummy_pStrLst,
	                                   dummy_pchar );	
	return(result);
} // sys_lsdir                       	


int
sys_szlsdir ( long long *size,  TpointerStringList  *StringList,  const char* dirname,  int recursive ) {
		
	int result;
	int   dummy_int = 0;
	char* dummy_pchar = NULL;
	TpointerStringList  *dummy_pStrLst = NULL;
		
	result = sys_DirCmd( cmd_SZLS_DIR, dirname, recursive, size, StringList, 
	                                   dummy_pchar, dummy_int, dummy_pStrLst,
	                                   dummy_pchar );	
	return(result);
} // sys_szlsdir                       	


int
sys_GetDirSize ( long long *size,  const char* dirname,  int recursive ) {
		
	int result, E;
	TpointerStringList  TmpStrLst = NULL;
	int   dummy_int = 0;
	char* dummy_pchar = NULL;
	TpointerStringList  *dummy_pStrLst = NULL;
	
	result = sys_DirCmd( cmd_SIZE_DIR, dirname, recursive, size, &TmpStrLst, 
	                                   dummy_pchar, dummy_int, dummy_pStrLst,
	                                   dummy_pchar );
	strlist_DestroyStrList( &TmpStrLst, &E );                                  
	return(result);
} // sys_GetDirSize                       	


int
sys_SearchDir ( const char* dirname,  int recursive,  
                const char* pattern,  int casens,  TpointerStringList *FoundPatternList ) {
		
	int result, E;
	TpointerStringList  TmpStrLst = NULL;
	long long dummy_size = (long long)0;
	char* dummy_pchar = NULL;
	
	result = sys_DirCmd( cmd_SEARCH_DIR, dirname, recursive, &dummy_size, &TmpStrLst, 
	                                     pattern, casens, FoundPatternList,
	                                     dummy_pchar );
	strlist_DestroyStrList( &TmpStrLst, &E );                                  
	return(result);
} // sys_SearchDir                       	


int
sys_CopyDir ( const char* dirname,  int recursive,  const char* destination ) {
		
	int result, E;
	TpointerStringList  TmpStrLst = NULL;
	long long dummy_size = (long long)0;
	int   dummy_int = 0;
	char* dummy_pchar = NULL;
	TpointerStringList  *dummy_pStrLst = NULL;
	
	result = sys_DirCmd( cmd_COPY_DIR, dirname, recursive, &dummy_size, &TmpStrLst, 
	                                   dummy_pchar, dummy_int, dummy_pStrLst,
	                                   destination );
	strlist_DestroyStrList( &TmpStrLst, &E );                                  
	return(result);
} // sys_CopyDir                       	


int
sys_MoveDir ( const char* dirname,  int recursive,  const char* destination ) {
		
	int result, E;
	TpointerStringList  TmpStrLst = NULL;
	long long dummy_size = (long long)0;
	int   dummy_int = 0;
	char* dummy_pchar = NULL;
	TpointerStringList  *dummy_pStrLst = NULL;
	
	result = sys_DirCmd( cmd_MOVE_DIR, dirname, recursive, &dummy_size, &TmpStrLst, 
	                                   dummy_pchar, dummy_int, dummy_pStrLst,
	                                   destination );
	strlist_DestroyStrList( &TmpStrLst, &E );                                  
	return(result);
} // sys_MoveDir                       	


int
sys_RemoveDir ( const char* dirname,  int recursive ) {
		
	int result, E;
	TpointerStringList  TmpStrLst = NULL;
	long long dummy_size = (long long)0;
	int   dummy_int = 0;
	char* dummy_pchar = NULL;
	TpointerStringList  *dummy_pStrLst = NULL;
	
	result = sys_DirCmd( cmd_REMOVE_DIR, dirname, recursive, &dummy_size, &TmpStrLst, 
	                                     dummy_pchar, dummy_int, dummy_pStrLst,
	                                     dummy_pchar );
	strlist_DestroyStrList( &TmpStrLst, &E );                                  
	return(result);
} // sys_RemoveDir                       	


static int
sys_DirCmd ( int command,  const char* dirname,  int recursive , /* Command + Target directory on which the command will be applied + Recursion-Switch */  
                           long long *size,                      /* Result of SIZE+SZLIST command */
                           TpointerStringList  *StringList,      /* Result of LIST+SZLIST */                       
                           const char* pattern,  int casens,     /* Input/ctrl-par. for SEARCH command */
                           TpointerStringList *FoundPatternList, /* Result of SEARCH command */
                           const char* destination /* destination path for COPY_DIR + MOVE_DIR */             
                           ) {
                        	
	//  TODO:  -->  Enhancement of SEARCH-function to REGULAR EXPRESSIONS
	//
	// cmd_COPY_DIR + cmd_MOVE_DIR :
	// =============================
	// If the directory pointed to by  destination  exists, then a new directory will
	// be created having the original (last-level-)name of the source directory and the content will be
	// copied recursviley or not depending on the value given in  recursive  .
	// If the directory in  destination  does  NOT  exists, then a new directory will 
	// be created having the name of the last directory specified in  destination  .
	// This implies that the destination path must exists at least up to the last but one
	// directory level.
	// NOTE:  when  moving  NON-RECURSIVELY a directory which contains
  	//		  sub-directories the failure when trying to remove it 
  	//        should not be regarded as an error.
	
	
	const int DEBUG = 0; // switch debug output  0/1 = OFF/ON
	
	int result = -1; // raise ERROR flag;
	int result_recursive = -1; // raise ERROR flag;
	int  err, E;
	int  name_equals_pattern;
	long long  sz = (long long)0;  // holds actual file size
	long long  sub_size = (long long)0;
	long L, i,j,  Ncount, r1,r2;
	char* S  = NULL;	
	char* SS = NULL;	
	char* Delimiter = NULL;
	char* DirNme = NULL;
	char* SubDirNme = NULL;	
	char* Prefix = NULL;	
	char* DestDir = NULL;
	char* SubDestDir = NULL;
	TpointerStringList    StrList_SubDir = NULL;
	TpointerStringList    FoundPatternList_SubDir = NULL;
	TpointerStrListElem	  Elem_i = NULL, 
                          Elem_j = NULL;	
	// define handle for directory
#ifndef SYS_UTILS_USE_WIN32_API	
	DIR  *directory; // Linux/Unix 
	struct dirent  *dirp;
#else
	HANDLE  directory; // Windows 
	WIN32_FIND_DATA  dirp;
#endif
	
	
	E = -1;   
	L = str_len( dirname );
	if( L > 0 ) {
		
		sys_QueryPathDelimiter( &Delimiter );

		str_ini( &DirNme );    str_ini( &SubDirNme );    str_ini( &Prefix );
		str_ini( &DestDir );   str_ini( &SubDestDir );
		str_ini( &S );    	   str_ini( &SS );
		
		str_copy( &DirNme , dirname, &E );     if( E ) goto EXIT;
	    str_trimStr( &DirNme , &E );           if( E ) goto EXIT;
				          
		if( sys_IsRelativePath( DirNme ) ) {
			    str_copy( &S, DirNme, &E );    if( E ) goto EXIT;
			    sys_GetAbsolutePath( &DirNme, S );    str_ini( &S );
		}	
		
  // next: open directory dirname which is now contained in SS as an absolute path

  // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
  // BEGIN PROCESSING ACTUAL DIRECTORY LEVEL
  //    OPEN DIRECTORY
#ifndef SYS_UTILS_USE_WIN32_API	
						
        //    LINUX / UNIX / CygWin
		// ===========================
		if( DEBUG ) printf("\nCONTENT OF DIRECTORY :   %s\n", DirNme );

		directory = opendir( DirNme ); 
		if( directory != NULL ) 
#else
		//    WINDOWS
		// =============
		// transform to Windows-style path	(replace / with \ )	
		sys_CygPathToWinPath( &DirNme );  

		if( DEBUG ) printf("\nCONTENT OF DIRECTORY :   %s\n", DirNme );

		// copy dirname to add  *.* - pattern 
		str_copy( &S, DirNme, &E);    if( E ) goto EXIT;	  
		// add a  *.*  at the end !!! --> directory = FindFirstFile ( "C:\\somedir\\*.*", &dirp );				
		L = str_len( S );
		if( S[L-1] == '\\' ) {
		     str_catenate( &S , "*.*" , &E );    if( E ) goto EXIT;		
		} else {
			 str_catenate( &S , "\\*.*" , &E );    if( E ) goto EXIT;		   
		}
			 
		directory = FindFirstFile ( S, &dirp );		
		if( directory != INVALID_HANDLE_VALUE )
#endif			
		{ // BEGIN if ( directory != NULL or INVALID_HANDLE_VALUE )
  //    INITIAL STEPS (OPENING SUCCESSFUL)
		 
			strlist_CreateStrList ( StringList, &E );    if( E ) goto EXIT;			
			// use StrinList.FNme to save dirname  
			str_copy( &(*StringList)->FNme, DirNme, &E );    if( E ) goto EXIT;
			
			switch( command ) {   
				case cmd_LIST_DIR:
				  // no further initial steps for listing
				break;
				
				case cmd_SZLS_DIR:
				case cmd_SIZE_DIR:
				case cmd_SEARCH_DIR:
					*size = (long long)0;    
					if(command == cmd_SEARCH_DIR) {
						strlist_CreateStrList ( FoundPatternList, &E );    if( E ) goto EXIT;							
						str_copy( &(*FoundPatternList)->FNme, DirNme, &E );    if( E ) goto EXIT;
					}	
				break;
				
				case cmd_COPY_DIR:
				case cmd_MOVE_DIR:
				    // examine destination path and make it absolute if necessary
					str_copy( &DestDir , destination, &E );     if( E ) goto EXIT;
				    str_trimStr( &DestDir , &E );           if( E ) goto EXIT;
							          
					if( sys_IsRelativePath( DestDir ) ) {
						    str_copy( &S, DestDir, &E );    if( E ) goto EXIT;
						    sys_GetAbsolutePath( &DestDir, S );    str_ini( &S );
					}	
					// does destination exist ?
					if( sys_DirExists( DestDir ) ) {
						// if YES : --> get last-level-directory name of source directory DirNme ..
						str_GetFileNameStr( &S, DirNme, &E );    if( E ) goto EXIT;	
						// ..and append it to DestDir.
						str_catenate3( &DestDir, Delimiter, S, &E );    if( E ) goto EXIT;	
					}else{
						// if NO : --> does at least the last but one directory level exist ?
						str_GetFilePathStr( &S, DestDir, &E );    if( E ) goto EXIT;							
						if( !sys_DirExists( S ) ) {
							if( E ) goto EXIT;	//..if not --> EXIT ON ERROR
						}							
					}	
						
					// CREATE DESTINATION DIRECOTORY
		            E = sys_mkdir( DestDir );	 if( E ) goto EXIT;	
		            
				break;
				
				case cmd_REMOVE_DIR:
				  // no furhter initial steps for removing
				break;					
			} // switch (command)
			
  //    READ DIRECTORY CONTENT/ENTRIES
#ifndef SYS_UTILS_USE_WIN32_API			

        	//    LINUX / UNIX / CygWin
			// ===========================
        	
			dirp = readdir( directory );
			while( dirp != NULL ) {
				
				//printf("%s\n", dirp->d_name );	

				strlist_AppString ( StringList, dirp->d_name , &E);    if( E ) goto EXIT;
				
				// build the full name of current entry			    									    
			    str_ini( &S );    str_catenate4( &S, DirNme, Delimiter, dirp->d_name, &E );    if( E ) goto EXIT;
			    
				sz = (long long)0;			
				switch( command ) {   
					case cmd_LIST_DIR:
					break;
					
					case cmd_SZLS_DIR:
					case cmd_SIZE_DIR:
					case cmd_SEARCH_DIR:
						
						sz = sys_GetFileSize ( S ); // returns -1 on failure (e.g. for a directory)
						if( sz < (long long)0 ) sz = (long long)0; // correct if size sz is negative
						*size += sz;
						(*StringList)->StrLstEnd->sz = sz;	
												
		//  TODO:  -->  Enhancement of SEARCH-function to REGULAR EXPRESSIONS
						if(command == cmd_SEARCH_DIR) {							
						    name_equals_pattern = !str_cmp( pattern, dirp->d_name, casens );
						    if( name_equals_pattern ) {

								strlist_AppString ( FoundPatternList, dirp->d_name , &E);    if( E ) goto EXIT;

								(*FoundPatternList)->StrLstEnd->sz = sz;	
								if( sys_DirExists( S ) ) {
									// set char  d  to TRUE to indicate that the 
									// pattern found is a DIRECTORY
									(*FoundPatternList)->StrLstEnd->d = 1;
								}	
						    }	
						}    
					break;
					
					case cmd_COPY_DIR:
					case cmd_MOVE_DIR:
					case cmd_REMOVE_DIR:					

						if( sys_FileExists( S ) ) {
							// actual object is a FILE or LINK..
							if( (command == cmd_COPY_DIR) ||
							    (command == cmd_MOVE_DIR) ) {
							    // compose full destination path	
								str_ini(&SS);   str_catenate4( &SS, DestDir, Delimiter, dirp->d_name, &E );    if( E ) goto EXIT;
								// COPY FILE or LINK
								E = sys_fcopy( S , SS );    if( E ) goto EXIT;
							}
							if( ((command == cmd_MOVE_DIR) ||
							     (command == cmd_REMOVE_DIR)) && (!E) ) {
								// REMOVE SOURCE FILE 
								 E = remove( S );    if( E ) goto EXIT;
							}	
						}						
					break;
					
				} // switch (command)

				if( DEBUG ) {
					printf("%s   ", dirp->d_name);	
					if( sys_DirExists( S ) ) {
						printf("[DIR]\n");
					}else{
						printf("[%lld bytes]\n", sz);						
					}		
				}	

				dirp = readdir( directory );
			} // while( dirp != NULL )  
#else
			//    WINDOWS
			// =============			
			do {
					// str_Nini( &S , MAX_PATH );    for(i=0;i<=MAX_PATH;i++) S[i] = dirp.cFileName[i];
					// printf("%s\n", S /*dirp.cFileName*/ );				
					// strlist_AppString ( StringList, S /*dirp.cFileName*/ , &E);    if( E ) goto EXIT;
					
				//printf("%s\n", dirp.cFileName );				

				strlist_AppString ( StringList, dirp.cFileName , &E);    if( E ) goto EXIT;
				
				// build the full name of current entry			    
				str_ini( &S );    str_catenate4( &S, DirNme, Delimiter, dirp.cFileName, &E );    if( E ) goto EXIT;
			    
				sz = (long long)0;							
				switch( command ) {   
					case cmd_LIST_DIR:
					break;
					
					case cmd_SZLS_DIR:
					case cmd_SIZE_DIR:
					case cmd_SEARCH_DIR:	

						sys_CygPathToWinPath( &S );
						sz = sys_GetFileSize ( S ); // returns -1 on failure (e.g. for a directory)
						if( sz < (long long)0 ) sz = (long long)0; // correct if size sz is negative
						*size += sz;
						(*StringList)->StrLstEnd->sz = sz;							
												
		//  TODO:  -->  Enhancement of SEARCH-function to REGULAR EXPRESSIONS
						if(command == cmd_SEARCH_DIR) {
						    name_equals_pattern = !str_cmp( pattern, dirp.cFileName, casens );
						    if( name_equals_pattern ) {
						    	
								strlist_AppString ( FoundPatternList, dirp.cFileName , &E);    if( E ) goto EXIT;
								
								(*FoundPatternList)->StrLstEnd->sz = sz;	
								if( sys_DirExists( S ) ) { // if the full name in  S  is a directory..
									// set char  d  to TRUE to indicate that the 
									// pattern found is a DIRECTORY
									(*FoundPatternList)->StrLstEnd->d = 1;
								}	
						    }	
						}    
						
					break;

					case cmd_COPY_DIR:
					case cmd_MOVE_DIR:
					case cmd_REMOVE_DIR:					

						if( sys_FileExists( S ) ) {
							// actual object is a FILE or LINK..
							if( (command == cmd_COPY_DIR) ||
							    (command == cmd_MOVE_DIR) ) {
							    // compose full destination path	
								str_ini(&SS);   str_catenate4( &SS, DestDir, Delimiter, dirp.cFileName, &E );    if( E ) goto EXIT;
								// COPY FILE or LINK
								E = sys_fcopy( S , SS );    if( E ) goto EXIT;
							}
							if( ((command == cmd_MOVE_DIR) ||
							     (command == cmd_REMOVE_DIR)) && (!E) ) {
								// REMOVE SOURCE FILE 
								 E = remove( S );    if( E ) goto EXIT;
							}	
						}						
					break;
					
				} // switch (command)
				
				if( DEBUG ) {
					printf("%s   ", dirp.cFileName);	
					if( sys_DirExists( S ) ) {
						printf("[DIR]\n");
					}else{
						printf("[%lld bytes]\n", sz);						
					}		
				}	
				
			} while( FindNextFile( directory, &dirp ) );	
#endif			

		if( DEBUG ) printf("  TOTAL SUM OF FILES :   [%lld byte]\n", *size );


			EXIT:  // ERROR jump mark for goto
			
  //    CLOSE DIRECTORY 
#ifndef SYS_UTILS_USE_WIN32_API			
			err = closedir( directory );					
#else
			err = !( FindClose( directory ) );	// FindClose returns 1 on SUCCESS		
#endif		

			if( !E && !err ) result = 0; // indicate SUCCESS so far			
	
		} // END if ( directory != ... )
		
  // END PROCESSING ACTUAL DIRECTORY LEVEL
  // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 				

  // BEGIN RECURSIVE PART 
		if( (recursive) && (result == 0) ) { 
		// only entered if recursion was requested and
		// the above part was successfully finished (result = 0)	
			
			result_recursive = -1;  // raise ERROR flag
			
		// STEP THROUGH ACTUAL CONTENT OF THE ABOVE SCANNED DIRECTORY AND
		// SEARCH FOR SUB-DIRS	
			Ncount = (*StringList)->Count;
			i = 0;    Elem_i = (*StringList)->StrLstRoot;			
			while( (i <= Ncount-1) && (Elem_i != NULL) ) { 
				
				str_ini( &SubDirNme );
				// compose actual object name in  S  from elements read above the 
  			    // if  Elem_i.str  contains  .  or  ..  then  S  remains empty				
				r1 = strcmp(Elem_i->str , ".");    r2 = strcmp(Elem_i->str , "..");
				if( (r1 != 0) && (r2 != 0) ) {
					str_catenate4( &SubDirNme, DirNme, Delimiter, Elem_i->str, &E );    if( E ) goto EXIT_2;					
					
					if( (command == cmd_COPY_DIR) ||
					    (command == cmd_MOVE_DIR) ) {
					    str_ini( &SubDestDir );	
						str_catenate4( &SubDestDir, DestDir, Delimiter, Elem_i->str, &E );    if( E ) goto EXIT_2;										    
					}    	
				}
					
#ifndef SYS_UTILS_USE_WIN32_API							
				// do nothing 
#else
				sys_CygPathToWinPath( &SubDirNme );  // force Windows-style path (replace / with \ )	
#endif
				// Is the acutal thing in  SubDirNme(-->Elem_i)  a sub-directory ?
				if( sys_DirExists( SubDirNme ) ) { //..if so then we have..
								  	
				  //..RUCURSION HERE !!
					E = sys_DirCmd ( command,  SubDirNme,  recursive,  &sub_size,  &StrList_SubDir,
					                        pattern, casens, &FoundPatternList_SubDir, 
					                        SubDestDir );    if( E ) goto EXIT_2;

 				  // NOTE: SubDirNme refers to  Elem_i  which is important
 				  //       for updating the sub-dir size   Elem_i.sz  below.
 				  
				    Elem_i->d = 1; // set char  d  to TRUE to indicate that this is DIRECTORY
				    
				  // compose  Prefix  from  sub-directory name (Elem_i.str) and Delimiter                 					
					str_ini( &Prefix );    str_catenate3( &Prefix, Elem_i->str, Delimiter, &E );    if( E ) goto EXIT_2;					
				  // insert  PrefixPath  at beginning of each member of StrList_SubDir							
					if( StrList_SubDir != NULL ) 
						 Elem_j = StrList_SubDir->StrLstRoot; 
					else Elem_j = NULL;
					j = 0; 
					while( Elem_j != NULL ) { 
						// insert Prefix to all elements of StrList_SubDir
						str_insert( &(Elem_j->str), Prefix, 0, &E );     if( E ) goto EXIT_2;
						j++;    Elem_j = Elem_j->next;
					}	
															
					switch( command ) {   
						case cmd_LIST_DIR:						
						case cmd_SZLS_DIR:
						case cmd_SEARCH_DIR:					    
						   
							strlist_BlockAppendToStrList ( StringList,  &StrList_SubDir,  0, LONG_MAX,  &E );    if( E ) goto EXIT_2;
							
							if(command == cmd_SZLS_DIR) { 							    	
								if( sub_size > 0 ) {
									 *size = *size +  sub_size;
									 Elem_i->sz = sub_size;	// now the sub-dir size can be updated															 
								}else{
									 Elem_i->sz = (long long)0;																 
								}
							}	
																 
							if(command == cmd_SEARCH_DIR) {	
								
							  // insert  PrefixPath  at beginning of each member of FoundPatternList_SubDir							
								if( FoundPatternList_SubDir != NULL ) 
									 Elem_j = FoundPatternList_SubDir->StrLstRoot; 
								else Elem_j = NULL;
								j = 0; 
								while( Elem_j != NULL ) { 
									// insert Prefix to all elements of FoundPatternList_SubDir
									str_insert( &(Elem_j->str), Prefix, 0, &E );     if( E ) goto EXIT_2;
									j++;    Elem_j = Elem_j->next;
								}	
															
								strlist_BlockAppendToStrList ( FoundPatternList,  &FoundPatternList_SubDir,  0, LONG_MAX,  &E );    if( E ) goto EXIT_2;								
								
								strlist_DestroyStrList( &FoundPatternList_SubDir, &E );    if( E ) goto EXIT_2;
							}								 
						break;
						
						case cmd_SIZE_DIR:
							if( sub_size > (long long)0 ) *size = *size +  sub_size;
						break;
						
						case cmd_COPY_DIR:
						break;
						
						case cmd_MOVE_DIR:
						break;
						
						case cmd_REMOVE_DIR:
						break;					
					} // switch (command)
					
					strlist_DestroyStrList( &StrList_SubDir, &E );    if( E ) goto EXIT_2;
					
				}else{ //..NO it was NOT a directory --> FILE or LINK
					
				}		
								
				i++;    Elem_i = Elem_i->next;
			} // while(...) 
			
		  // POST-RECURSION CLEAN-UP
			switch( command ) {   
				case cmd_LIST_DIR:						
				case cmd_SZLS_DIR:				
				case cmd_SEARCH_DIR:
				case cmd_SIZE_DIR:
				case cmd_COPY_DIR:
				case cmd_MOVE_DIR:
				case cmd_REMOVE_DIR:				    
				  // DO NOT REMOVE  StringList  !!!
				  // especially not when having recursion  --> it's a result for the next step;
				  // NO !! NO !! NO !! strlist_DestroyStrList( StringList, &E ); // this removes StringList
				break;					
			} // switch (command)
						
			result_recursive = 0; // indicate RUCURSION SUCCESS 
			
			EXIT_2:	 // ERROR jump mark for goto						
			
			result = result_recursive; // indicate TOTAL SUCCESS
						
		} // if( (recursive) && ... )
		
  // END RECURSIVE PART
  
  		
  		if( ((command == cmd_MOVE_DIR) ||
  		     (command == cmd_REMOVE_DIR)) && (!E) ) {
  			// finally REMOVE SOURCE DIRECTORY (should be empty now; if not rmdir() will fail)
  			E = rmdir( DirNme );
  			
  			if( recursive ) { // when recursive was set and  E!=0  this is an ERROR: the directory must be empty but is not!
	  			if(E)result = -1; // indicate FAILURE
  			}else{
  				E = 0; // when moving NON-RECURSIVELY a directory which contains
  				       // sub-directories the failure when trying to remove it 
  				       // should not be regarded as an error.
  			}		
  		}	
  					
		free( Delimiter );    	Delimiter = NULL;
		free( S );    			S  = NULL;
		free( SS );    			SS = NULL;
		free( Prefix );         Prefix = NULL;			
		free( SubDirNme );      SubDirNme = NULL;			
		free( DirNme );   		DirNme = NULL;			
		free( DestDir );   		DestDir = NULL;			
		free( SubDestDir );   	SubDestDir = NULL;			
	}	
	
	return(result);
	
} // sys_dir


int
sys_RenameDir ( const char* dirname, const char* newname ) {
	int result;
	result = rename ( dirname, newname ); // --> rename() works also for directories
	return( result ); 
} // sys_RenameDir	
		

int 
sys_FileSetReadOnly ( const char* path ) {
	return( chmod( path, S_IREAD ) );  // from  <io.h> OR <sys/stat.h> OR <sys/unistd.h>
} //sys_FileSetReadOnly 

int 
sys_FileSetReadWrite ( const char* path ) {
	return( chmod( path, (S_IREAD | S_IWRITE) ) );  // from  <io.h> OR <sys/stat.h> OR <sys/unistd.h> 
} //sys_FileSetReadWrite 

int 
sys_FileSetWriteOnly ( const char* path ) {
	return( chmod( path, S_IWRITE ) );  // from  <io.h> OR <sys/stat.h> OR <sys/unistd.h>
} //sys_FileSetWriteOnly 

	
int
sys_FileExists ( const char* path ) {
	// Returns
	//   on WINDOWS:      TRUE for FILES and LINKS
	//   on UNIX/LINUX:   TRUE for FILES only
	int result, is_file = 0, is_dir = 0, is_link = 0;
	
	result = sys_ObjExists( path, &is_file, &is_dir, &is_link ); 
	
	if( (result > 0) ) {
		if( !is_file )  result = 0; // object exists but is NOT a file
	}	
	return(result);
} // sys_FileExists	


int
sys_DirExists ( const char* path ) {
	// Returns TRUE for DIRS only
	int result, is_file = 0, is_dir = 0, is_link = 0;
	
	result = sys_ObjExists( path, &is_file, &is_dir, &is_link ); 
	
	if( (result > 0) ) {
		if( !is_dir )  result = 0; // object exists but is NOT a directory
	}	
	return(result);
} // sys_DirExists	


int
sys_SymLnkExists ( const char* path ) {
	// Returns TRUE for LINKS only
	int result, is_file = 0, is_dir = 0, is_link = 0;
	
	result = sys_ObjExists( path, &is_file, &is_dir, &is_link ); 
	
	if( (result > 0) ) {
		if( !is_link )  result = 0; // object exists but is NOT a link
	}	
	return(result);
} // sys_DirExists	


int
sys_ObjExists ( const char* Path_fSysObj, int *is_file, int *is_dir, int *is_link ) {
	// Queries the file system for the object specified by its path
	// and indicates whether it is a file or directory or symbolic link.
	// 
	// Returns 1 if the object DOES     exist
	//         0 if the object does NOT exist 
	
	struct stat fSysQuery;
	
	int result;
	int  err;
	long L;
#ifdef	SYS_UTILS_TARGET_OS_WINDOWS		
	char* Extension = NULL;
	long long FileSize;  
#endif	
	// 	mode_t REG, DIR, LNK;
	//	
	//		REG = S_IFREG;
	//		DIR = S_IFDIR;
	//		LNK = S_IFLNK;
	
	  result = 0;  // set to FALSE assuming object is not existing 
	*is_file = 0;
	*is_dir  = 0;
	*is_link = 0;
	
	L = str_len( Path_fSysObj );
	if( L > 0 ) {
		
		err = stat( Path_fSysObj, &fSysQuery ); // query file system
		
		if( !err ) {
			// if the constants  S_IFREG , S_IFDIR  are defined in sys/stat.h 
			// then use
			// ..the 'CONSTANT-WAY'
			
			if( fSysQuery.st_mode & S_IFREG ) {  // ON WINDOWS A LINK IS HANDLED AS FILE
			   *is_file  = 1; // object is a FILE
			}else if( fSysQuery.st_mode & S_IFDIR ) {
			   *is_dir   = 1; // object is a DIRECTORY
			}else if( fSysQuery.st_mode & S_IFLNK ) {  // ONLY  UNIX / LINUX  !! NOT WINDOWS !!
			   *is_link  = 1; // object is a SYMBOLIC LINK
			}   
			//if( fSysQuery.st_mode & S_ISLINK ) *is_link  = 1; // object is a SYMBOLIC LINK
			// otherwise use
			// ..the 'MACRO-WAY'  (some Linux-Systems use macros instead of constants)
			// if( S_IFREG( sSysQuery.st_mode ) ) *is_file = 1; // object is a FILE
			// if( S_IFDIR( sSysQuery.st_mode ) ) *is_dir  = 1; // object is a DIRECTORY
			// if( S_IFLNK( sSysQuery.st_mode ) ) *is_link = 1; // object is a  SYMBOLIC LINK
			// if( S_ISLINK( sSysQuery.st_mode ) ) *is_link = 1; // object is a  SYMBOLIC LINK
			
			
			// if object is a directory, test if there exists also a file with the same name
			// NORMALLY THIS CAN   N O T   BE THE CASE !
				//if( is_dir ) { 
				//	if( access( fSysObjPath, EXIST ) != -1 ) *is_file = 1;
				//}	
			
			// PROBLEM: 
			// On WINDOWS a file can not be distinguished from a link by
			// using the bitmask  S_IFLNK  , so some further examinations
			// have to be encountered.
			// My approach for Windows:
			//
			//       If the file has the extension  .lnk   AND
			//       a size between   300..300 byte  (that was the typical size on my machine)
			//       then it's assumed to be a link. 
			// 
			// FIXME: THERE MUST BETTER APPROACH !!??
			//
#ifdef	SYS_UTILS_TARGET_OS_WINDOWS		
			if( *is_file ) { // if we have Windows and a file was detected..
				*is_link = 0; //..we start assuming the object is NOT a link..
				str_GetFileExtStr ( &Extension, Path_fSysObj, &err ); //..and proceed with checking its extension 
				str_tolowerStr(&Extension, &err ); 
				if( str_cmp( Extension , ".lnk" , 0 ) == 0 ) {
					FileSize = sys_GetFileSize( Path_fSysObj ); //..and its size..
					if( ((long long)200 <= FileSize) && (FileSize <= (long long)3000) ) {
						*is_link = 1; //..before it's finally guessed to be LINK
					}	
				}	
				free(Extension);    Extension = NULL;
			}	
#endif
			
			if( *is_file || *is_dir || *is_link ) {
				
				result = 1; // object EXISTS !				
			}				
		}else{
			result = 0; // not an error --> object does not exist
		}	
	}
		
	return( result );
} // sys_ObjExists	


int
sys_IsRelativePath ( const char* path ) {

	long L, p1,p2,
	        q1,q2;	
	int result = 0;
	
	L = str_len( path );
	if( L > 0) {
		// is path relative ?
		p1 = p2 = q1 = q2 = -1;
		               p2 = str_pos( path , "../"  , 0, 0 ); // search for  ../  in path string 
		if( p2<0 ) {   p1 = str_pos( path , "./"   , 0, 0 ); // search for   ./  in path string 
	   	  if( p1<0 ) { q2 = str_pos( path , "..\\" , 0, 0 ); // search for  ..\  in path string 
		    if( p2<0 ) q1 = str_pos( path , ".\\"  , 0, 0 ); // search for   .\  in path string 
	  	  }
		}
		          
		if( (p1 >= 0) || (p2 >= 0) || 
		    (q1 >= 0) || (q2 >= 0) ) {
		    	result = 1;
		}
	}
	return(result);				
} // sys_IsRelativePath
		
		
char*
sys_QueryPathDelimiter ( char* *Delimiter ) {

	int   err;
	long  p0, p1, p2;	     
	char* CurrDir   = NULL;   

		sys_GetCurrDir( &CurrDir );
		
		//Delimiter == / or \ ?
		//query the actual path delimiter from current dir:  
		p0 = -1;    str_ini( Delimiter );
		p1 = str_pos ( CurrDir, "/" , 0, 0);		if( p1 >= 0 ) p0 = p1;
		p2 = str_pos ( CurrDir, "\\" , 0, 0);		if( p2 >= 0 ) p0 = p2;
		if( (p1>=0)&&(p2>=0) ) {  if( p1 < p2 ) p0 = p1; else p0 = p2;  }
		if( p0 >= 0 ) {
			str_Ncopy( Delimiter , CurrDir , p0 , 1 , &err );
		}	
		free( CurrDir );    CurrDir = NULL;
		
	return(*Delimiter);	
		
} // sys_QueryPathDelimiter	


char*
sys_CygPathToWinPath ( char* *Path ) {
	
	int E;
	long L, p;
	
	L = str_len( *Path );
	if( L > 0 ) {
		str_trimStr( Path , &E );
		p = str_pos( *Path , Prefix_CygPath , 0, 0 );
		if( p == 0 ) {
			L = str_len( Prefix_CygPath );
			str_delete( Path , p, L, &E );
			str_insert( Path , ":" , 1, &E ); // insert : as 2nd character
			(*Path)[0] = toupper( (*Path)[0] ); // toupper from <ctype.h>
		}	
		str_replaceStr ( Path, LONG_MAX, "/",  "\\" , 0, 0, &E ); // replace / by \ in path string
	}
	return(*Path);
} // sys_CygPathToWinPath


char*
sys_WinPathToCygPath ( char* *Path ) {
	
	int E;
	long L, p;
	
	L = str_len( *Path );
	if( L > 0 ) {
		str_trimStr( Path , &E );
		p = str_pos( *Path , ":\\" , 0, 0 ); // search for :\ in path string
		if( p == 1 ) {			
			str_delete( Path , p, 1, &E ); // delete :
			(*Path)[0] = tolower( (*Path)[0] ); // tolower from <ctype.h>
			str_insert( Path , Prefix_CygPath , 0 , &E );
		}	
		str_replaceStr ( Path, LONG_MAX, "\\",  "/" , 0, 0, &E ); // replace \ by / in path
	}
	return(*Path);
} // sys_WinPathToCygPath

	
char* 
sys_ExpandName ( char* *Full_Path , const char* Name_fSysObj ) {
	// Queries the current directory path and appends the name string 	
	// specified by Name_fSysObj.
	// Returns on SUCCESS a string with the full path
	//         on FAILURE an empty string

	int DO_DELETE;
	int  err;
	long L, p0, p1, p2, 
	        q0, q1, q2;
	char* Name      = NULL;   
	char* Delimiter = NULL;   
	char* CurrDir   = NULL;   
	
	err = str_ini( Full_Path );
	
	L = str_len( Name_fSysObj );
	if( L > 0 ) {
		
		sys_GetCurrDir( &CurrDir );
		
		//Delimiter == / or \ ?
		//query the actual path delimiter from current dir:  
		sys_QueryPathDelimiter( &Delimiter );
		
	    str_copy( &Name, Name_fSysObj , &err );     str_trimStr( &Name , &err );
		
		//search for pattern  ./ or  .\ in name string and delete it if existing 
		//BUT DO NOT DELETE  ../ or ..\ !!  ()
		p0 = -1;
		p1 = str_pos ( Name, "./" , 0, 0);		if( p1 >= 0 ) p0 = p1;
		p2 = str_pos ( Name, ".\\" , 0, 0);		if( p2 >= 0 ) p0 = p2;
		q0 = -1;
		q1 = str_pos ( Name, "../" , 0, 0);		if( q1 >= 0 ) q0 = q1;
		q2 = str_pos ( Name, "..\\" , 0, 0);    if( q2 >= 0 ) q0 = q2;
		if( (q1 == p1-1) || (q2 == p2-1) ) {
			DO_DELETE = 0;
		}else{
			DO_DELETE = 1;
		}	
		if( DO_DELETE ) {
			str_delete( &Name, p0 , 2 , &err);
		}

		str_catenate4( Full_Path , CurrDir, Delimiter,  Name ,  &err );
		
		// correct mixtures of \ and / 
		if( Delimiter[0] == '/' ) {
			str_replaceStr ( Full_Path, LONG_MAX, "\\", Delimiter , 0, 0, &err);
		}else{
			str_replaceStr ( Full_Path, LONG_MAX, "/",  Delimiter , 0, 0, &err);
		}	
		
		free(Name);         Name      = NULL;
		free(Delimiter);    Delimiter = NULL;
		free(CurrDir);      CurrDir   = NULL;		
	}	
	return(*Full_Path);
} // sys_ExpandName
	
	
char* 
sys_MakeAbsolute ( char* *Path , int *E ) {
	// Removes relative path sections  ../ and ..\ from a given
	// path string leaving the resulting destination unchanged.
	// Returns on SUCCESS the path string as pure absolute path
	//         on FAILURE a NULL pointer and indicates an error.

	const int  reverse = 1;
	
	int REPEAT;
	int err;
	long L, P, P0, p1, p2;
	// for debugging puposes    
	// char* S = *Path; // toggle comment off to see value
	
	*E = -1; // raise ERROR flag
			
	L = str_len( *Path );
	if( L > 0 ) {
	
	    str_trimStr( Path , &err );
	    
		REPEAT = 1;
		while( REPEAT && !err) { 
			
		    REPEAT = 0;
			//search FORWARD for "one-dir-up"-pattern  ../ or ..\  in path string 
			P = -1;
			p1 = str_pos ( *Path, "../"  , 0, 0);    if( p1 >= 0 ) P = p1;	 
			p2 = str_pos ( *Path, "..\\" , 0, 0);    if( p2 >= 0 ) P = p2;	
			if( (p1>=0)&&(p2>=0) ) {  if( p1 < p2 )  P = p1;  else  P = p2;  } // if both (by fault!) then take the SMALLER in P
			//search BACKWARDS(=reverse!) for / or \ which separates the leading directory level
			//before the "one-dir-up"-pattern
			P0 = -1;
			if( P >= 0 ) {
				p1 = str_posnext ( P-2 , *Path, "/" , reverse , 0);    if( p1 >= 0 ) P0 = p1;	 
				p2 = str_posnext ( P-2 , *Path, "\\", reverse , 0);    if( p2 >= 0 ) P0 = p2;	 
				if( (p1>=0)&&(p2>=0) ) {  if( p2 > p1 )  P0 = p2;  else  P0 = p1;  } // if both (by fault!) then take the LARGER in P0
			}	 
			
			if( (P0 >= 0) && (P > P0+1) ) {
				REPEAT = 1;
				str_delete( Path, P0+1 , P-P0+2 , &err);
			}
		}
				
		if( err ) {
			*E = -1; // raise ERROR flag
			return(NULL); // EXIT ON ERROR
		}	

		REPEAT = 1;
		while( REPEAT && !err) { 
			
		    REPEAT = 0;
			//search FORWARD for "curr-dir"-pattern  ./ or .\  in path string 
			P = -1;
			p1 = str_pos ( *Path, "./"  , 0, 0);    if( p1 >= 0 ) P = p1;	 
			p2 = str_pos ( *Path, ".\\" , 0, 0);    if( p2 >= 0 ) P = p2;	
			if( (p1>=0)&&(p2>=0) ) {  if( p1 < p2 )  P = p1;  else  P = p2;  } // if both (by fault!) then take the SMALLER in P
			
			if( P >= 0 ) { //
				REPEAT = 1;
				str_delete( Path, P , 2 , &err);
			}
		}
		
		L = str_len(*Path);
		while(  (L>0) && ( ((*Path)[L-1] == '/') ||
		                   ((*Path)[L-1] == '\\') )  ) {
			str_delete( Path, L-1, 1, &err );	
        }                   	
				
		if( err ) {
			*E = -1; // raise ERROR flag
			return(NULL); // EXIT ON ERROR
		}	
		
		*E = 1; // indicate SUCCESS

	}	
	
	return(*Path);
} // sys_MakeAbsolute


char*	
sys_GetAbsolutePath ( char* *AbsPath, const char* Name_fSysObj ) {
	// Adds path string of current dir to name string and removes 
	// relative path sections  ../ and ..\ from the resulting string.
	// Returns on SUCCESS the path string as pure absolute path
	//         on FAILURE a NULL pointer which indicates an error.
	
	int E;
	
	sys_ExpandName( AbsPath , Name_fSysObj );
	sys_MakeAbsolute( AbsPath , &E );
	if( !E ) {
		return(*AbsPath);
	}else{
		return(NULL);
	}	
} // sys_GetAbsolutePath	


char*
sys_GetCurrDir ( char* *s ) {
	// Queries the current working directory path.
	// Returns on SUCCESS the path-string and
	//         oN FAILURE a NULL pointer.
	
	const long L_MAX = 1024;  //..are there paths longer than this ?? if so, then increase
	
	int err = 0;
	
	err = str_Nini( s , L_MAX); 
	
	if( err ) return(NULL); // EXIT ON ERROR 
	
	getcwd( *s , L_MAX+1 );
	str_memtrim( s ); // fit string to actual length
	
	return(*s);
} // sys_GetCurrDir	


int 
sys_GetUID ( const char* Path_fSysObj ) {
	// Queries the user ID of a file or directory specified by path.
		
	int  UID = 0, GID = 0;
	
	sys_GetOwner( Path_fSysObj , &UID, &GID); 	
	return(UID);
} // sys_GetUID	


int 
sys_GetGID ( const char* Path_fSysObj ) {
	// Queries the group ID of a file or directory specified by path.
		
	int  UID = 0, GID = 0;
	
	sys_GetOwner( Path_fSysObj , &UID, &GID); 	
	return(GID);
} // sys_GetGID	


void 
sys_GetOwner ( const char* Path_fSysObj, int *UID, int *GID ) {
	// Queries the user and group ID of a file or directory specified by path.
		
	struct stat fSysQuery;
		
	int  err = 0;
	long L;  
	
	*UID = -1;
	*GID = -1;
		
	L = str_len( Path_fSysObj );
	if( L > 0 ) {
		
		err = stat( Path_fSysObj, &fSysQuery ); // query file system
		
		if( !err ) {			
			*UID = fSysQuery.st_uid;
			*GID = fSysQuery.st_gid;
		}	
	}		
	return;
} // sys_GetOwner

    
    // TODO: does not work on Windows
    //                                                                           
	//	  int                                                                          
	//	  sys_SetUID ( const char* Path_fSysObj, int UID ) {                           
	//	  	// Sets the user ID of a file or directory specified by path.            
	//	  	                                                                         
	//	  	int result = -1; // indicate FAILURE	                                 
	//	  	                                                                         
	//	  	int  GID = sys_GetGID( Path_fSysObj );                                   
	//	  	                                                                         
	//	  	if( GID > 0 ) {                                                          
	//	  		result = sys_SetOwner( Path_fSysObj , UID, GID); 	                 
	//	  	}	                                                                     
	//	  	return(result);                                                          
	//	  } // sys_SetUID	                                                             
	//	                                                                               
	//	  int                                                                          
	//	  sys_SetGID ( const char* Path_fSysObj, int GID ) {                           
	//	  	// Sets the group ID of a file or directory specified by path.           
	//	  	                                                                         
	//	  	int result = -1; // indicate FAILURE	                                 
	//	  	                                                                         
	//	  	int  UID = sys_GetUID( Path_fSysObj );                                   
	//	  	                                                                         
	//	  	if( UID > 0 ) {                                                          
	//	  		result = sys_SetOwner( Path_fSysObj , UID, GID); 	                 
	//	  	}	                                                                     
	//	  	return(result);                                                          
	//	  } // sys_SetGID	                                                             
	//	                                                                               
	//	                                                                               
	//	  int                                                                          
	//	  sys_SetOwner ( const char* Path_fSysObj, int UID, int GID ) {                
	//	  	// Sets the user and group ID of a file or directory specified by path.  
	//	  	//                                                                       
	//	  	// CAUTION :  it is not checked that  UID + GID  exists on the system !!!
	//	  	// 	                                                                     
	//	  	                                                                         
	//	  	int  result = -1; // indicate FAILURE	                                 
	//	  	long L;                                                                  
	//	  	                                                                         
	//	  	L = str_len( Path_fSysObj );                                             
	//	  	if( L > 0 ) {                                                            
	//	  		if(sys_FileExists(Path_fSysObj)) {                                                                     
	//		  		result = chown( Path_fSysObj, UID, GID ); // from <sys/unistd>
	//	  		}
	//	  		                                                                     
	//	  	}		                                                                 
	//	  	return(result);                                                          
	//	  } // sys_SetOwner                                                            
    

long long
sys_GetFileSize ( const char* path ) {
	// Queries the file size (also for LINKS !) in bytes
	// for the file specified by path.
	// Returns the file size in bytes or  -1 on error.
	
	struct stat fSysQuery;
	
	long long result;
	int  err, is_file = 0, 
	          is_link = 0;
	long L;  
	
	result = (long long)0;  // set to 0 assuming an empty file
	
	L = str_len( path );
	if( L > 0 ) {
		
		err = stat( path, &fSysQuery ); // query file system
		
		if( !err ) {
			// if the constants  S_IFREG , S_IFDIR  are defined in sys/stat.h 
			// then use
			// ..the 'CONSTANT-WAY'
			if( fSysQuery.st_mode & S_IFREG ) is_file = 1; // object is a FILE
		//	if( fSysQuery.st_mode & S_IFLNK ) is_link = 1; // object is a LINK
			// otherwise use
			// ..the 'MACRO-WAY'  (some Linux-Systems use macros instead of constants)
			// if( S_IFREG( sSysQuery.st_mode ) ) is_file = 1; // object is a FILE
		//  if( S_IFLNK( sSysQuery.st_mode ) ) is_link = 1; // object is a LINK
			
			if( is_file || is_link ) {				
				result = (long long)fSysQuery.st_size; // file size in bytes
			}else{
				result = (long long)-1; // indicate ERROR
			}					
		}else{
			result = (long long)-1; // indicate ERROR
		}	
	}
		
	return( result );
} // sys_GetFileSize	


struct tm* 
sys_GetLastModifyTime ( const char* Path_fSysObj ) {
	// Queries the date & time of last modification of a file 
	// or directory specified by path.
	// Returns on
	//   SUCCESS a timeptr which contains the date and time
	//           of the file in a structure of type tm.
	//   FAILURE a NULL pointer.
	
	struct stat fSysQuery;
	
	struct tm* result;
	int  err;
	long L;  
	
	result = NULL;  // initialize to NULL
	
	L = str_len( Path_fSysObj );
	if( L > 0 ) {
		
		err = stat( Path_fSysObj, &fSysQuery ); // query file system
		
		if( !err ) {
			result = localtime( &fSysQuery.st_mtime ); // file size in bytes
		}	
	}
		
	return( result );
} // sys_GetLastModifyTime


int 
sys_SetLastModifyTime ( const char* Path_fSysObj, struct tm* timeptr ) {
	// Sets the date & time of last modification of a file 
	// or directory specified by path.
	// Returns on
	//   SUCCESS 0 
	//   FAILURE -1.
	//
	// members of structure  tm  :
	//	 	int tm_sec      /* seconds after minute [0-61] (61 allows for 2 leap-seconds)*/
	//	 	int tm_min      /* minutes after hour [0-59] */
	// 		int tm_hour     /* hours after midnight [0-23] */
	// 		int tm_mday     /* day of the month [1-31] */
	// 		int tm_mon      /* month of year [0-11] */
	// 		int tm_year     /* current year-1900 */
	// 		int tm_wday     /* days since Sunday [0-6] */
	// 		int tm_yday     /* days since January 1st [0-365] */
	// 		int tm_isdst    /* daylight savings indicator */
	
	
	int  result = -1; // indicate FAILURE
	int  err;
	long L;  
	struct stat  fSysQuery;
	struct utimbuf  set_time;
		
	L = str_len( Path_fSysObj );
	if( L > 0 ) {
		
		err = stat( Path_fSysObj, &fSysQuery ); // query file system
		
		if( !err ) {			
			 set_time.actime  = fSysQuery.st_atime; // keep last access date/time
			 set_time.modtime = mktime( timeptr );  // change last modify date/time
			 
 			 // now set date/time of dest.file to new values
			 if( utime( Path_fSysObj, &set_time ) < 0 ) return(result); // EXIT ON ERROR
			
			 result = 0; // indicate SUCCESS			 
		}	
	}
	
	return( result );
} // sys_SetLastModifyTime


attr_t* 
sys_GetAttributes ( const char* Path_fSysObj ) {
	// Queries the access attributes of a file or directory specified by path.
	// Returns on
	//   SUCCESS an array[10] of int (type attr_t) with
	//              attr[0] =  1/2/3 :  file / directory / symbolic link   
	//              attr[1] =  1 / 0 :  USER   Read     yes/no
	//              attr[2] =  1 / 0 :  USER   Write    yes/no
	//              attr[3] =  1 / 0 :  USER  eXecute   yes/no
	//              attr[4] =  1 / 0 :  GROUP  Read     yes/no
	//              attr[5] =  1 / 0 :  GROUP  Write    yes/no
	//              attr[6] =  1 / 0 :  GROUP eXecute   yes/no
	//              attr[7] =  1 / 0 :  OTHER  Read     yes/no
	//              attr[8] =  1 / 0 :  OTHER  Write    yes/no
	//              attr[9] =  1 / 0 :  OTHER eXecute   yes/no
	//   FAILURE  all  -1 .
	
#ifdef __unix__
	int bits[10] = { 0 ,  S_IRUSR, S_IWUSR, S_IXUSR,
	                      S_IRGRP, S_IWGRP, S_IXGRP,
	                      S_IROTH, S_IWOTH, S_IXOTH };
#else // NOT UNIX or LINUX --> WINDOWS
	int bits[10] = { 0 ,  S_IREAD, S_IWRITE, S_IEXEC,
	                            0,        0,       0,
	                            0,        0,       0 };
#endif	
	
	struct stat fSysQuery;
	
	
	attr_t* result;
    size_t mem_size;	
	int  i, i_max = Nmax_attr-1,  err = 0;
	long L;  
	
	mem_size = Nmax_attr*sizeof(int);
	result = (attr_t*)malloc(mem_size);

	for(i=0;i<=i_max;i++) (*result)[i] = -1;  // initialize attribute array
	
	L = str_len( Path_fSysObj );
	if( L > 0 ) {
		
		err = stat( Path_fSysObj, &fSysQuery ); // query file system
		
		if( !err ) {
			
			      if( sys_SymLnkExists( Path_fSysObj ) ) {				
							(*result)[0] = 3; 
							
			}else if( sys_DirExists( Path_fSysObj ) ) {
							(*result)[0] = 2;
				//Test for FILE at the end --> on WINDOWS a LINK is also a FILE !
			}else if( sys_FileExists( Path_fSysObj ) ) {  
							(*result)[0] = 1;	
			}	  
			
			
			
			for(i=1;i<=i_max;i++) {
			  if( fSysQuery.st_mode & bits[i] ) {
			      (*result)[i] = 1; 
			  }else{
			      (*result)[i] = 0; 
			  }    
			}  
		}	
	}
		
	return( result );
} // sys_GetAttributes	


char* 
sys_AttrToStr ( char* *s,  attr_t* attributes ) {
	// Returns a string showing the access attributes contained
	// in the array attributes
	// The strings has a length of 10 charaters where
	//    s[0] = '-':file / 'd':directory / 'l':link
	//    s[1] = 'r' / '-'  USER   Read    access yes/no
	//    s[2] = 'w' / '-'  USER   Write   access yes/no
	//    s[3] = 'x' / '-'  USER  eXecute  access yes/no
	//    s[4] = 'r' / '-'  GROUP  Read    access yes/no
	//    s[5] = 'w' / '-'  GROUP  Write   access yes/no
	//    s[6] = 'x' / '-'  GROUP eXecute  access yes/no
	//    s[7] = 'r' / '-'  OTHER  Read    access yes/no
	//    s[8] = 'w' / '-'  OTHER  Write   access yes/no
	//    s[9] = 'x' / '-'  OTHER eXecute  access yes/no	
	// On FAILURE a NULL pointer is returned	
	
	int  i_max = Nmax_attr-1;
	int  i,j,k, err = 0;
	
	str_ini( s );
		
	if( attributes != NULL ) {
				
		// if NOT attributes[0] == 1,2,3 then ERROR
		if( !(( (*attributes)[0] == 1) ||
		      ( (*attributes)[0] == 2) ||
		      ( (*attributes)[0] == 3)) )  err = 1; 

		// if NOT attributes[1..9] = 0,1 then ERROR		    		    
		for(i=1;i<=i_max;i++) { 
			if( !(( (*attributes)[i] == 0 ) ||
			      ( (*attributes)[i] == 1 ))  )  err = 1; 
		}
		
		
		if( !err ) {
			
			str_Nini( s , Nmax_attr );
			
			switch ( (*attributes)[0] ) {
				case 1: (*s)[0]='-';  break;
				case 2: (*s)[0]='d';  break;
				case 3: (*s)[0]='l';  break;
			}	
			for(i=1;i<=3;i++) {
				for(j=1;j<=3;j++) {					
					k = (i-1)*3 + j;					
					switch( (*attributes)[k] ) {
						case 0: (*s)[k]='-';  break;
						case 1: switch (j ) {
									case 1: (*s)[k]='r';  break;
									case 2: (*s)[k]='w';  break;
									case 3: (*s)[k]='x';  break;
								}	
					}			
				}
			}
			  
		}	
	}
		
	return(*s);
} // sys_AttrToStr	

