/*                      Copyright  (C)  2006    Patrick Rix 
 * unistruc.h
 * ===========
 * Header file for  unistruc.c
 * 
 * LICENSE
 *                not yet defined
 * 
 * AUTHOR(S)
 *                Patrick Rix          e-mail: <patrick.rix@online.de>
 */
 
#ifndef UNISTRUC_H_
#define UNISTRUC_H_

#define VERSION_UNISTRUC     "0.0.0" 
#define MODULE_UNISTRUC     "unistruc" 

#include <stdio.h>


////////////////////////////////////////////////////////////
// <<<  GLOBAL DEFINITION OF STRUCTURES + TYPES   >>>
// <<<  exported by  unistruc                      >>>  
////////////////////////////////////////////////////////////
#define  LENGTH_UNI_FORMAT_INDICATOR    10
#define         UNI_FORMAT_INDICATOR   "UNI-0.0.0\n"

enum DataTypes_enum
{	  	
  // TYPE OF MAIN STRUCTURE  UniStruct  FOR RECURSIVE SUB-STRUCTURING
	  e_T_UNI_STRUCT   = 100,  
      e_T_VECTOR_DATA  = 101,
      e_T_MATRIX_DATA  = 102,   
      e_T_ITEM_DATA    = 103,  
      e_T_OBJECT_DATA  = 104,  
      e_T_SERIES_DATA  = 105,
      e_T_DATASET_DATA = 106,   
	  	  
  // ELEMENTARY DATA-TYPES:  1 - DIMENSIONAL ARRAYS OF GENERIC C-TYPES
      e_T_CHAR        = 1,   e_T_UCHAR   = 10,
      e_T_SHORT       = 2,   e_T_USHORT  = 20,
      e_T_INT         = 3,   e_T_UINT    = 30,
      e_T_LONG        = 4,   e_T_ULONG   = 40,
      e_T_FLOAT       = 5,
      e_T_DOUBLE      = 6,
      e_T_LONG_DOUBLE = 7      
};


enum PropTypes_enum
{
      e_T_NO_PROP      =   0,   
      e_T_BASE_PROP    = 110,   
      e_T_VECTOR_PROP  = 111,
      e_T_MATRIX_PROP  = 112,   
      e_T_ITEM_PROP    = 113,  
      e_T_OBJECT_PROP  = 114,  
      e_T_SERIES_PROP  = 115,
      e_T_DATASET_PROP = 116   
};

// FORWARD DECLARATIONS for introducing types to make the following declarations work.
typedef struct BaseProp      BaseProp_t; // basic properties for objects, items, series, datasets, etc.
typedef struct EntityProp    EntityProp_t;
typedef struct GroupProp     GroupProp_t;
//typedef struct ItemProp      ItemProp_t;
//typedef struct ObjProp       ObjProp_t;

typedef  BaseProp_t*     TpointerBaseProp;
typedef  EntityProp_t*   TpointerEntityProp;
typedef  GroupProp_t*    TpointerGroupProp;

typedef union   UniProp     UniProp_t;
typedef union   UniData     UniData_t;

typedef struct  UniStruct   UniStruct_t;


//   T H E   M A I N   P O I N T E R   T Y P E   
typedef  UniStruct_t*  TpointerUniStruct;

//   T H E   M A I N   S T R U C T U R E     U n i S t r u c t
// stands for  universal structure  and forms the skeleton of a variable 
// recursivley defined data structure whose type can be determined at run 
// time.
struct UniStruct 
{
	unsigned long Size;
	short pType;  // controls the actual PROPERTY TYPE at run time --> UniProp_t  (*p).???
	short dType;  // controls the actual   DATA   TYPE at run time --> UniData    (*d).??? 
	//short vDim;   // holds the 'virtual' NUMBER OF DIMENSIONS of Data.
	//unsigned long *vSize; // array[0..vDim]; holds the 'virtual' NUMBER OF ELEMEMTS PER DIMENSION
	                      // controls the effective (member) size  N_D  of unions  p + d.
	                      // e.g.  (*d).Xi[0..(N_D-1)]  
	UniProp_t  *p; // pointer to !union! containing the actual (P)ROPERTY structure
	UniData_t  *d; // pointer to !union! containing the actual   (D)ATA   structure	
};


union UniData
{ 
  // RECURSIVE DATA-TYPES	  
  // The members  Mat + Vec   &   Obj + Item   &   DataSet + Series  are somehow redundant
  // and serve more to improve the readability of the code when building 
  // data structures with several levels.
  
    // Note: Obj must be the 1st member ! --> union initialization
	TpointerUniStruct  *Obj;  // philosophy:  an  OBJECT  owns several ITEMS
	TpointerUniStruct  *Item;  

	TpointerUniStruct  *Mat;  // philosophy:  a   MATRIX  owns several VECTORS
	TpointerUniStruct  *Vec;  
	                     
	TpointerUniStruct  *DSet; // philosophy:  a  DATASET  owns several SERIES
	TpointerUniStruct  *Ser;
	                     
 // ELEMENTARY DATA-TYPES:  1 - DIMENSIONAL ARRAYS OF GENERIC C-TYPES
	signed char   *Xc;     unsigned char   *Xuc;
	signed short  *Xs;     unsigned short  *Xus;
	signed int    *Xi;     unsigned int    *Xui;
	signed long   *Xl;     unsigned long   *Xul;
	float  *Xf;
	double *Xd;
	long double *Xld;	 
}; //UniData_t;


union UniProp
{	
    // Note: Obj must be the 1st member ! --> union initialization
	TpointerGroupProp     *Obj;   
	TpointerEntityProp    *Item;

	TpointerGroupProp     *Mat;
	TpointerEntityProp    *Vec;   

	TpointerGroupProp     *DSet; // Common properties for a set of multiple SERIES.
	TpointerEntityProp    *Ser;  // Property of one measurement/simulation TIME SERIES, FFT-series,	etc.
	
	TpointerBaseProp    *Xp;
	
}; // UniProp_t;


typedef struct ScaleStruct { // see also:  Ini() + Destroy()
	double Fac;
	double Off;	
} ScaleStruct_t;

typedef struct StatStruct { // see also:  Ini() + Destroy()
	double Min,Max,Mean,Rms;
} StatStruct_t;

typedef struct ParaStruct { // see also:  Ini() + Destroy()
	char* Name;
	double *Val;    unsigned short L_Val;
} ParaStruct_t;

struct BaseProp // basic properties for objects, items, series, datasets, etc.
{   			// see also:  Ini() + Destroy()	
	char ShareCommonProperies; // all series share the same common properties --> series do not own individual properties
	char IsSynchronized; // all series share the same reference (time track, frequency or whatever)
	char IsEquidistant;  // all series share the same equidistandt reference (const. dT, dF, etc.)   
	char IsEquisized;    // all series have the same length (number of elements
	
	char*  Name;    
	char*  Unit;
	char*  Descr;

	long  *ID;       unsigned short  L_ID; 
	long  *Index;    unsigned short  L_Index; 
	short *Flag;     unsigned short  L_Flag; 
	
	ScaleStruct_t  *Scale;    
	
	StatStruct_t   *Stat;
	
	//general informal parameters like coordinates, or other descriptive numbers
	ParaStruct_t   *Para;   unsigned short  L_Para;
		
	// More properties ? --> think in different directions 
	// e.g.  some FEM stuff 
    //   MaterialStruct_t  *Material;  
	//   TopologyStruct_t  *Topology;		
};	

	
struct EntityProp // properties of ONE ENTITY ( --> SERIES , VECTOR , ITEM )
{   			  // see also:  Ini() + Destroy()
	TpointerBaseProp    Base;
	TpointerUniStruct   Ref;   //   -->   R E C U R S I V E   STRUCTURE  !!
}; 


struct GroupProp // properties for grouping types ( --> DATASET , MATRIX , OBJECT )
                 // SHARED properties, common for ALL ENTITIES (--> SERIES , VECTORS , ITEMS) contained in a group
{			     // see also:  Ini() + Destroy()
	
	short TimeStamp[6];   // yyyy.mm.dd hh.nn.ss
	char* FileName;
	char* Title;
		
	TpointerBaseProp    Base;
	// Shared Properties  -->   R E C U R S I V E   STRUCTURE  !!
	TpointerEntityProp  Shared; // array holding the properties of each series contained in the set
}; 


////////////////////////////////////////////////////////////
// <<<  GLOBAL CONSTANTS  exported by  unistruc.c  >>>  
////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////
// <<<  GLOBAL FUNCTIONS + MACROS exported by  unistruc.c  >>>  
////////////////////////////////////////////////////////////

 // extern int  InitializeUniStruct     ( TpointerUniStruct UNI );

  extern int  CreateUniStruct    ( TpointerUniStruct *UNI,  unsigned long Size,  short dType,  short pType );
  extern int  ResizeUniStruct    ( TpointerUniStruct *UNI,  unsigned long Size );  
  extern int  EqualizeUniStruct  ( TpointerUniStruct *UNI,  unsigned long Size );  
  extern int  DestroyUniStruct   ( TpointerUniStruct *UNI );
  
  extern int  AppendBlockToUniStruct    ( TpointerUniStruct *UNI,  unsigned long Number );
  extern int  InsertBlockToUniStruct    ( TpointerUniStruct *UNI,  unsigned long Index,  unsigned long Number );
  extern int  DeleteBlockFromUniStruct  ( TpointerUniStruct *UNI,  unsigned long Index,  unsigned long Number );
  
 // TODO:
 // extern int  CopyElementWithinUniStruct     ( TpointerUniStruct *UNI, unsigned long Index,  unsigned long NewIndex );
 // extern int  MoveElementWithinUniStruct     ( TpointerUniStruct *UNI, unsigned long Index,  unsigned long NewIndex );
 // extern int  XchangeElementsWithinUniStruct ( TpointerUniStruct *UNI, unsigned long Index_1,  unsigned long Index_2 );
 //
 // extern int  CopyElementBetweenUniStructs     ( TpointerUniStruct *UNI_1,  unsigned long Index_1, 
 //                                                TpointerUniStruct *UNI_2,  unsigned long Index_2 );
 // extern int  MoveElementBetweenUniStructs     ( TpointerUniStruct *UNI_1,  unsigned long Index_1, 
 //                                                TpointerUniStruct *UNI_2,  unsigned long Index_2 );
 // extern int  XchangeElementsBetweenUniStructs ( TpointerUniStruct *UNI_1,  unsigned long Index_1, 
 //                                                TpointerUniStruct *UNI_2,  unsigned long Index_2 );
 // extern int  AppendUniStructs ( TpointerUniStruct *UNI_1,
 //                                TpointerUniStruct *UNI_2,);
 // extern int  SplitUniStruct ( TpointerUniStruct *UNI_1,  unsigned long Index_1,  
 //                              TpointerUniStruct *UNI_2,);
  
  extern int  TransposeUniStruct ( TpointerUniStruct *UNI );
  
  extern void GetSubSizesUniStruct ( TpointerUniStruct UNI,  unsigned long *MinSz,  unsigned long *MaxSz );
  extern void GetSubTypesUniStruct ( TpointerUniStruct UNI,  short *dType,  short *pType );

  extern FILE*  OpenFileUniStruct    ( int MODE,  const char* FileName );
  extern long   BlockReadUniStruct   ( FILE *F,  long Fpos_0,  TpointerUniStruct *UNI,  unsigned long L0,  unsigned long NL,  unsigned long *NR,  int *E );  
  extern long   BlockWriteUniStruct  ( FILE *F,  long Fpos_0,  TpointerUniStruct *UNI,  unsigned long L0,  unsigned long NL,  unsigned long *NW,  int *E );

  extern int CreateBaseProp  ( TpointerBaseProp *BaseProp );
  extern int DestroyBaseProp ( TpointerBaseProp *BaseProp );
      

#endif /*UNISTRUC_H_*/
