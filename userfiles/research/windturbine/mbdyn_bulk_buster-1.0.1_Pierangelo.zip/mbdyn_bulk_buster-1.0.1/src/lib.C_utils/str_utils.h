/*                      Copyright  (C)  2006    Patrick Rix 
 * str_utils.h
 * ===========
 * Header file for  str_utils.c
 * 
 * LICENSE
 *                not yet defined
 * 
 * AUTHOR(S)
 *                Patrick Rix          e-mail: <patrick.rix@online.de>
 */
#ifndef STR_UTILS_H_
#define STR_UTILS_H_

#define VERSION_STR_UTILS     "0.0.0" 
#define MODULE_STR_UTILS     "str_utils" 

//  Set  STR_UTILS_TARGET_OS_???  to choose OPERATING SYSTEM DEPENDENT STRING SETTING
//  ENABLE ONLY ONE ENTRY AND DISABLE ALL OTHER
#define     STR_UTILS_TARGET_OS_WINDOWS   1  
//#define   STR_UTILS_TARGET_OS_LINUX     1

//==============================================================================
//   !!!   IMPORTANT NOTE   !!!   IMPORTANT NOTE   !!!   IMPORTANT NOTE   !!!
//==============================================================================
//
//   INITIALIZE STRING  =  NULL   before using the str_utils - routines.
//
//   This is because when working with strings (=pointer to char) a
//   pointer variable which is not NULL can not be distinguished between
//   not yet mallocated (and thus containing junk) or pointing to a 
//   string constant.
//   BOTH SITUATIONS WILL LEAD TO   F A I L U R E   .
//
//     -->  String variable may not point to STRING CONSTANT. (e.g.:  S = "ABC";)
//     -->  String variable not mallocated but pointer value != NULL.
//    
//	 TIP:   a string var definition could look like this
//
//				char* S = NULL;   str_ini(&S);
//    
//==============================================================================

////////////////////////////////////////////////////////////
// <<<  GLOBAL CONSTANTS  exported by  str_utils.c  >>>  
////////////////////////////////////////////////////////////

  extern const char* DQ; // a  double  quote char " 
  extern const char* SQ; // a (single) quote char '

  extern const char* LF; 
  extern const char* LF2; 
  extern const char* LF3; 
  extern const char* LF4; 
  extern const char* LF5; 
  
  extern const char* PathDelim;
  extern const char* DriveDelim;
  extern const char* PathSep;

////////////////////////////////////////////////////////////
// <<<  GLOBAL FUNCTIONS + MACROS exported by  str_utils.c  >>>  
////////////////////////////////////////////////////////////
  
#define   Efmt(X, width, d_exp)    Efmt_( (long double)X , (int)width, (int)d_exp )
#define   Ffmt(X, width, d_frac)   Ffmt_( (long double)X , (int)width, (int)d_frac )
  
  extern void  str_free  (char* *s1); 
  extern int   str_clear (char* *s1); 
  extern int   str_ini   (char* *s1);
  extern int   str_Nini  (char* *s1, long N);    
  extern int   str_memtrim (char* *s1);  
  
  extern int   str_is_numstr (const char* s1);
  extern int   str_is_intstr (const char* s1);
  extern int   str_cmp (const char* s1, const char* s2, int casens);  
  extern long  str_len (const char* s1);  
  extern long  str_pos (const char* s1, const char* s2, int reverse, int casens);
  extern long  str_posnext (long p0, const char* s1, const char* s2, int reverse, int casens);
  
  extern long  str_copy  (char* *s1, const char* s2, int *E);
  extern char* str_cpy              (const char* s);
  
  extern long  str_Ncopy (char* *s1, const char* s2, long p, long n, int *E);
  extern char* str_Ncpy             (const char* s,  long p, long n);
  
  extern int   str_getnextStrL  (char* *s1, char* *s2, int *E);
  extern char* str_getnextL     (char* *s);  
  extern int   str_getnextStrR  (char* *s1, char* *s2, int *E);		
  extern char* str_getnextR     (char* *s);    
  extern int   str_getnextStrCL (char* *s1, char* *s2, const char* cs, int *E);
  extern char* str_getnextCL    (char* *s,             const char* cs);  
  extern int   str_getnextStrCR (char* *s1, char* *s2, const char* cs, int *E);		
  extern char* str_getnextCR    (char* *s,             const char* cs);		    
  extern int   str_getnextSubStr(char* *s1, char* *s2, const char* cs, int reverse, int casens, int *E);
  
  extern void  str_splitP (char* *s1, char* *s2, long p, int *E);
  extern void  str_splitC (char* *s1, char* *s2, const char* cs, int reverse, int casens, int *E);
  extern void  str_splitS (char* *s1, char* *s2, const char* s3, int reverse, int casens, int *E);
  
  extern long  str_replaceStr (char* *s1, long N, const char* s2, const char* s3, int reverse, int casens, int *E);
  extern char* str_repl       (char* *s1, long N, const char* s2, const char* s3, int reverse, int casens);  
  
  extern void  str_delete (char* *s1, long p, long n, int *E);
  extern char* str_del    (char* *s1, long p, long n);  
  
  extern void  str_insert (char* *s1, const char* s2, long p, int *E);
  extern char* str_ins    (char* *s1, const char* s2, long p);
  
  extern void  str_catenate         (char* *s1, const char* s2, int *E);
  extern char* str_cat        (const char*  s1, const char *s2);
  extern void  str_catenate3        (char* *s1, const char* s2 , const char* s3, int *E);
  extern char* str_cat3       (const char*  s1, const char* s2 , const char* s3);  
  extern void  str_catenate4        (char* *s1, const char* s2 , const char* s3 , const char* s4, int *E);
  extern char* str_cat4       (const char*  s1, const char* s2 , const char* s3 , const char* s4);  
  extern void  str_catenate5        (char* *s1, const char* s2 , const char* s3 , const char* s4 , const char* s5, int *E);
  extern char* str_cat5       (const char*  s1, const char* s2 , const char* s3 , const char* s4 , const char* s5);  
  extern void  str_catenate10       (char* *s1, const char* s2 , const char* s3 , const char* s4 , const char* s5, const char* s6, const char* s7 , const char* s8 , const char* s9 , const char* s10, int *E);
  extern char* str_cat10      (const char*  s1, const char* s2 , const char* s3 , const char* s4 , const char* s5, const char* s6, const char* s7 , const char* s8 , const char* s9 , const char* s10);
  
  extern void  str_trimStr  (char* *s1, int *E);
  extern char* str_trim     (char* *s1);  
  extern void  str_trimStrL (char* *s1, int *E);
  extern char* str_trimL    (char* *s1);  
  extern void  str_trimStrR (char* *s1, int *E);
  extern char* str_trimR    (char* *s1);
  
  extern void  str_trimStrC  (char* *s1, const char* cs, int *E);
  extern char* str_trimC     (char* *s1, const char* cs);  
  extern void  str_trimStrCL (char* *s1, const char* cs, int *E);  
  extern char* str_trimCL    (char* *s1, const char* cs);  
  extern void  str_trimStrCR (char* *s1, const char* cs, int *E);
  extern char* str_trimCR    (char* *s1, const char* cs);
  
  extern void  str_removeLF  (char* *s, int *E);
  extern char* str_remLF     (char* *s);
  
  extern void  str_fillStrL (char* *s1, const char *s2, long n, int *E);
  extern char* str_fillL    (char* *s1, const char *s2, long n);  
  extern void  str_fillStrR (char* *s1, const char *s2, long n, int *E);
  extern char* str_fillR    (char* *s1, const char *s2, long n);
  
  extern void  str_tolowerStr (char* *s1, int *E);
  extern char* str_tolower    (char* *s1);
  extern void  str_toupperStr (char* *s1, int *E);
  extern char* str_toupper    (char* *s1);
  
  extern void  str_GetFileNameStr   (char* *s1, const char* s2, int *E);
  extern char* str_GetFileName                 (const char* s2);  
  extern void  str_GetFilePathStr   (char* *s1, const char* s2, int *E);
  extern char* str_GetFilePath                 (const char* s2);  
  extern void  str_GetFileExtStr    (char* *s1, const char* s2, int *E);
  extern char* str_GetFileExt                  (const char* s2);  
  extern void  str_ChangeFileExtStr (char* *s1, const char* s2, int *E);
  extern char* str_ChangeFileExt               (const char* s2);  
  
  extern          double str_toDbl   (const char* s1, int *E);
  extern          float  str_toFlt   (const char* s1, int *E);
  extern          long   str_toLong  (const char* s1, int *E);
  extern          int    str_toInt   (const char* s1, int *E);
  extern          short  str_toShrt  (const char* s1, int *E);
  extern   signed char   str_toChar  (const char* s1, int *E);
  extern unsigned long   str_toUlong (const char* s1, int *E);
  extern unsigned int    str_toUint  (const char* s1, int *E);
  extern unsigned short  str_toUshrt (const char* s1, int *E); 
  extern unsigned char   str_toUchar (const char* s1, int *E); 
    
  extern char* Efmt_ (long double X, int width, int d_exp);  // not intended for direct use --> USE MACRO instead
  extern char* Ffmt_ (long double X, int width, int d_frac); // not intended for direct use --> USE MACRO instead

#endif /*STR_UTILS_H_*/
