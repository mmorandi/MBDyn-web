/*                      Copyright  (C)  2006    Patrick Rix 
 * strlist.c
 * ===========
 * Contains utilities for working with text files
 * using linked lists containing string data.
 * Covers loading / saving of text files into / to
 * string lists and routines for list manipulation
 * like inserting + deleting of elements, etc.
 * 
 * 
 * LICENSE
 *                not yet defined
 * 
 * AUTHOR(S)
 *                Patrick Rix          e-mail: <patrick.rix@online.de>
 *
 * Modification History
 * ====================
 * Version      Date         Editor      Changes/Modifications/Improvements
 * -------------------------------------------------------------------------
 *   
 *  VERSION_STR_UTILS  -->  remember to update version number in header file
 * 
 *  0.0.0    30.June 2006    Rix         Basic Version, 1st beta release.
 * 
 */
 
#include "strlist.h"

#include "str_utils.h"
#include <stdlib.h>
#include <limits.h>

//#include <stdio.h>    // for sprintf()
//#include <stdlib.h>   // for memory allocation
//#include <ctype.h>    // for tolower/toupper + character testing(isalpha(), isdigit(), etc.)
//#include <string.h>   // for strlen(), strcpy(), strcat(), etc.
//#include <float.h>    // for DBL_MAX, etc.
//#include <limits.h>   // for INT_MAX, etc.
//#include <math.h>	  // for fabs()

// static const char* module  = MODULE_STRLIST;
// static const char* version = VERSION_STRLIST;

  static const long  MAX_LINE_LENGTH = 1024*1024; // = 1 MB
	
////////////////////////////////////////////////////////////
// <<<  LOCAL FUNCTIONS  private to   strlist.c  >>>  
////////////////////////////////////////////////////////////
  static int strlist_BlockCopyOrMoveToStrList ( int MoveMode,  TpointerStringList  *SrceStrList,  TpointerStringList  *DestStrList,  long L1, long NL1,  long L2,  int *E);  
  static                void   adjust_to_Len          (long *L0, long *NL, long Len);
  static                 int   strlist_CreateElem     (TpointerStrListElem  *StrListElem,  int *E);
  static                 int   strlist_IniElem        (TpointerStrListElem  *StrListElem,  int *E);
  static                 int   strlist_DestroyElem    (TpointerStrListElem  *StrListElem,  int *E);
  static TpointerStrListElem   strlist_seek_forward   (TpointerStringList  *StringList,  TpointerStrListElem  StrListElem,  long index);
//  static TpointerStrListElem   strlist_seek_backward  (TpointerStringList  *StringList,  TpointerStrListElem  StrListElem,  long index);
  static char* DEBUG_InsString(char* TEXT , TpointerStringList  *StringList,  TpointerStrListElem  StrListElem,  long position);

////////////////////////////////////////////////////////////
// <<<  GLOBAL CONSTANTS  exported by  strlist.c  >>>  
////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////
// <<<  GLOBAL FUNCTIONS  exported by  strlist.c  >>>  
////////////////////////////////////////////////////////////

static long 
fSeekLine (FILE *F, long L) {
// #######################################################                        
// !!!   IMPORTANT  NOTE  -->  R E S T R I C I T I O N    !!!
// !!!   The function only works reliably for files with a   MAXIMUM FILE SIZE  <=  2 GB   !!!
// !!!   due to the limited number range of data type "long"  in functions fseek() and fSeekLine()  !!!
// #######################################################                        
	// Seeks in an open text file after line index  L-1  that
	// successive file operations start a line L .
	// Index L counts from 0 !
	// RETURNS
	// on  SUCCESS  the actual file position  Fpos > 0
	// on  FAILURE  Fpos = -1  .
	
	long Fpos;
	
	int err = 0;
	long i;
	char *S  = NULL;
	
	Fpos = -1;
	if( F != NULL ) {
		err = fseek( F, 0L, SEEK_SET ); 
		if( !err ) {
			if( L == 0 ) {
			 // we have already finished
			}else{
			 // L > 0	
			    err = str_Nini( &S, MAX_LINE_LENGTH+1 ); // get memory and initialize it 
				i = -1;    
				while( (i < (L-1)) && !feof(F) && !err ) {
					i++;
					if( !fgets( S , MAX_LINE_LENGTH, F ) ) err = 1;
				}
				if( S != NULL ) { free(S);   S = NULL; }	// free memory
				
				if( i != (L-1) ) return(Fpos);  // EXIT ON ERROR
			}	
			
			Fpos = ftell( F );	
		}
	}
	return(Fpos);	
} // fSeekLine	


int 
strlist_ReadFILE ( FILE *F,   TpointerStringList *StringList,   int *E ) {

// #######################################################                        
// !!!   IMPORTANT  NOTE  -->  R E S T R I C I T I O N    !!!
// !!!   The function only works reliably for files with a   MAXIMUM FILE SIZE  <=  2 GB   !!!
// !!!   due to the limited number range of data type "long"  in functions fseek() and fSeekLine()  !!!
// #######################################################                        
	long Fpos_0 = 0;
	long L0 = -1;
	long NL = LONG_MAX;
	long MaxSize = -1;
	long RL;
	
	strlist_BlockReadFILE ( F,   StringList,   Fpos_0,   L0, NL,   MaxSize,   &RL,  E );
	
	return(*E);
}


long 
strlist_BlockReadFILE ( FILE *F,   TpointerStringList *StringList,   
                        long Fpos_0,  long L0,  long NL,  long MaxSize,   
                        long *RL,
                        int *E ) {
// #######################################################                        
// !!!   IMPORTANT  NOTE  -->  R E S T R I C I T I O N    !!!
// !!!   The function only works reliably for files with a   MAXIMUM FILE SIZE  <=  2 GB   !!!
// !!!   due to the limited number range of data type "long"  in functions fseek() and fSeekLine()  !!!
// #######################################################                        
	// Reads from an open text file pointed to by  F  a continous block of  NL  lines
	// starting at text line  L0  (counting from 0 !!) into a string list  StringList  ,
	// P R O V I D E D   Fpos_0  <  0   !!!
	// ALTERNATIVELY, IF   Fpos_0  >=  0   THEN  L0  WILL BE IGNORED and instead of 
	// using a line index the file position is used to start from.
	// OPTIONALLY to the number of lines to read specified by NL a maximum nb. of 
	// characters can be given by  MaxSize  which will not be exeeded.
	// If  MaxSize  <=  0  then any nb. of characters will be read until the nb. of
	// lines read reaches  NL  or the end of file.
	// In variable  RL  the procedure gives back the nb. of lines acutally read.
	// Errors are reported in  E  while 0 means no errors occured and -1 inidcates
	// that something failed.
	// The function RETURNS
	//   ON SUCCESS  the actual file position at the end of reading 
	// 				 or EOF if the end of file is reached.	
	//   ON FAILURE  -1  .
	
	const int DEBUG = 0;
	
	long Fpos;
	
	TpointerStrListElem	Elem_i;	
	int MaxSize_EXCEEDED = 0;
	int Seek_OK;
	int err;
	long ActSize, NewSize;
	long L, i, line;
	char *S = NULL;
	
	Fpos = -1;
	
	*E = -1; // raise ERROR flag
	*RL = 0;
		
	if( F != NULL ) {
		
		Seek_OK = -1;
		if( Fpos_0 < 0 ) {
		// seek LINE 
			Fpos_0 = fSeekLine( F , L0 );
			if( Fpos >= 0 )  Seek_OK = 1;
		}else{
		// seek file position	
			err = fseek( F , Fpos_0 , SEEK_SET );
			if( !err )  Seek_OK = 1;
		}
		
		ActSize = 0;
		if( Seek_OK ) {
		// start reading
			if( *StringList == NULL ) {
				strlist_CreateStrList( StringList, &err);
			}else{
				strlist_ClearStrList( StringList, &err);
			}
			
			if( err ) return(Fpos);  // EXIT ON ERROR
			
			err = str_Nini( &S, MAX_LINE_LENGTH+1 ); // get memory and initialize it 
			line = L0;
			*RL = 0;    MaxSize_EXCEEDED = 0;
			while( (*RL < NL) && !feof(F) && !err && !ferror(F) && !MaxSize_EXCEEDED ) {
				line++;   // actual text line to read next
				          // (counting FROM  1 !)
				// fgets reads the complete line INCLUSIVE the line feed at the end         
				if( !fgets( S , MAX_LINE_LENGTH, F ) ) err = 1; 

				
				if( !err && !ferror(F)) {					
					str_removeLF( &S, &err ); // remove the trailing line feed from the string
					L = str_len(S);    NewSize = ActSize + L;
					if( (MaxSize <= 0) ||
					    ((MaxSize > 0)&&(NewSize <= MaxSize)) ) {
						
						strlist_AppString( StringList, S, &err );
						
						if( !err ) {
							(*RL)++;
							Fpos = ftell( F );
							ActSize = NewSize;
						}	
					}else{
						MaxSize_EXCEEDED = 1;
					}		
				} 					
			}	
			if( S != NULL ) { free(S);   S = NULL; }	// free memory			
			
			if( feof(F) ) Fpos = EOF;
			
			if(  (*RL == NL) || 
			     ((*RL > 0)&&( (feof(F))||(MaxSize_EXCEEDED)) )  ) {
			     	
			    *E = 0;	 // indicate SUCCESS
			    
				    if( DEBUG ) {
				    	Elem_i = (*StringList)->StrLstRoot;
				    	for(i=0;i<(*StringList)->Count;i++) {
				    		line = L0+i+1; 
				    		if( Elem_i != NULL ) {
				    			printf("%05ld>%s\n", line, Elem_i->str);
					    		Elem_i = Elem_i->next;
				    		}	
				    	}	
				    }	
			}     				
		}	
	}	
	
	return(Fpos);
} // strlist_BlockReadFILE                        	


int 
strlist_WriteFILE ( FILE *F,   TpointerStringList *StringList,   int *E ) {

// #######################################################                        
// !!!   IMPORTANT  NOTE  -->  R E S T R I C I T I O N    !!!
// !!!   The function only works reliably for files with a   MAXIMUM FILE SIZE  <=  2 GB   !!!
// !!!   due to the limited number range of data type "long"  in functions fseek() and fSeekLine()  !!!
// #######################################################                        
	long Fpos_0 = 0;
	long L0 = 0;
	long NL = LONG_MAX;
	long RL;
	
	strlist_BlockWriteFILE ( F,  StringList,  Fpos_0,  L0, NL,  &RL,  E );
	
	return(*E);
}


int 
strlist_AppendToFILE ( FILE *F,   TpointerStringList *StringList,   int *E ) {

	long Fpos_0 = LONG_MAX;
	long L0 = 0;
	long NL = LONG_MAX;
	long RL;
	
	strlist_BlockWriteFILE ( F,  StringList,  Fpos_0,  L0, NL,  &RL,  E );
	
	return(*E);
}


long 
strlist_BlockWriteFILE ( FILE *F,   TpointerStringList *StringList,   
                        long Fpos_0,  long L0,  long NL,  
                        long *RL,
                        int *E ) {
// #######################################################                        
// !!!   IMPORTANT  NOTE  -->  R E S T R I C I T I O N    !!!
// !!!   The function only works reliably for files with a   MAXIMUM FILE SIZE  <=  2 GB   !!!
// !!!   due to the limited number range of data type "long"  in functions fseek() and fSeekLine()  !!!
// #######################################################                        
	// Writes into an open text file pointed to by  F  a continous block of  NL  lines
	// of a string list  StringList  starting at line  L0  (string list index counting from 0 !!) ,
	// Fpos_0 controls the position in file where the block will be placed/written.
	// If  Fpos_0  <  0  the block will be written at the actual file position (=feature disabled),
	// otherwise the file position indicator will be moved first to the new file position.
	// If  Fpos_0 == LONG_MAX   the block will be appended at the end of the file.
	// The behaviour whether the file is truncated or not if the actual file position
	// is not the end of the file depends on the mode in which the file was opened.
	// In variable  RL  the procedure gives back the nb. of lines acutally written.
	// Errors are reported in  E  while 0 means no errors occured and -1 inidcates
	// that something failed.
	// The function RETURNS
	//   ON SUCCESS  the actual file position at the end of writing
	// 				 or EOF if end of file is the actual position.	
	//   ON FAILURE  -1  .
	
	
	long Fpos;
	
	TpointerStrListElem		Elem_i = NULL;
	int Seek_OK;
	int  err;
	long Len, i;
	char *S = NULL;
	
	Fpos = -1;
	
	*E = -1; // raise ERROR flag
	*RL = 0;
		
	if( (F != NULL) && (*StringList != NULL) ) {
		
		Len = strlist_GetLen( StringList );
		
		if( (0 <= L0) && (L0 <= Len ) ) {
		
			adjust_to_Len ( &L0, &NL, Len );
		
			Seek_OK = -1;
			if( Fpos_0 < 0 ) {
			// actually DO NOTHING
			// write at actual file position	
				Seek_OK = 1;
				// seek LINE 
				//	Fpos_0 = fSeekLine( F , L0 );
				//	if( Fpos >= 0 )  Seek_OK = 1;
			}else{
			// seek file position	
			    if( Fpos_0 == LONG_MAX ) {
			    	err = fseek( F , 0L , SEEK_END );			    	
			    }else{
			    	err = fseek( F , Fpos_0 , SEEK_SET );
			    }	
				if( !err )  Seek_OK = 1;
			}
			
			if( Seek_OK ) {
			// start writing
				Elem_i = strlist_seek_forward( StringList, Elem_i, L0);
				*RL = 0;    i = -1;    
				while( (Elem_i != NULL) && (*RL < NL) && !err && !ferror(F) ) {
					i++;
					// fputs writes a complete line (=string) WITHOUT a line feed at the end         
					if( fputs( Elem_i->str , F ) ) err = 1; 
					
					// The solution below was TOO SLOW !!
					// if( fputs( strlist_GetString( StringList, &S, L0+i, &e0 ) , F ) ) err = 1; 
					
					fputs( LF, F ); // write a line feed;	
					
					if( !err && !ferror(F) ) {
						(*RL)++;
						Fpos = ftell( F );
					} 					
					
					Elem_i = Elem_i->next;
				}	
				if( S != NULL ) { free(S);   S = NULL; }	// free memory			
				
				if( feof(F) ) Fpos = EOF;
				
				if( *RL == NL ) { 
				     	
				    *E = 0;	 // indicate SUCCESS
				    
				}     				
			}	
		}	
	}	
	
	return(Fpos);
} // strlist_BlockWriteFILE                        	


int
strlist_CreateStrList (TpointerStringList  *StringList, int *E) {
//..creates an empty string list structure (allocates memory and intializes all fields to zero / NULL)	
	size_t	mem_size;
	int err; 
	
	*E = -1;  // raise ERROR flag
	
	mem_size = sizeof(TStringList);
	
	if( *StringList == NULL ) {
		
		*StringList = (TpointerStringList) malloc(mem_size);  // get new memory
		
			(*StringList)->F = NULL;
			(*StringList)->FNme = NULL;  
			(*StringList)->StrLstRoot = NULL;  
			(*StringList)->StrLstEnd  = NULL;

			*E = 0;  // incidcate SUCCESS
		
	}else{  // (*StringList) != NULL 
			
		strlist_CloseStrList( StringList, &err );
			
		if( !err ) {
			*E = 0;  // incidcate SUCCESS
		}
	}
	
	return(*E);	
} // strlist_CreateStrList

int
strlist_OpenStrList (TpointerStringList  *StringList,  const char* FileName, int *E) {
//..opens the specified file in FileName for reading and saves the file handle in StrinList.F and clears the string list unless it was already empty.
//  A previously opened file will be closed first.
//  RESTRICTION:   StringList object must exist !!!  i.e. it must have be created using  strlist_CreateStrList()   !!!

 //	size_t	mem_size;
	int err = 0; 
	
	*E = -1;  // raise ERROR flag
	
	if( *StringList == NULL ) { // string list object not existing --> has to be created first !!!
		return(*E);	
	}
		
		strlist_CloseStrList( StringList, &err );
        
		if( err ) {
			return(*E);  // ..exit on FAILURE
		}
			
		(*StringList)->F = NULL;
		(*StringList)->FNme = NULL;  
		(*StringList)->StrLstRoot = NULL;  
		(*StringList)->StrLstEnd  = NULL;
		
		(*StringList)->F = fopen( FileName , "rt" ); // open text file for reading
        
		if( (*StringList)->F == NULL ){
			return(*E);  // ..exit on FAILURE
		}
		
		(*StringList)->FNme = str_cpy(FileName);  
		
		*E = 0;  // incidcate SUCCESS
	
	return(*E);	
} // strlist_OpenStrList


int
strlist_ClearStrList (TpointerStringList  *StringList, int *E) {
//..just clears the string list but leaves the file open and filename unchanged
	TpointerStrListElem	RootNext;
	int err;
	
	*E = 0;  // indicate SUCCESS;
				
	if( *StringList != NULL ) {
		
/*        
		// close file if open and set file pointer to NULL
		if( (*StringList)->F != NULL ) {
			if( !fclose( (*StringList)->F ) ) *E = -1;
			(*StringList)->F = NULL;  
		}
		str_ini( &((*StringList)->FNme) ); // resets FNme to an empty string (just \0)
*/
		
		// FREE MEMORY
		// Destroy string list elementwise starting from root
		err = 0;
		while ( (!err) && (*StringList)->StrLstRoot != NULL ) {
			RootNext = (*StringList)->StrLstRoot->next;  // get pointer to next element after root element
			
			strlist_DestroyElem( &(*StringList)->StrLstRoot, &err ); // delete root element
			
			(*StringList)->StrLstRoot = RootNext; // make the next element to actual root element
		}	
		if( err ) *E = -1;
		
		(*StringList)->StrLstRoot = NULL;
		(*StringList)->StrLstEnd  = NULL;
		(*StringList)->Count = 0;		
	}	
	
	return(*E);	
} // strlist_ClearStrList


int
strlist_CloseStrList (TpointerStringList  *StringList,  int *E) {
//..clears the string list, closes file and sets filename to NULL
	
	TpointerStrListElem	RootNext;
	int err;
	
	*E = 0;  // indicate SUCCESS;
				
	if( *StringList != NULL ) {
		
		// close file if open and set file pointer to NULL
		if( (*StringList)->F != NULL ) {
			if( !fclose( (*StringList)->F ) ) *E = -1;
			(*StringList)->F = NULL;  
		}
		str_ini( &((*StringList)->FNme) ); // reset FNme to an empty string (just \0)
		
		// FREE MEMORY
		// Destroy string list elementwise starting from root
		err = 0;
		while ( (!err) && (*StringList)->StrLstRoot != NULL ) {
			RootNext = (*StringList)->StrLstRoot->next;  // get pointer to next element after root element
			
			strlist_DestroyElem( &(*StringList)->StrLstRoot, &err ); // delete root element
			
			(*StringList)->StrLstRoot = RootNext; // make the next element to actual root element
		}	
		if( err ) *E = -1;
		
		(*StringList)->StrLstRoot = NULL;
		(*StringList)->StrLstEnd  = NULL;
		(*StringList)->Count = 0;		
	}	
	
	return(*E);	
} // strlist_CloseStrList


int
strlist_DestroyStrList (TpointerStringList  *StringList, int *E) {
		
	int err; 
	
	*E = 0;  // incidcate SUCCESS
		
	if( *StringList != NULL ) {
		
		strlist_CloseStrList ( StringList, &err);  // closes the file, frees the linked list of strings
		                                    // and resets file name to an empty string
		if( err ) *E = -1; // raise ERROR flag
		
		// Free meomory for string data
		if ( (*StringList)->FNme != NULL ) {
			free( (*StringList)->FNme );
			(*StringList)->FNme = NULL;
		}	  
		
		// Now free the complete string list and set pointer to NULL
		free( *StringList );
		*StringList = NULL;				
	}
	
	return(*E);	
} // strlist_DestroyStrList


int
strlist_SortStrList (TpointerStringList  *StringList,  int increasing,  int casens,  int *E) {
	
	long L, i,j;
	char* Si = NULL;
	char* Sj = NULL;
	int cmp_result;
	int e1,e2,e3, err = 0; 
	
	*E = 0;  // incidcate SUCCESS
		
	if( *StringList != NULL ) {
		L = strlist_GetLen( StringList );
		if( L == 1 ){ // List is already sorted -> has only 1 element
			*E = 0;  // indicate SUCCESS
		}else if( L > 1) {
			i = -1;   err = 0;
			while( (i < (L-2)) && !err) { // i = 0..(L-2)
				i++;  j = i;
				while( (j < (L-1)) && !err) { // j = (i+1)..(L-1)
					j++;
					cmp_result = str_cmp( strlist_GetString( StringList, &Si, i, &e1) ,
					                      strlist_GetString( StringList, &Sj, j, &e2) , casens);
					e3 = 0;                      
					if( increasing ) { // -> A,B,C,..,Z						
						if( cmp_result == 2 )  strlist_XchString( StringList, i, j, &e3);
					}else{ // decreasing -> Z,Y,X,..,A
						if( cmp_result == 1 )  strlist_XchString( StringList, i, j, &e3);
					}
					if( e1 ||  e2 ||  e3 ) {
						err = -1;  // EXIT ON ERROR
					}	
				}
			}	
			if( !err ) {
				*E = 0;  // indicate SUCCESS			
			}	
		}	 		
	}
	
	return(*E);	
} // strlist_DestroyStrList


long
strlist_GetLen (TpointerStringList  *StringList) {
	
	if( *StringList != NULL ) {
		return( (*StringList)->Count ); 
	}else{		
		return(-1);
	}
} // strlist_GetLen


int
strlist_AppString (TpointerStringList  *StringList, const char* string, int *E) {
	
	long position;
	
	*E = -1;  // raise ERROR flag
		
	if( (*StringList != NULL) && (string != NULL) ) {
		
		position = (*StringList)->Count; 
	    
	    strlist_InsString( StringList, string, position, E );
	}	

	return(*E);		
} // strlist_AppString


int
strlist_InsString (TpointerStringList  *StringList, const char* string, long position,  int *E) {
	
	const int DEBUG = 0;  // 1 = switch on  DEBUG OUTPUT
	                      // 0 = switch off DEBUG OUTPUT 
	
    TpointerStrListElem		StrListElem;
	TpointerStrListElem		Elem_j, Elem_k; 
	long k;
	int err;
	char* Text = NULL;	
	
	*E = -1;  // raise ERROR flag
		
	if( (*StringList != NULL) && (string != NULL) ) {
		// correct position if index out of range..
		if( position < 0 ) position = 0;  // set postion as 1. element
		if( position > (*StringList)->Count )  position = (*StringList)->Count; // set position as last element
				
		// ASSERTED:  position == 0..Count !! 
		
		// Next: Get memory for new element
		strlist_CreateElem( &StrListElem, &err );
		
		if( (StrListElem != NULL) && (!err) ) {
			
			if( position < (*StringList)->Count ) {
				// I N S E R T   E L E M E N T   inbetween two list elemnts 
				
				// seek list forward for element at index 'position'
				Elem_k = strlist_seek_forward  ( StringList,  Elem_k,   position);
											
				if( Elem_k == NULL ) {
					//  C R I T I C A L   E R R O R  
					//  UNEXPECTED END OF LIST (index mismatch)
					//  List ends before i = Count --> Count is not up to date ?!
					*E = -1;  // raise ERROR flag 
					return(*E);	 // EXIT FUNCTION ON ERROR				
				}
				
				// Everything OK:  position index was found --> now insert new element.
				Elem_j = Elem_k->prev;
					
							if( DEBUG ) {
			                    str_copy( &Text, "\n strlist_InsString(), INSERTING ELEMENT  index = ", &err);    str_catenate3( &Text, Ffmt(position,-1,0) , "\n" , &err);
			                    str_catenate( &Text, "\n BEFORE\n", &err);   
			                    printf( "%s" , DEBUG_InsString( Text, StringList, StrListElem, position) );
							}    
					
				StrListElem->next = Elem_k;
				StrListElem->prev = Elem_j;
				Elem_k->prev = StrListElem;			
				Elem_j->next = StrListElem;		
					
							if( DEBUG ) {
			                    str_copy( &Text, "\n strlist_InsString(), INSERTING ELEMENT  index = ", &err);    str_catenate3( &Text, Ffmt(position,-1,0) , "\n" , &err);
			                    str_catenate( &Text, "\n AFTER\n", &err);   
			                    printf( "%s" , DEBUG_InsString( Text, StringList, StrListElem, position) );
							}    
				
				(*StringList)->Count++;  // increase COUNT (nb.of string list elements)
				 StrListElem->index = position;  // set index of new element

				str_copy( &(StrListElem->str), string, &err);  // NOW COPY THE STRING 
				
				if( err ) {
					//  C R I T I C A L   E R R O R   
					//  FAILED TO COPY STRING
					*E = -1;  // raise ERROR flag					
					return(*E);	 // EXIT FUNCTION ON ERROR
				}	
									
				// re-number the indices of the 'right' part 
				// starting at index position+1.
				k = position;    Elem_k = StrListElem;
				while( (k < ((*StringList)->Count - 1) ) &&
				       (Elem_k->next != NULL) ) {
					k++;
					Elem_k = Elem_k->next;
					Elem_k->index = k; 
				}
				
				//..sollte eigentlich �berfl�ssig sein
				//(*StringList)->StrLstEnd = Elem_k;  // update the pointer to EndOfList
				
				if( Elem_k->index != ((*StringList)->Count - 1) ) {
					//  C R I T I C A L   E R R O R   
					//  UNEXPECTED END OF LIST (index mismatch)
					//  List ends before i = Count --> Count is not up to date ?!
					*E = -1;  // raise ERROR flag
					return(*E);	 // EXIT FUNCTION ON ERROR
				}	
				
				*E = 0;  // indicate SUCCESS
							
			}else{ 
				// A P P E N D   E L E M E N T   at end of list
				 
				if( position == 0 ) { // list is empty --> new element gets the 1st element
					
							if( DEBUG ) {
			                    str_copy( &Text, "\n strlist_InsString(), APPENDING ELEMENT  index = ", &err);    str_catenate3( &Text, Ffmt(position,-1,0) , "\n" , &err);
			                    str_catenate( &Text, "\n BEFORE\n", &err);   
			                    printf( "%s" , DEBUG_InsString( Text, StringList, StrListElem, position) );
							}    
	                 
					// THE ROOT ELEMENT 
					(*StringList)->StrLstRoot = StrListElem;
					(*StringList)->StrLstRoot->next = NULL;
					(*StringList)->StrLstRoot->prev = NULL;
										
					(*StringList)->StrLstEnd  = (*StringList)->StrLstRoot; 
					//(*StringList)->StrLstEnd->next = NULL; // already done with root->next,prev
					//(*StringList)->StrLstEnd->prev = NULL;
	
							if( DEBUG ) {
			                    str_copy( &Text, "\n strlist_InsString(), APPENDING ELEMENT  index = ", &err);    str_catenate3( &Text, Ffmt(position,-1,0) , "\n" , &err);
			                    str_catenate( &Text, "\n AFTER\n", &err);   
			                    printf( "%s" , DEBUG_InsString( Text, StringList, StrListElem, position) );
							}    
					
				}else{	// position > 0 : list has some elements --> new element is appended at end of list
					if( (*StringList)->StrLstEnd->index != ((*StringList)->Count - 1) ) {
						//  C R I T I C A L   E R R O R   
						//  UNEXPECTED END OF LIST (index mismatch)
						//  List ends before i = Count --> Count is not up to date ?!
						*E = -1;  // raise ERROR flag
						return(*E);	 // EXIT FUNCTION ON ERROR
					}
					
							if( DEBUG ) {
			                    str_copy( &Text, "\n strlist_InsString(), APPENDING ELEMENT  index = ", &err);    str_catenate3( &Text, Ffmt(position,-1,0) , "\n" , &err);
			                    str_catenate( &Text, "\n BEFORE\n", &err);   
			                    printf( "%s" , DEBUG_InsString( Text, StringList, StrListElem, position) );
							}    
					
					StrListElem->next = NULL;  // as NewElem will become the new EndElem set  NewElem->next = NULL
					StrListElem->prev = (*StringList)->StrLstEnd;  // set  NewElem->prev  pointing to actual EndElem
					(*StringList)->StrLstEnd->next = StrListElem; // actual EndElem->next won't be longer the end of list so set pointer to NewElem
					(*StringList)->StrLstEnd = StrListElem;  // now NewElem becomes the actual EndElem
	
							if( DEBUG ) {
			                    str_copy( &Text, "\n strlist_InsString(), APPENDING ELEMENT  index = ", &err);    str_catenate3( &Text, Ffmt(position,-1,0) , "\n" , &err);
			                    str_catenate( &Text, "\n BETWEEN\n", &err);   
			                    printf( "%s" , DEBUG_InsString( Text, StringList, StrListElem, position) );
							}    
					
					// link the 2nd element(=end element) with the root element
					if( position == 1 ) {
						(*StringList)->StrLstRoot->next = (*StringList)->StrLstEnd; 
						(*StringList)->StrLstEnd->prev  = (*StringList)->StrLstRoot; 
					}	
					
							if( DEBUG ) {
			                    str_copy( &Text, "\n strlist_InsString(), APPENDING ELEMENT  index = ", &err);    str_catenate3( &Text, Ffmt(position,-1,0) , "\n" , &err);
			                    str_catenate( &Text, "\n AFTER\n", &err);   
			                    printf( "%s" , DEBUG_InsString( Text, StringList, StrListElem, position) );
							}    
					
				}
				
				(*StringList)->Count++;  // increase COUNT (nb.of string list elements)
				 StrListElem->index = position;  // set index of new element

				str_copy( &(StrListElem->str), string, &err);  // NOW COPY THE STRING 
				
				if( err ) {
					//  C R I T I C A L   E R R O R   
					//  FAILED TO COPY STRING
					*E = -1;  // raise ERROR flag
					return(*E);	 // EXIT FUNCTION ON ERROR
				}	
	
				*E = 0;  // indicate SUCCESS			
				
			} // if( position < (*StringList)->Count )..else..		
		} // if( (StrListElem != NULL) && (!err) )..	
	} // if( (*StringList != NULL) && (string != NULL) )..	
		
	return(*E);	
} // strlist_InsString


int
strlist_DelString (TpointerStringList  *StringList,  long position,  int *E) {
		
	TpointerStrListElem		Elem_j, Elem_k, Elem_l; 
	long k;
	int err;
	
	*E = -1;  // raise ERROR flag
		
	if( *StringList != NULL ) {
		
		// correct position if index out of range..
		if( position < 0 ) position = 0;  // set postion as 1. element
		if( position > ((*StringList)->Count-1) )  position = (*StringList)->Count - 1; // set position as last element
				
		// ASSERTED:  position == 0..(Count-1) !! 				
		
		if(  (0 <= position)  &&  ( position < ((*StringList)->Count - 1) )  ) {		//   D E L E T E   E L E M E N T   I N B E T W E E N   L I S T
		//   D E L E T E   R O O T   E L E M E N T   OR   E L E M E N T   F R O M   I N B E T W E E N 

			// seek list forward for element at index 'position'
			Elem_k = strlist_seek_forward  ( StringList,  Elem_k,   position);
										
			if( Elem_k == NULL ) {
				//  C R I T I C A L   E R R O R  
				//  UNEXPECTED END OF LIST (index mismatch)
				//  List ends before i = Count --> Count is not up to date ?!
				*E = -1;  // raise ERROR flag 
				return(*E);	 // EXIT FUNCTION ON ERROR		
			}
			
			// Everything OK:  position index was found 				
			if( position == 0 ) {
				// DELETE ROOT ELEMENT
				
				// save address of current root element
				Elem_k = (*StringList)->StrLstRoot;
				Elem_l = (*StringList)->StrLstRoot->next;
				
				// disconnect the actual root element and make the next elem. the new root
				(*StringList)->StrLstRoot = (*StringList)->StrLstRoot->next;
				(*StringList)->StrLstRoot->prev = NULL;
				(*StringList)->StrLstRoot->index = 0;					
			}else{						
				// DELETE SOME OTHER ELEMENT
				
				Elem_j = Elem_k->prev;
				Elem_l = Elem_k->next;
					
				// disconnect element k	
				Elem_j->next = Elem_l;
				Elem_l->prev = Elem_j;
				Elem_l->index = position;  // element L getx index of deleted element
			}
			
			// DESTROY ELEMENT K AND FREE MEMORY
			strlist_DestroyElem( &Elem_k , &err );

			if( err ) {
				//  C R I T I C A L   E R R O R   
				//  FAILED TO DESTROY ELEMENT
				*E = -1;  // raise ERROR flag
				return(*E);	 // EXIT FUNCTION ON ERROR
			}	
								
			(*StringList)->Count--;  // decrease COUNT (nb.of string list elements)
												
			// re-number the indices of the 'right' part 
			// starting at index position+1.
			k = position;    Elem_k = Elem_l;
			while( (k < ((*StringList)->Count - 1) ) &&
			       (Elem_k->next != NULL) ) {
				k++;
				Elem_k = Elem_k->next;
				Elem_k->index = k; 
			}
							
			if( Elem_k->index != ((*StringList)->Count - 1) ) {
				//  C R I T I C A L   E R R O R   
				//  UNEXPECTED END OF LIST (index mismatch)
				//  List ends before i = Count --> Count is not up to date ?!
				*E = -1;  // raise ERROR flag
				return(*E);	 // EXIT FUNCTION ON ERROR
			}	
			
			*E = 0;  // indicate SUCCESS
					
		}else{ 
		//   D E L E T E   E N D   E L E M E N T 
		   
			// save address of end element
			Elem_k = (*StringList)->StrLstEnd;
			
			// disconnect the actual end element and make the previous elem. the new end
			(*StringList)->StrLstEnd = (*StringList)->StrLstEnd->prev;
			(*StringList)->StrLstEnd->next = NULL;
			(*StringList)->StrLstRoot->index = position - 1;					
	
			// DESTROY ELEMENT K AND FREE MEMORY
			strlist_DestroyElem( &Elem_k , &err );
	
			if( err ) {
				//  C R I T I C A L   E R R O R   
				//  FAILED TO DESTROY ELEMENT
				*E = -1;  // raise ERROR flag
				return(*E);	 // EXIT FUNCTION ON ERROR
			}	
	
			(*StringList)->Count--;  // decrease COUNT (nb.of string list elements)
					
			if( (*StringList)->StrLstEnd->index != ((*StringList)->Count - 1) ) {
			//  C R I T I C A L   E R R O R   
			//  UNEXPECTED END OF LIST (index mismatch)
			//  List ends before i = Count --> Count is not up to date ?!
			*E = -1;  // raise ERROR flag
			return(*E);	 // EXIT FUNCTION ON ERROR
			}
	
			*E = 0;  // indicate SUCCESS			
				
		} // if( position < (*StringList)->Count )..else..		
	} // if( *StringList != NULL )..	
		
	return(*E);	
} // strlist_DelString


int
strlist_XchString (TpointerStringList  *StringList,  long curr_index,  long new_index,  int *E) {
	//  ABECD --> Xch(2,4) --> ABDCE

	TpointerStrListElem  Elem_j, Elem_k;
	long L;
	char* string = NULL;
	//char* S = NULL;
	//int e0, e1, e21, e22, e3;
	
	*E = -1;  // raise ERROR flag
		
	if( *StringList != NULL ) {
		L = strlist_GetLen( StringList );
		if( (0 <= curr_index) && (curr_index <= (L-1)) && 
		    (0 <=  new_index) && ( new_index <= (L-1)) ) {
			
			if( new_index == curr_index ) {
				*E = -1;  // raise ERROR flag 
				return(*E);	 // EXIT FUNCTION ON ERROR		
			}	
			
			// FASTER !!			
			// SWAP STRINGS by changing the string pointers (NOT COPYING)
			// seek list forward for element at  curr_index
			Elem_j = strlist_seek_forward  ( StringList,  Elem_j,   curr_index);
			if( Elem_j == NULL ) {
				*E = -1;  // raise ERROR flag 
				return(*E);	 // EXIT FUNCTION ON ERROR		
			}
			// seek list forward for element at  new_index
			Elem_k = strlist_seek_forward  ( StringList,  Elem_k,   new_index);
			if( Elem_k == NULL ) {
				*E = -1;  // raise ERROR flag 
				return(*E);	 // EXIT FUNCTION ON ERROR		
			}
			string = Elem_j->str;
			Elem_j->str = Elem_k->str;
			Elem_k->str = string;
			
			*E = 0; // indicate SUCCESS
			
				//	// SWAP STRINGS by physically copying
				//  e0 = str_ini(&string); // get memory & initialize string
				//	// save string at curr_index into temporay variable
				//	string = strlist_GetString( StringList, string, curr_index, &e1 );
				//	// copy string from new_index to curr_index
				//	strlist_SetString( StringList, strlist_GetString( StringList, S, new_index, &e21 ), curr_index, &e22);
				//	// copy temporary string to new_index
				//	strlist_SetString( StringList, string, new_index, &e3);
				//				
				//	if(S != NULL) free(S);
				//	if(string != NULL) free(string);
				//	
				//	if( !e1 && !e21 && !e22 && !e3) {
				//		*E = 0;  // indicate SUCCESS
				//	}	
		}	
	}	
	return(*E);
} // strlist_XchString	


int
strlist_MovString (TpointerStringList  *StringList,  long curr_index,  long new_index,  int *E) {
	//  ABECD --> Mov(2,4) --> ABCDE
	
	long L;
	int e1, e2, e3;
	
	*E = -1;  // raise ERROR flag
		
	if( *StringList != NULL ) {
		L = strlist_GetLen( StringList );
		if( (0 <= curr_index) && (curr_index <= (L-1)) && 
		    (0 <=  new_index) && ( new_index <= (L-1)) ) {
		    				
			if( new_index == curr_index ) {
				*E = -1;  // raise ERROR flag 
				return(*E);	 // EXIT FUNCTION ON ERROR		
			}	
			
			strlist_InsString( StringList,    "",        (new_index + 1),  &e1);
			strlist_XchString( StringList,  curr_index,  (new_index + 1),  &e2);
			strlist_DelString( StringList,  curr_index, &e3);
			
			if( !e1 && !e2 && !e3) {
				*E = 0;  // indicate SUCCESS
			}	
		}	
	}	
	return(*E);
} // strlist_MovString	


int
strlist_SetString (TpointerStringList  *StringList,  const char* string,  long index,  int *E) {
	
	TpointerStrListElem		Elem_k; 
	int err;
	
	*E = -1;  // raise ERROR flag
		
	if( (*StringList != NULL) && (string != NULL) ) {
		
		// check: index in range ?  index == 0..(Count-1) ?
		if(  (0 <= index) && (index <= (*StringList)->Count - 1)  ) {
			
			// seek list forward for element at index 'position'
			Elem_k = strlist_seek_forward  ( StringList,  Elem_k,   index);
										
			if( Elem_k == NULL ) {
				//  C R I T I C A L   E R R O R  
				//  UNEXPECTED END OF LIST (index mismatch)
				//  List ends before i = Count --> Count is not up to date ?!
				*E = -1;  // raise ERROR flag 
				return(*E);	 // EXIT FUNCTION ON ERROR		
			}
								
			// Everything OK:  position index was found 
			//  --> now copy string to list element
		
			str_copy( &(Elem_k->str), string, &err );		
		
			if( !err ) *E = 0;  // indicate SUCCESS			
			
		} 
	} // if( (*StringList != NULL) && (string != NULL) )..	

	return(*E);		
} // strlist_SetString


char*
strlist_GetString (TpointerStringList  *StringList,  char* *string,  long index,  int *E) {
	
	TpointerStrListElem		Elem_k; 
	int err;
	
	// initialize string and return NULL in case of an error like e.g. index out of range or non-existing list, etc.
	if( *string != NULL ) {
		err = str_ini(string);
		free(*string);    *string = NULL;  
	}
		
	*E = -1;  // raise ERROR flag
		
	if( *StringList != NULL ) {
		
		// check: index in range ?  index == 0..(Count-1) ?
		if(  (0 <= index) && (index <= (*StringList)->Count - 1)  ) {
			
			// seek list forward for element at index 'position'
			Elem_k = strlist_seek_forward  ( StringList,  Elem_k,   index);
										
			if( Elem_k == NULL ) {
				//  C R I T I C A L   E R R O R  
				//  UNEXPECTED END OF LIST (index mismatch)
				//  List ends before i = Count --> Count is not up to date ?!
				*E = -1;  // raise ERROR flag 
				return(*string);	 // EXIT FUNCTION ON ERROR		
			}
								
			// Everything OK:  position index was found 
			//  --> now copy string from list element
		
			str_copy( string, Elem_k->str, &err );		
		
			if( !err ) *E = 0;  // indicate SUCCESS			
			
		} // if( (StrListElem != NULL) && (!err) )..	
	} // if( *StringList != NULL )..	

	return(*string);		
} // strlist_GetString


long
strlist_IndexOf (TpointerStringList  *StringList,  const char* string,  int reverse,  int *E) {
	// Searches for the first occurrence of a string (=COMPLETE ELEMENT) in the 
	// string list. 
	// The seach can either start at the end or beginning of the string list.
	// 
	
	long index;	
	
	long L;	
	int err;
	
	*E = -1; // raise ERROR flag
	
	index = -1; // indicate NOT FOUND	
	
	if( *StringList != NULL ) {
		
		L = strlist_GetLen( StringList );
		if( L > 0) {
			// set loop parameters
			if( reverse ) {
				  index = strlist_NextIndexOf( StringList, string, (L-1), reverse, &err);
			}else{
				  index = strlist_NextIndexOf( StringList, string,   0,   reverse, &err);
			}		    	
	    	if( !err ) {	    	
		    	*E = 0; // indicate SUCCESS
	    	}	
		}	    	
	}
	return(index);
} // strlist_IndexOf


long
strlist_NextIndexOf (TpointerStringList  *StringList,  const char* string,  long position_0,  int reverse,  int *E) {
	// Searches for the next occurrence of a string (=COMPLETE ELEMENT) in the
	// string list starting at index position_0.
	// The seach can either start at the end or beginning of the string list.
	// 
	
	const int casens = 1; // 1 = case-sensitive  ,  0 = case-INsensitive
	
	long index;	
	
	TpointerStrListElem		Elem_i;
	int FOUND, END;
	long L, i,i0,i1,i2;	
	char* string2;
	//int err;
	
	*E = -1; // raise ERROR flag
	
	index = -1; // indicate NOT FOUND	
	
	if( *StringList != NULL ) {
		
		L = strlist_GetLen( StringList );
		if( (L > 0) &&
		    (0 <= position_0) && (position_0 <= (L-1)) ) {
			// set loop parameters
			if( reverse ) {
				i0 = -1;    i1 = position_0;    i2 = 0;
			}else{
				i0 = +1;    i1 = position_0;    i2 = L-1;			
			}	
			Elem_i = strlist_seek_forward( StringList, Elem_i, position_0 );
			// start search	
			i = i1;    FOUND = 0;    END = 0;
	    	while( (Elem_i != NULL) && !FOUND && !END ) {
	    		
	    		if( Elem_i->index != i ) {
	    			// CRITICAL ERROR: index mismatch !
	    			*E = -1;
	    			return(index);   // EXIT ON ERROR
	    		}	
	    		
	    		if( i == i2 ) END = 1;  // end of list is reached
	    		
	    		string2 = Elem_i->str;  // strlist_GetString( StringList, string2, i, &err );
										//	if( err ) {
										//		*E = -1;
										//		return(index);  // EXIT ON ERROR
										//	}	
	    		
	    		if( str_cmp( string, string2, casens ) == 0 ) {
	    			FOUND = 1;
	    		}
	    		
	    		if( !FOUND && !END ) {
	    			// get next element
	    			if( reverse ) {
	    				Elem_i = Elem_i->prev;
	    			}else{
	    				Elem_i = Elem_i->next;
	    			}	
	    			i = i + i0; // increase/decrease index
	    		}	
	    	}
	    	
	    	if( FOUND ) {
	    		index = i;  // this is our RESULT
	    	}else{
		    	if( !END ) { // what ? not FOUND and not END ? --> ERROR 
	    			// CRITICAL ERROR: unexpected end of list !
	    			*E = -1;
	    			return(index);   // EXIT ON ERROR
		    	}	
		    }	 
	    	
	    	*E = 0; // indicate SUCCESS
		}	    	
	}
	return(index);
} // strlist_NextIndexOf


int
strlist_FindFirstPattern (TpointerStringList  *StringList,  const char* pattern,  long *LINE,  long *COLUMN,  int reverse,  int casens,  int *E) {
	// Searches for the first occurrence of a string pattern (=SUB STRING of an element) in the
	// string list.
	// The seach can either start at the end or beginning of the string list
	// and be either case-sensitive or not.
	// If the pattern was found the target coordinates LINE & COLUMN, are passed back.
	// 
	// Returns   1  if pattern was FOUND
	//           0  if pattern was NOT FOUND
	//
	
	int FOUND;
	long L, line_0, col_0;	
	
	*E = -1; // raise ERROR flag
	
	FOUND   =  0;  // indicate NOT FOUND	
	*LINE   = -1; 
	*COLUMN = -1;

	if( *StringList != NULL ) {
		
		L = strlist_GetLen( StringList );
		if( L > 0 ) {
			// set start parameters for search
			if( reverse ) {
				line_0 = L-1;    col_0 = LONG_MAX;
			}else{
				line_0 = 0;      col_0 = 0;
			}	
			FOUND = strlist_FindNextPattern ( StringList, pattern, 
			                                  line_0, col_0,
			                                  LINE, COLUMN,  reverse, casens, E);
		}
	}	
	return(FOUND);	
} // strlist_FindFirstPattern
		

int
strlist_FindNextPattern (TpointerStringList  *StringList,  const char* pattern,  long line_0,  long column_0,  long *LINE,  long *COLUMN,  int reverse,  int casens,  int *E) {
	// Searches for the next occurrence of a string pattern (=SUB STRING of an element) in the
	// string list starting at "coordinates"  line_0, column_0.
	// The seach can either start at the end or beginning of the string list
	// and be either case-sensitive or not.
	// If the pattern was found the target coordinates LINE & COLUMN, are passed back.
	// 
	// Returns   1  if pattern was FOUND
	//           0  if pattern was NOT FOUND
	//	
	
	TpointerStrListElem		Elem_i;	
	int FIRST, FOUND, END;
	long col_0, i,i0,i1,i2, j, L, Lstring;	
	char* string;
	
	*E = -1; // raise ERROR flag
	
	FOUND   =  0;  // indicate NOT FOUND	
	*LINE   = -1; 
	*COLUMN = -1;

	if( *StringList != NULL ) {
		
		L = strlist_GetLen( StringList );
		if( (L > 0) &&
		    (0 <= line_0) && (line_0 <= (L-1)) ) {
			// set loop parameters
			if( reverse ) {
				i0 = -1;    i1 = line_0;    i2 = 0;
			}else{
				i0 = +1;    i1 = line_0;    i2 = L-1;			
			}	
			Elem_i = strlist_seek_forward( StringList, Elem_i, line_0 );
			// start search	
			i = i1;    FIRST = 1;    FOUND = 0;    END = 0;
	    	while( (Elem_i != NULL) && !FOUND && !END ) {
	    		
	    		if( Elem_i->index != i ) {
	    			// CRITICAL ERROR: index mismatch !
	    			*E = -1;
	    			return(FOUND);   // EXIT ON ERROR
	    		}	
	    		
	    		if( i == i2 ) END = 1;  // end of list is reached
	    		
	    		string = Elem_i->str;  // strlist_GetString( StringList, string2, i, &err );
										//	if( err ) {
										//		*E = -1;
										//		return(index);  // EXIT ON ERROR
										//	}	

				Lstring = str_len( string );
				j = -1;
				if( Lstring > 0	) {
		    		if( FIRST ) {
		    			col_0 = column_0;
		    			if( (Lstring-1) < col_0 ) col_0 = (Lstring-1);
		    		}else{
		    			if( reverse ) {
		    				col_0 = (Lstring-1);
		    			}else{
		    				col_0 = 0;
		    			}	
		    		} 
		    		// search pattern in actual string
		    		j = str_posnext ( col_0, string, pattern, reverse, casens );
		    	}
		    		    		
	    		
	    		if( 0 <= j ) {
	    			FOUND = 1;
    			 // RESULT "COORDINATES"
	    			*LINE   = i;   
	    			*COLUMN = j;
	    		}

	    		if( !FOUND && !END ) {
	    			// get next element
	    			if( reverse ) {
	    				Elem_i = Elem_i->prev;
	    			}else{
	    				Elem_i = Elem_i->next;
	    			}	
	    			i = i + i0; // increase/decrease index
	    		}	
	    		
	    		FIRST = 0;
	    	}
	    	
	    	if( !FOUND && !END ) { // what ? not FOUND and not END ? --> ERROR 
    			// CRITICAL ERROR: unexpected end of list !
    			*E = -1;
    			return(FOUND);   // EXIT ON ERROR
		    }	 
	    	
	    	*E = 0; // indicate SUCCESS
		}	    	
	}
	return(FOUND);
} // strlist_FindNextPattern


int
strlist_BlockCopy (TpointerStringList  *DestStrList  ,TpointerStringList  *SrceStrList,  long L0,  long NL,  int *E) {
	// Copies from an existing, non-empty source string  list  SrcStrList  a continous block of 
	// NL lines beginning from line L0 (inclusive!) into a destination string list  DestStrList. 
	// If the DestStrList does not exist it will be created new.
	// L0 counts from 0 and must stay within the range of  SrceStringList.
	// NL may be positive (copying the following  lines from below) 
	//        or negative (copying the preceeding lines above)
	// On SUCCESS the function RETURNS  0
	// On FAILURE the fucntion RETURNS -1
	
	TpointerStrListElem		Elem_i;	
	int e0 ;
	long L, i;	
	
	*E = -1; // raise ERROR flag
	
	if( *SrceStrList != NULL ) {
		
		L = strlist_GetLen( SrceStrList );
		if( (L > 0) &&
			//(labs(NL) > 0) &&		
		    (0 <= L0) && (L0 <= (L-1)) ) {
		    	
		    // check indices and eventually make corrections
		    adjust_to_Len( &L0, &NL, L );

		    // CREATE / CLEAR DESTINATION STRING LIST
			if( *DestStrList != NULL ) { // if DestStrList already exists..    	
				strlist_ClearStrList( DestStrList , &e0 );   // ..reset list by clearing its content
			}else{
				strlist_CreateStrList( DestStrList , &e0 );   // ..otherwise create a new list
			}	  
			
			if( e0) {
				*E = -1; // raise ERROR flag
				return(*E); // EXIT ON ERROR
			}	
			  	
			// seek start element from source list
			Elem_i = strlist_seek_forward( SrceStrList, Elem_i, L0 );
			if( Elem_i != NULL ) {
				// COPY BLOCK OF ELEMENTS FROM SOURC LIST TO DESTINATION LIST
				for(i=0;i<NL;i++) {
					// append a new element to DestStrList and copy the content
					// of the actual source list element 
					strlist_AppString( DestStrList,  Elem_i->str  ,  &e0 ); 
					// copy also additional fields sz,d 				
					(*DestStrList)->StrLstEnd->sz = Elem_i->sz;
					(*DestStrList)->StrLstEnd->d  = Elem_i->d;
					
					
					Elem_i = Elem_i->next; // get next element for next turn
					
					if(   e0 || ( (Elem_i == NULL)&&(i<(NL-1)) )   ) {
						// CRITICAL ERROR
						// unexpected end of source string list OR
						// invalid operation while appending new element
						strlist_ClearStrList  ( DestStrList , &e0 );
						strlist_DestroyStrList( DestStrList , &e0 );
												
						*E = -1; // raise ERROR flag
						return(*E); // EXIT ON ERROR
					}
				}
				
				*E = 0; // indicate SUCCESS
			}	
	    } // if( (L > 0) && (0 <= L0) && (L0 <= (L-1)) ) 
	} // if( *SrceStrList != NULL )
	return(*E);	
} // strlist_BlockCopy


int
strlist_BlockInsert (TpointerStringList  *DestStrList  ,TpointerStringList  *StrList,  long L0,  int *E) {
	// Insert into an existing, destination string list  DestStrList  (which may be empty)
	// the complete content of another string list  StrList  (which may NOT be empty) 
	// at index L0.
	// L0 counts from 0 and must stay within the range of  SrceStringList.
	//
	//   ==>  ON SUCCESS THE INSERTED STRING LIST   StrList   WILL BE CLEARED !!!
	// 
	// On SUCCESS the function RETURNS  0
	// On FAILURE the fucntion RETURNS -1

	TpointerStrListElem		Elem_i, Elem_j;	
	int e0 ;
	long L1,L2, i;	
	
	*E = -1; // raise ERROR flag
	
	if( (*DestStrList != NULL) &&
	    (    *StrList != NULL) ) {
		
		L1 = strlist_GetLen( DestStrList );
		L2 = strlist_GetLen(     StrList );
				
		if( (L1 >= 0) &&   /* DestStrList may be empty */
		    (L2 > 0) && 
		    (0 <= L0) && (L0 <= L1) ) { // L1 as last index is OK --> append list to DestStrList
			
			if( L1 == 0 ) { // DestStrList is empty --> SrcList becomes DestStrList
				
				(*DestStrList)->StrLstRoot  = (*StrList)->StrLstRoot;
				(*DestStrList)->StrLstEnd   = (*StrList)->StrLstEnd;
				(*DestStrList)->Count       = (*StrList)->Count;
								
			}else{	
			  							
				if( L0 <= (L1-1) ) {
				// INSERT BLOCK OF ELEMENTS TO DESTINATION LIST
					
					if( L0 == 0 ) {
						// insert list at ROOT ELEMENT
						Elem_j = (*DestStrList)->StrLstRoot;
						(*DestStrList)->StrLstRoot = (*StrList)->StrLstRoot;
					}else{ // insert list at some other element
						
						// seek start element from destination list
						Elem_j = strlist_seek_forward( DestStrList, Elem_j, L0 );
						
						if( Elem_j == NULL ) {
							// CRITICAL ERROR --> unexpected end of list
							*E = -1; // raise ERROR flag
							return(*E);	 // EXIT ON ERROR						
						}	

						Elem_i = Elem_j->prev;
						
						if( Elem_i == NULL ) {
							// CRITICAL ERROR --> unexpected end of list
							*E = -1; // raise ERROR flag
							return(*E);	 // EXIT ON ERROR						
						}	
	
						Elem_i->next = (*StrList)->StrLstRoot;
						(*StrList)->StrLstRoot->prev = Elem_i;
					}	

					Elem_j->prev = (*StrList)->StrLstEnd;
					(*StrList)->StrLstEnd->next = Elem_j;

 					(*DestStrList)->Count = (*DestStrList)->Count  +  (*StrList)->Count;
					
				}else{ 
				// L0 == L1 --> APPEND BLOCK TO DESTINATION LIST
				
					Elem_j = (*DestStrList)->StrLstEnd;
				
					Elem_j->next = (*StrList)->StrLstRoot;
					(*StrList)->StrLstRoot->prev = Elem_j;

					(*DestStrList)->StrLstEnd = (*StrList)->StrLstEnd;

 					(*DestStrList)->Count = (*DestStrList)->Count  +  (*StrList)->Count;						
				}
			
				*E = 0; // indicate SUCCESS
					
			} // if( L1 = 0 )..else..
			
			//re-number element index
			Elem_i = (*DestStrList)->StrLstRoot;
			for(i=0;i<(*DestStrList)->Count;i++) {
				Elem_i->index = i;
				Elem_i = Elem_i->next;
			}	
			
			// finally mark StrList as empty
			(*StrList)->StrLstRoot = NULL;
		    (*StrList)->StrLstEnd  = NULL;
			(*StrList)->Count = 0;
			// and free memory by destroying StrList
			strlist_DestroyStrList( StrList , &e0);			
			*StrList = NULL;
							
			*E = 0; // indicate SUCCESS;	
					
	    } // if( (L1 => 0)&&(L2 > 0) && (0 <= L0)&&(L0 <= (L1-1)) ) 
	} // if( (*DestStrList != NULL)&&(*StrList != NULL) )
	return(*E);	
} // strlist_BlockInsert


int
strlist_BlockDelete (TpointerStringList  *StringList  ,  long L0,  long NL,  int *E) {
	// Deletes from an existing, non-empty string list  StringList  a continous block
	// of NL lines beginning at index L0 (inclusive!).
	// L0 counts from 0 and must stay within the range of  StringList.
	// On SUCCESS the function RETURNS  0
	// On FAILURE the fucntion RETURNS -1

	TpointerStrListElem		Elem_i, Elem_j, Elem_k;	
	int err ;
	long L, i,j;	
	
	if( labs(NL) == 0 ) { // if nothing to delete
		*E = 0; // indicate SUCCESS
	   	return(*E);
	}	
	
	*E = -1; // raise ERROR flag

	if( *StringList != NULL ) {
		
		L = strlist_GetLen( StringList );
				
		if( (L > 0) &&   
			(labs(NL) > 0) &&		
		    (0 <= L0) && (L0 <= (L-1)) ) {

		    // check indices and eventually make corrections
		    adjust_to_Len( &L0, &NL, L );
		    				
			if( (L0+NL-1) == (L-1) ) { 
			// DELETE END - BLOCK ON THE 'RIGHT' SIDE
				
				Elem_j = (*StringList)->StrLstEnd;
				err = 0;
				for(j=1;j<=NL;j++) { // deleting backwards from the end of the list
					
					if( err || (Elem_j == NULL) ) {
						// CRITICAL ERROR --> 
						// failed to destroy element OR
						// unexpected end of list
						*E = -1; // raise ERROR flag
						return(*E);	 // EXIT ON ERROR												
					}	
					Elem_i = Elem_j->prev;										
					strlist_DestroyElem( &Elem_j, &err );					
					Elem_j = Elem_i;
				}	

				(*StringList)->Count = (*StringList)->Count - NL;
				
				if( L0 == 0 ) { // --> entire string list has been deleted 
					// (check Elem_j to be sure)
					if( Elem_j == NULL ) {
						(*StringList)->StrLstRoot = NULL; 
						(*StringList)->StrLstEnd  = NULL;					
					}else{
						// CRITICAL ERROR --> 
						// list is LONGER than expected !??
						*E = -1; // raise ERROR flag
						return(*E);	 // EXIT ON ERROR																		
					}		 
				}else{	
					(*StringList)->StrLstEnd = Elem_j; 
					(*StringList)->StrLstEnd->next = NULL;
				}
													
			}else{ 	
			// (L0+NL-1) < (L1-1) --> DELETE BLOCKFROM THE BEGINNING OR THE MIDDLE
			
				// seek start element from string list
				Elem_j = strlist_seek_forward( StringList, Elem_j, L0 );
				
				if( Elem_j == NULL ) {
					// CRITICAL ERROR --> unexpected end of list
					*E = -1; // raise ERROR flag
					return(*E);	 // EXIT ON ERROR						
				}	
				
				Elem_i = Elem_j->prev; // save element previous to L0		
						
				err = 0;
				for(j=1;j<=NL;j++) { // deleting forward 
					
					if( err || (Elem_j == NULL) ) {
						// CRITICAL ERROR --> 
						// failed to destroy element OR
						// unexpected end of list
						*E = -1; // raise ERROR flag
						return(*E);	 // EXIT ON ERROR												
					}	
					Elem_k = Elem_j->next;										
					strlist_DestroyElem( &Elem_j, &err );					
					Elem_j = Elem_k;
				}  
				
				(*StringList)->Count = (*StringList)->Count - NL;
				
				if( L0 == 0 ) {
					(*StringList)->StrLstRoot = Elem_j;
					(*StringList)->StrLstRoot->prev = NULL;
				}else{
					Elem_i->next = Elem_j;
					Elem_j->prev = Elem_i;
				}						
		    }
		    
			//re-number element index
			Elem_i = (*StringList)->StrLstRoot;
			for(i=0;i<(*StringList)->Count;i++) {
				Elem_i->index = i;
				Elem_i = Elem_i->next;
			}	
										
			*E = 0; // indicate SUCCESS;	
		} // if( (L > 0) && (0 <= L0)&&(L0 <= (L-1)) ) 			
	} // if( *StringList != NULL )
	return(*E);	
} // strlist_BlockDelete


int
strlist_BlockXchange (TpointerStringList  *StringList,  long L1, long NL1,  long L2, long NL2,  int *E) {
	// Exchanges in an existing, string list  StringList  two continous blocks of lines.
	// THE BLOCKS MAY NOT OVERLAP.
	// The start indices L1, L2 count from 0 and must stay within the range of   StringList.
	// On SUCCESS the function RETURNS  0
	// On FAILURE the fucntion RETURNS -1

	TpointerStrListElem		Elem_i_prev,   Elem_i, Elem_j, 	 Elem_j_next,
	                        Elem_m_prev,   Elem_m, Elem_n,   Elem_n_next;
	int OVERLAP;
	long L, i;	

	*E = -1; // raise ERROR flag
	
	if( *StringList != NULL ) {
		
		L = strlist_GetLen( StringList );
				
		if( (L > 0) &&   
			//(labs(NL1) > 0) &&		
			//(labs(NL2) > 0) &&		    
		    (0 <= L1) && (L1 <= (L-1)) &&
		    (0 <= L2) && (L2 <= (L-1)) ) { 

		    // check indices of BLOCK 1 + 2 and eventually make corrections
		    adjust_to_Len( &L1, &NL1, L );
		    adjust_to_Len( &L2, &NL2, L );
			
			OVERLAP = 0;
			if ( L1 == L2 ) {// ERROR
				OVERLAP = 1;
			}else if( L1 < L2 ) {
				if( L2 <= (L1+NL1-1) )	OVERLAP = 1;				
			}else{
				if( L1 <= (L2+NL2-1) )	OVERLAP = 1;				
			}	
			
			if( OVERLAP ) {
				//CRITICAL ERROR
				*E = -1;
				return(*E);  // EXIT ON ERROR
			}	
			
			// seek first + last elements of BLOCK 1 + 2
			Elem_i = strlist_seek_forward( StringList, Elem_i, L1 );
			Elem_j = strlist_seek_forward( StringList, Elem_j, (L1+NL1-1) );
			Elem_m = strlist_seek_forward( StringList, Elem_m, L2 );
			Elem_n = strlist_seek_forward( StringList, Elem_n, (L2+NL2-1) );
			
			if ( (Elem_i == NULL) ||  (Elem_j == NULL) || 
			     (Elem_m == NULL) ||  (Elem_n == NULL) ) {
				//CRITICAL ERROR
				*E = -1;
				return(*E);  // EXIT ON ERROR			     	
	     	}     	
			// get neigbour elements of BLOCK 1   				
			Elem_i_prev = Elem_i->prev;
			Elem_j_next = Elem_j->next;

			// get neigbour elements of BLOCK 2  							
			Elem_m_prev = Elem_m->prev;
			Elem_n_next = Elem_n->next;
			
			
			
			// switch pointers: insert BLOCK 2 
			//if( Elem_i == (*StringList)->StrLstRoot ) {
			if( labs(NL2) > 0 ) {
				if( L1 == 0 ) {
					(*StringList)->StrLstRoot = Elem_m;
					(*StringList)->StrLstRoot->prev = NULL;
				}else{	
					Elem_i_prev->next = Elem_m;
					Elem_m->prev = Elem_i_prev;						
				}	
				//if( Elem_j == (*StringList)->StrLstEnd ) {
				if( (L1+NL1-1) == ((*StringList)->Count-1) ) {
					(*StringList)->StrLstEnd = Elem_n;
					(*StringList)->StrLstEnd->next = NULL;				
				}else{	
					Elem_j_next->prev = Elem_n;
					Elem_n->next = Elem_j_next;
				}		
			}
										
			// switch pointers: insert BLOCK 1 
			//if( Elem_m == (*StringList)->StrLstRoot ) {
			if( labs(NL1) > 0 ) {
				if( L2 == 0 ) {
					(*StringList)->StrLstRoot = Elem_i;
					(*StringList)->StrLstRoot->prev = NULL;
				}else{	
					Elem_m_prev->next = Elem_i;
					Elem_i->prev = Elem_m_prev;						
				}	
				//if( Elem_n == (*StringList)->StrLstEnd ) {
				if( (L2+NL2-1) == ((*StringList)->Count-1) ) {
					(*StringList)->StrLstEnd = Elem_j;
					(*StringList)->StrLstEnd->next = NULL;				
				}else{					
					Elem_n_next->prev = Elem_j;
					Elem_j->next = Elem_n_next;
				}	
			}
			
			//re-number element index
			Elem_i = (*StringList)->StrLstRoot;
			for(i=0;i<(*StringList)->Count;i++) {
				Elem_i->index = i;
				Elem_i = Elem_i->next;
			}	
										
			*E = 0; // indicate SUCCESS;	
					
	    } 
	} 
	return(*E);	
} // strlist_BlockXchange


int
strlist_BlockMove (TpointerStringList  *StringList,  long L1, long NL1,  long L2,  int *E) {
	// Moves in an existing, non-empty string list  StringList  a continous block of NL1 lines
	// starting at L1 to position L2.
	// The indices L1, L2 count from 0 and must stay within the range of   StringList.
	// The position index L2 insertion refers to the unchanged list status.
	// On SUCCESS the function RETURNS  0
	// On FAILURE the fucntion RETURNS -1

	TpointerStringList  TmpStrLst = NULL;
	int e1, e2, e3;
	long L;	

	if( (labs(NL1) == 0) || // if nothing to move
	    ((L1 <= L2)&&(L2 <= (L1+NL1))) ) { // or when moving to itself
		*E = 0; // indicate SUCCESS
	   	return(*E);
	}	
			
	*E = -1; // raise ERROR flag
	
	if( *StringList != NULL ) {
		
		L = strlist_GetLen( StringList );
				
		if( (L > 0) &&   
			(labs(NL1) > 0) &&
		    (0 <= L1) && (L1 <= (L-1)) &&
		    (0 <= L2) && (L2 <=  L) ) {  // L2 may point after the end for appending

			adjust_to_Len( &L1, &NL1, L );
			
			strlist_BlockCopy( &TmpStrLst, StringList, L1, NL1, &e1 );
			if( !e1 ) strlist_BlockDelete( StringList, L1, NL1, &e2 );
			if( L2 > (L1+NL1-1) ) {
				L2 = L2 - NL1;
			}else if( L2 >= L1 ) { // L1 <= L2 <= (L1+NL1-1)
				L2 = L2 - (NL1-(L2-L1));
			}
			
			if( !e1 && !e2 )strlist_BlockInsert( StringList, &TmpStrLst, L2, &e3 );
			
			if( !e1 && !e2 && !e3 ) {
				*E = 0; // indicate SUCCESS;				
			}	
	  	}
	}
	return(*E);	
} // strlist_BlockMove

int
strlist_BlockAppendToStrList (TpointerStringList  *DestStrList,  TpointerStringList  *SrceStrList,  long L1, long NL1,  int *E) {
	long L_END;
	*E = -1; // raise ERROR flag
	if( *DestStrList!=NULL ) {
		L_END = strlist_GetLen( DestStrList );
		strlist_BlockCopyOrMoveToStrList ( 0,  DestStrList,  SrceStrList,  L1, NL1, L_END,  E);	
	}	
	return(*E);
}

int
strlist_BlockCopyToStrList (TpointerStringList  *DestStrList,  TpointerStringList  *SrceStrList,  long L1, long NL1,  long L2,  int *E) {
	strlist_BlockCopyOrMoveToStrList ( 0,  DestStrList,  SrceStrList,  L1, NL1, L2,  E);	
	return(*E);
}

int
strlist_BlockMoveToStrList (TpointerStringList  *DestStrList,  TpointerStringList  *SrceStrList,  long L1, long NL1,  long L2,  int *E) {
	strlist_BlockCopyOrMoveToStrList ( 1,  DestStrList,  SrceStrList,  L1, NL1, L2,  E);	
	return(*E);
}

static int
strlist_BlockCopyOrMoveToStrList ( int MoveMode,  TpointerStringList  *DestStrList,  TpointerStringList  *SrceStrList,  long L1, long NL1,  long L2,  int *E) {
	// Copies or moves from an existing, non-empty source string list  SrceStrList  
	// a continous block of NL1 lines starting at L1 to position L2 in an existing 
	// destination string list  DestStrList.
	// The indices L1, L2 count from 0 and must stay within the range of   SrceStrList and DestStrList.
	// The position index L2 insertion refers to the unchanged list status.
	// On SUCCESS the function RETURNS  0
	// On FAILURE the fucntion RETURNS -1
	
	TpointerStringList  TmpStrLst = NULL;
	int e1=0, e2=0, e3=0;
	long Lsrc, Ldst;	

	if( labs(NL1) == 0 ) {  // if nothing to move
		*E = 0; // indicate SUCCESS
	   	return(*E);
	}	
			
	*E = -1; // raise ERROR flag
	
	if( (*SrceStrList != NULL) &&
	    (*DestStrList != NULL) &&
	    (*SrceStrList != *DestStrList) ) {
		
		Lsrc = strlist_GetLen( SrceStrList );
		Ldst = strlist_GetLen( DestStrList );
				
		if( (Lsrc > 0) &&   
			(labs(NL1) > 0) &&
		    (0 <= L1) && (L1 <= (Lsrc-1)) &&
		    (0 <= L2) && (L2 <=  Ldst) ) {  // L2 may point after the end for appending

			adjust_to_Len( &L1, &NL1, Lsrc );
			
			strlist_BlockCopy( &TmpStrLst, SrceStrList, L1, NL1, &e1 );
			if( MoveMode && !e1) strlist_BlockDelete( SrceStrList, L1, NL1, &e2 );			
			if( !e1 && !e2 )strlist_BlockInsert( DestStrList, &TmpStrLst, L2, &e3 );
			
			if( !e1 && !e2 && !e3 ) {
				*E = 0; // indicate SUCCESS;				
			}	
	  	}else{ // is Source-StrList is empty ?
	  		   // if so, it's not an error --> we are finished.
	  		if( Lsrc == 0 ) *E = 0; // indicate SUCCESS;				
		}	
	}
	return(*E);	
} // strlist_BlockCopyOrMoveToStrList



		  	
////////////////////////////////////////////////////////////
// <<<  LOCAL FUNCTIONS  private to   strlist.c  >>>  
////////////////////////////////////////////////////////////

static void
adjust_to_Len ( long *L0, long *NL, long Len) {
    // Checks parameters list start index L0 and block length NL
    // for exceeding the valid index range given by string list 
    // length Len and eventually corrects L0 and NL.
    // On return L0 is always the 'left' (=lower) border index.
    
    long Ldiff = 0;
    
    if( Len < 0) {
    	*L0 = -1;    *NL = 0;
    }else{	
	    if( *L0 < 0 )       { Ldiff = -*L0;             *L0 = 0; }
	    if( *L0 > (Len-1) ) { Ldiff =  *L0 - (Len-1);   *L0 = (Len-1); }
	    
	    if( *NL < 0 ) { // if NL counts 'to the left' (NL negatave !)
	    	*NL = -*NL; //..make NL positive
	    	*L0 = *L0 - (*NL-1); //..recalculate L0 that it becomes the 'left' start point
	    	if( *L0 < 0 ) *L0 = 0; //..assure that index is valid.
	    }
	    *NL	= *NL - Ldiff;
	    if( (*L0+*NL-1) > (Len-1) ) *NL = (Len-1)-*L0+1; //..check if valid index range is exceeded to the 'right'	
    }   
} // adjust_to_Len	


int
strlist_CreateElem (TpointerStrListElem  *StrListElem, int *E) {
	// Creates a new string list element by mallocating momory
	// and initializes the members of the new element by 
	// calling  strlist_IniElem.
	//
	// NOTE: The new element is not inserted into a StringList !!
	//       
	size_t	mem_size;
	int err; 
	*E = -1;  // raise ERROR flag
	
	mem_size = sizeof(TStrListElem);
	
	//if( *StrListElem == NULL ) {
		
		*StrListElem = (TpointerStrListElem) malloc(mem_size);
		
		if( *StrListElem != NULL ) {
			
			(*StrListElem)->next = NULL; 
			(*StrListElem)->prev = NULL;
			(*StrListElem)->str = NULL;  
			
			strlist_IniElem( StrListElem, &err );
			
			if( !err ) {
				 *E = 0;  // incidcate SUCCESS
			}	 
		}	
	//}
	
	return(*E);	
} // strlist_CreateElemt


static int
strlist_IniElem (TpointerStrListElem  *StrListElem, int *E) {
	// 	
	*E = -1;  // raise ERROR flag
				
	if( *StrListElem != NULL ) {		
		// A T T E N T I O N : THIS DISCONNECTS A LINKED ELEMENT FROM ITS LIST !!
		// KEEP IN MIND :  THIS DOES NOT FREE ALOCATED MEMORY !
		(*StrListElem)->next = NULL;  
		(*StrListElem)->prev = NULL;
		
		// Reset element data fields
		(*StrListElem)->index = -1;		
		(*StrListElem)->sz = (long long)0;  // -> zero-size		
		(*StrListElem)->d = 0;	  // -> no-dir	
		str_ini( &((*StrListElem)->str) );  // resets or creates str as an empty string (just \0)		
		
		*E = 0;  // incidcate SUCCESS
	}	
	
	return(*E);	
} // IniStrListElem


static int
strlist_DestroyElem (TpointerStrListElem  *StrListElem, int *E) {
		
	*E = -1;  // raise ERROR flag
	
	if( StrListElem != NULL ) {
		
		// Free meomory for string data
		if ( (*StrListElem)->str != NULL ) {
			free( (*StrListElem)->str );
			(*StrListElem)->str = NULL;
		}	  
		
		// Now free the complete element and set pointer to NULL
		free( *StrListElem );
		*StrListElem = NULL;
		
		*E = 0;  // incidcate SUCCESS
	}
	
	return(*E);	
} // strlist_DestroyElem


static TpointerStrListElem
strlist_seek_forward (TpointerStringList  *StringList,  TpointerStrListElem  StrListElem,  long index) {
	
	TpointerStrListElem		Elem_k;
	long k;
	
	StrListElem = NULL;  // indicate ERROR 
	
	if( *StringList != NULL ) {
		// seek list forward for element at index 'position'
		k = 0;    Elem_k = (*StringList)->StrLstRoot;
		while( (k < index) &&
		       (Elem_k->next != NULL) ) {
			k++;
			Elem_k = Elem_k->next;
		}
		if( (k == index) && (Elem_k->index == index) ) {
			StrListElem = Elem_k;  // SUCCESS
		}else{	
			StrListElem = NULL;  // ERROR --> no element with specified index found
			                      // unexpected end of list or discontinous indices
		}	
	}    
    return(StrListElem);
} // strlist_seek_forward
			

//static TpointerStrListElem
//strlist_seek_backward (TpointerStringList  *StringList,  TpointerStrListElem  StrListElem,  long index) {
//	
//	TpointerStrListElem		Elem_k;
//	long k;
//	
//	StrListElem = NULL;  // indicate ERROR 
//	
//	if( *StringList != NULL ) {
//		// seek list forward for element at index 'position'
//		k = (*StringList)->Count - 1;    Elem_k = (*StringList)->StrLstEnd;
//		while( (k > index) &&
//		       (Elem_k->prev != NULL) ) {
//			k--;
//			Elem_k = Elem_k->prev;
//		}
//		if( (k == index) && (Elem_k->index == index) ) {
//			StrListElem = Elem_k;  // SUCCESS
//		}else{	
//			StrListElem = NULL;  // ERROR --> no element with specified index found
//		}	
//	}    
//    return(StrListElem);
//} // strlist_seek_backward


static char*
DEBUG_InsString(char* TEXT , TpointerStringList  *StringList,  TpointerStrListElem  StrListElem,  long position) {
	
	char* SOUT = NULL;
	
	int e;
	char* S = NULL;   str_Nini(&S, 1000); // allocate memory for help string S and initialize it
	
			sprintf(S, "\n %s\n", TEXT);                     str_copy( &SOUT, S, &e );
		   	sprintf(S, "   StrListElem = %p\n", StrListElem);   str_catenate( &SOUT, S, &e );
		   	if( StrListElem != NULL) {
		    	sprintf(S, "   StrListElem->next = %p\n", StrListElem->next);   str_catenate( &SOUT, S, &e );
		    	sprintf(S, "   StrListElem->prev = %p\n", StrListElem->prev);   str_catenate( &SOUT, S, &e );
		    	if( StrListElem->prev != NULL) { // should normally equal StrListElem
			    	sprintf(S, "   PreviousElm->next  = %p\n", StrListElem->prev->next);   str_catenate( &SOUT, S, &e );
		    	}else{
			    	sprintf(S, "   PreviousElm->next  = N.A\n");                            str_catenate( &SOUT, S, &e );
		    	}		
		    	if( StrListElem->next != NULL) { // should normally equal StrListElem
			    	sprintf(S, "   FollowingElm->prev = %p\n", StrListElem->next->prev);   str_catenate( &SOUT, S, &e );						    		
		    	}else{
			    	sprintf(S, "   FollowingElm->prev = N.A\n");                            str_catenate( &SOUT, S, &e );
		    	}		
		   	}else{
		    	sprintf(S, "   StrListElem->next = N.A.\n");     str_catenate( &SOUT, S, &e );
		    	sprintf(S, "   StrListElem->prev = N.A.\n");     str_catenate( &SOUT, S, &e );
		    	sprintf(S, "   PreviousElm->next  = N.A\n");   str_catenate( &SOUT, S, &e );
		    	sprintf(S, "   FollowingElm->prev = N.A\n");   str_catenate( &SOUT, S, &e );
		   	}

		   	sprintf(S, "   StringList = %p\n", *StringList);   str_catenate( &SOUT, S, &e );						   			
		   	if( *StringList != NULL) {
		    	sprintf(S, "   StringList->StrLstRoot = %p\n", (*StringList)->StrLstRoot);               str_catenate( &SOUT, S, &e );
			   	if( (*StringList)->StrLstRoot != NULL) {
				   	sprintf(S, "   StringList->StrLstRoot->next = %p\n", (*StringList)->StrLstRoot->next);   str_catenate( &SOUT, S, &e );
				   	sprintf(S, "   StringList->StrLstRoot->prev = %p\n", (*StringList)->StrLstRoot->prev);   str_catenate( &SOUT, S, &e );
			   	}else{
				   	sprintf(S, "   StringList->StrLstRoot->next = N.A.\n");   str_catenate( &SOUT, S, &e );
				   	sprintf(S, "   StringList->StrLstRoot->prev = N.A.\n");   str_catenate( &SOUT, S, &e );
			   	}		
		    	sprintf(S, "   StringList->StrLstEnd = %p\n", (*StringList)->StrLstEnd);                   str_catenate( &SOUT, S, &e );
			   	if( (*StringList)->StrLstEnd != NULL) {
				   	sprintf(S, "   StringList->StrLstEnd->next = %p\n", (*StringList)->StrLstEnd->next);   str_catenate( &SOUT, S, &e );
				   	sprintf(S, "   StringList->StrLstEnd->prev = %p\n", (*StringList)->StrLstEnd->prev);   str_catenate( &SOUT, S, &e );
			   	}else{
				   	sprintf(S, "   StringList->StrLstEnd->next = N.A.\n");    str_catenate( &SOUT, S, &e );
				   	sprintf(S, "   StringList->StrLstEnd->prev = N.A.\n");    str_catenate( &SOUT, S, &e );
			   	}		
		   	}
	free(S);			   	
	return(SOUT);				   	
} // DEBUG_InsToStrList
