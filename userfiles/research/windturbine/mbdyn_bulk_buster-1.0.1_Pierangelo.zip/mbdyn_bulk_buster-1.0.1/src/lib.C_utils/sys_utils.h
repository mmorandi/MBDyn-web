/*                      Copyright  (C)  2006    Patrick Rix 
 * sys_utils.h
 * ===========
 * Header file for  sys_utils.c
 * 
 * LICENSE
 *                not yet defined
 * 
 * AUTHOR(S)
 *                Patrick Rix          e-mail: <patrick.rix@online.de>
 */
#ifndef SYS_UTILS_H_
#define SYS_UTILS_H_

#define VERSION_SYS_UTILS     "0.0.0" 
#define MODULE_SYS_UTILS     "sys_utils" 

#include "strlist.h"

////////////////////////////////////////////////////////////
// <<<  GLOBAL CONSTANTS  exported by  sys_utils.c  >>>  
////////////////////////////////////////////////////////////

//  extern const int Nmax_attr;  // = 10 --> see  sys_utils.c  
  typedef int      attr_t[10]; // attr_t[ Nmax_attr ] !
  
  
typedef unsigned char    u_char_t;
typedef unsigned short  u_short_t;
typedef unsigned int      u_int_t;
typedef unsigned long    u_long_t;
  
typedef signed char	       *char1D_t;  	typedef u_char_t   *u_char1D_t;
typedef signed short      *short1D_t;  	typedef u_short_t  *u_short1D_t;
typedef signed int          *int1D_t;  	typedef u_int_t    *u_int1D_t;
typedef signed long        *long1D_t;  	typedef u_long_t   *u_long1D_t;
typedef float	 	      *float1D_t;  
typedef double     	     *double1D_t;
typedef long double *long_double1D_t;

typedef signed char        **char2D_t;  	typedef u_char_t    **u_char2D_t;
typedef signed short      **short2D_t;  	typedef u_short_t   **u_short2D_t;
typedef signed int          **int2D_t;  	typedef u_int_t     **u_int2D_t;
typedef signed long        **long2D_t;  	typedef u_long_t    **u_long2D_t;
typedef float	 	      **float2D_t;  
typedef double     	     **double2D_t;
typedef long double **long_double2D_t;

typedef signed char  	       ***char3D_t;  	typedef u_char_t    ***u_char3D_t;
typedef signed short 	      ***short3D_t;  	typedef u_short_t   ***u_short3D_t;
typedef signed int   	        ***int3D_t;  	typedef u_int_t     ***u_int3D_t;
typedef signed long  	       ***long3D_t;  	typedef u_long_t    ***u_long3D_t;
typedef float	 	   		  ***float3D_t;  
typedef double     	    	 ***double3D_t;
typedef long double		***long_double3D_t;
 
  
    
////////////////////////////////////////////////////////////
// <<<  GLOBAL FUNCTIONS + MACROS exported by  sys_utils.c  >>>  
////////////////////////////////////////////////////////////

// 
#define  Xmalloc(type, num)       ((type *) x_malloc  (             (size_t)(num) * sizeof(type)))
#define  Xrealloc(type, p, num)   ((type *) x_realloc ((void *)(p), (size_t)(num) * sizeof(type)))
#define  Xcalloc(type, num)       ((type *) x_calloc  (             (size_t)(num),  sizeof(type)))
        
  extern void*   x_malloc  (size_t mem_size);
  extern void*   x_realloc (void *p, size_t mem_size);
  extern void*   x_calloc  (size_t num, size_t size);
         
         
#define  fREAD(F,  var, type, num, num_read,    E)   (x_fread(  (F),       (void *)(var),  sizeof(type),  (size_t)(num),  (size_t *)(num_read),    (E) ))
#define  fWRITE(F, var, type, num, num_written, E)   (x_fwrite( (F), (const void *)(var),  sizeof(type),  (size_t)(num),  (size_t *)(num_written), (E) ))  

  extern u_long_t  x_fread  ( FILE* F,        void* var,  size_t size,  size_t num,  size_t *NR,  int *E );
  extern u_long_t  x_fwrite ( FILE* F,  const void* var,  size_t size,  size_t num,  size_t *NW,  int *E );
  
  extern void wait ( int seconds );
  
  extern struct tm* sys_mktm			  ( int year, int month, int day, int hour, int min, int sec );
  extern struct tm* sys_difftm            ( const struct tm* timeptr_1 , const struct tm* timeptr_2 );
  extern struct tm* sys_Now               ( void );
  extern char*      sys_DateTimeToStrFmt  ( char* *s,  const char* format,  const struct tm* timeptr );
  extern char*      sys_DateTimeToStr     ( char* *s,  const struct tm* timeptr );
  extern char*      sys_DateToStr         ( char* *s,  const struct tm* timeptr );
  extern char*      sys_TimeToStr         ( char* *s,  const struct tm* timeptr );

  extern int        sys_fcopy             ( const char* source,  const char* destination );
  extern int        sys_fmove             ( const char* source,  const char* destination );
  extern int        sys_CopyFile          ( const char* source,  const char* destination );
  extern int        sys_MoveFile          ( const char* source,  const char* destination );

  extern int        sys_CopyDir           ( const char* dirname,  int recursive,  const char* destination );
  extern int        sys_MoveDir           ( const char* dirname,  int recursive,  const char* destination );
  extern int        sys_RemoveDir         ( const char* dirname,  int recursive );
  extern int        sys_RenameDir         ( const char* dirname, const char* newname );
            
  extern int        sys_mkdir             ( const char* path );  	
  extern int        sys_mkdir_forced      ( const char* path );
  extern int        sys_rmdir_forced      ( const char* path );
  extern int        sys_lsdir             ( TpointerStringList  *StringList,  const char* dirname,  int recursive );
  extern int        sys_szlsdir           ( long long *size,  TpointerStringList  *StringList,  const char* dirname,  int recursive );
   
  extern long long  sys_GetFileSize       ( const char* path );
  extern int        sys_GetDirSize        ( long long *size,  const char* dirname,  int recursive );
  extern int        sys_SearchDir         ( const char* dirname,  int recursive, 
  										    const char* pattern,  int casens,  TpointerStringList *FoundPatternList );  										    
  										    
  extern int        sys_FileSetReadOnly   ( const char* path );
  extern int        sys_FileSetReadWrite  ( const char* path );
  extern int        sys_FileSetWriteOnly  ( const char* path );
                
  extern int        sys_FileExists        ( const char* path );
  extern int        sys_DirExists         ( const char* path );
  extern int        sys_SymLnkExists      ( const char* path );  
  extern int        sys_ObjExists         ( const char* Path_fSysObj, int *is_file, int *is_dir, int *is_link );
  extern int        sys_IsRelativePath    ( const char* path );
  extern char*      sys_QueryPathDelimiter( char* *Delimiter );
  
  extern char*      sys_CygPathToWinPath  ( char* *Path );
  extern char*      sys_WinPathToCygPath  ( char* *Path );  
  
  extern char*      sys_ExpandName        ( char* *Full_Path , const char* Name_fSysObj );
  extern char*      sys_MakeAbsolute      ( char* *Path , int *E );
  
  extern char*	    sys_GetAbsolutePath   ( char* *AbsPath, const char* Name_fSysObj );  
  extern char*      sys_GetCurrDir        ( char* *s );
  
  extern int        sys_GetUID            ( const char* Path_fSysObj );
  extern int        sys_GetGID            ( const char* Path_fSysObj );
  extern void       sys_GetOwner          ( const char* Path_fSysObj, int *UID, int *GID );

//	TODO:  does not work on Windows
//	  extern int        sys_SetUID            ( const char* Path_fSysObj, int UID );    
//	  extern int        sys_SetGID            ( const char* Path_fSysObj, int GID );
//	  extern int        sys_SetOwner          ( const char* Path_fSysObj, int UID, int GID );
  
  extern struct tm* sys_GetLastModifyTime ( const char* Path_fSysObj );
  extern int        sys_SetLastModifyTime ( const char* Path_fSysObj, struct tm* timeptr );
  
  extern attr_t*    sys_GetAttributes     ( const char* Path_fSysObj );
  extern char*      sys_AttrToStr         ( char* *s,  attr_t* attributes );
        

#endif /*SYS_UTILS_H_*/
