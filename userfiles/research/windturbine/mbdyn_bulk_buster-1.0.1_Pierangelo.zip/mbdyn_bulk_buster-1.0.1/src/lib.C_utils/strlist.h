/*                      Copyright  (C)  2006    Patrick Rix 
 * strlist.h
 * ===========
 * Header file for  strlist.c
 * 
 * LICENSE
 *                not yet defined
 * 
 * AUTHOR(S)
 *                Patrick Rix          e-mail: <patrick.rix@online.de>
 */
#ifndef STRLIST_H_
#define STRLIST_H_

#define VERSION_STRLIST     "0.0.0" 
#define MODULE_STRLIST     "strlist" 

#include <stdio.h>

////////////////////////////////////////////////////////////
// <<<  GLOBAL DEFINITION OF STRUCTURES + TYPES   >>>
// <<<  exported by  strlist                      >>>  
////////////////////////////////////////////////////////////
  
typedef struct StrListElem {
	struct StrListElem	*prev, *next;
	long	index;
	char*	str;
    // additional fields intended for use in module  sys_utils.c
	long long sz;  // holds the file/dir size when used in function  sys_DirCmd()
	char d;        // holds boolean 0/1 to indicate a directory or not in fucntion  sys_DirCmd()
} TStrListElem;

typedef TStrListElem* TpointerStrListElem;


typedef struct StringList {
	FILE*	F;
	char*	FNme;
	long	Count;	
	TpointerStrListElem		StrLstRoot;	
	TpointerStrListElem		StrLstEnd;	
} TStringList;

typedef TStringList* TpointerStringList;


////////////////////////////////////////////////////////////
// <<<  GLOBAL CONSTANTS  exported by  strlist.c  >>>  
////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////
// <<<  GLOBAL FUNCTIONS + MACROS exported by  strlist.c  >>>  
////////////////////////////////////////////////////////////

  // TODO :    
  
  
  extern int   strlist_CreateStrList        (TpointerStringList  *StringList,  int *E);
  extern int   strlist_OpenStrList          (TpointerStringList  *StringList,  const char* FileName, int *E);
  extern int   strlist_ClearStrList         (TpointerStringList  *StringList,  int *E);
  extern int   strlist_CloseStrList         (TpointerStringList  *StringList,  int *E);
  extern int   strlist_DestroyStrList       (TpointerStringList  *StringList,  int *E);
  extern int   strlist_SortStrList          (TpointerStringList  *StringList,  int increasing,  int casens,  int *E);

  extern int   strlist_ReadFILE             ( FILE *F,   TpointerStringList *StringList,   int *E );
  extern int   strlist_WriteFILE            ( FILE *F,   TpointerStringList *StringList,   int *E );
  extern int   strlist_AppendToFILE         ( FILE *F,   TpointerStringList *StringList,   int *E );
  
  extern long  strlist_GetLen               (TpointerStringList  *StringList);
  extern int   strlist_AppString            (TpointerStringList  *StringList,  const char* string,  int *E);  
  extern int   strlist_InsString            (TpointerStringList  *StringList,  const char* string,  long position,  int *E);
  extern int   strlist_DelString            (TpointerStringList  *StringList,  long position,  int *E);  
  extern int   strlist_XchString            (TpointerStringList  *StringList,  long curr_index,  long new_index,  int *E);
  extern int   strlist_MovString            (TpointerStringList  *StringList,  long curr_index,  long new_index,  int *E);  
  extern int   strlist_SetString            (TpointerStringList  *StringList,  const char* string,  long index,  int *E);
  extern char* strlist_GetString            (TpointerStringList  *StringList,  char* *string,  long index,  int *E);
  extern long  strlist_IndexOf              (TpointerStringList  *StringList,  const char* string,  int reverse,  int *E);
  extern long  strlist_NextIndexOf          (TpointerStringList  *StringList,  const char* string,  long position_0,  int reverse,  int *E);
  extern int   strlist_FindFirstPattern     (TpointerStringList  *StringList,  const char* pattern,  long *LINE,  long *COLUMN,  int reverse,  int casens,  int *E);  
  extern int   strlist_FindNextPattern      (TpointerStringList  *StringList,  const char* pattern,  long line_0,  long column_0,  long *LINE,  long *COLUMN,  int reverse,  int casens,  int *E);
  extern int   strlist_BlockCopy            (TpointerStringList  *DestStrList, TpointerStringList  *SrceStrList,  long L0,  long NL,  int *E);
  extern int   strlist_BlockInsert          (TpointerStringList  *DestStrList, TpointerStringList  *StrList,  long L0,  int *E);
  extern int   strlist_BlockDelete          (TpointerStringList  *StringList,  long L0,  long NL,  int *E);
  extern int   strlist_BlockXchange         (TpointerStringList  *StringList,  long L1, long NL1,  long L2, long NL2,  int *E);
  extern int   strlist_BlockMove            (TpointerStringList  *StringList,  long L1, long NL1,  long L2,  int *E);
  extern int   strlist_BlockMoveToStrList   (TpointerStringList  *DestStrList, TpointerStringList  *SrceStrList,  long L1, long NL1,  long L2,  int *E);
  extern int   strlist_BlockCopyToStrList   (TpointerStringList  *DestStrList, TpointerStringList  *SrceStrList,  long L1, long NL1,  long L2,  int *E);
  extern int   strlist_BlockAppendToStrList (TpointerStringList  *DestStrList, TpointerStringList  *SrceStrList,  long L1, long NL1,  int *E);

  extern long  strlist_BlockReadFILE 		( FILE *F,   TpointerStringList *StringList,   
					                          long Fpos_0,  long L0,  long NL,  long MaxSize,   
                    					      long *RL,  int *E );
  extern long  strlist_BlockWriteFILE       ( FILE *F,   TpointerStringList *StringList,   
 											  long Fpos_0,  long L0,  long NL,  
                                              long *RL,  int *E );
                                              
                
              
#endif /*STRLIST_H_*/
