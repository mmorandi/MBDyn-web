/* ============================================================================
 *    Copyright   (C)   2010   Patrick Rix  -  all rights reserved.
 * ============================================================================

 Author      : Patrick Rix

 ProgName    : mbdyn_bulk_buster.c

 ProgVersion : 1.0.0

 Licence
 Disclaimer  :  		G P L - L i c e n c e d
			#  -------------------------------------------------------------------  #
			#    This program is free software; you can redistribute it and/or      #
			#    modify it under the terms of the GNU General Public License as     #
			#    published by the Free Software Foundation; either version 2 of     #
			#    the License, or (at your option) any later version.                #
			#                                                                       #
			#    This program is distributed in the hope that it will be useful,    #
			#    but WITHOUT ANY WARRANTY; without even the implied warranty of     #
			#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.               #
			#    See the GNU General Public License for more details.               #
			#                                                                       #
			#    You should have received a copy of the GNU General Public License  #
			#    along with this program; If not, you can obtain a copy of the GNU  #
			#    GPL licence at the home page of the Free Software Foundation, Inc. #
			#    at  <http://www.fsf.org/>  .                                       #
			#  -------------------------------------------------------------------  #

 Language
 Description : C, Ansi-style

 Requirements: NetCDF C-library ver. 3.6.x  or higher

                   For the development  NetCDF-4.1.1  was used but was built with

                     ./configure --enable-c-only  --disable-netcdf-4  --disable-dap

                   what results in a fallback to the NetCDF-3 API.
                   (..anyway I used only the very basic features of the NetCDF library.)

 Development
 Environment : Machine: Intel Core2 Quad CPU Q9300 @ 2.5GHz , 3.25GB RAM
               Plattform: Windows XP + Cygwin(1.7.0),
               IDE-Tools: Eclipse-3.5.2(Galileo) + CDT-6.0.2 plugin for C/C++ development
               Compiler:  GCC-4.3.4(from Cygwin)
               Debugger:  GDB-6.8.0(from Cygwin)

 Testing &
 Performance : On the machine above ver. 1.0.0 of mbdyn_bulk_buster succeeded in splitting
               an MBDyn *.aer result file with 3.5GB of bulk ASCII text data, consisting of
               156 labels (i.e. data sets with up to 40 columns) with each data set having
               45079 time steps resulting in ~7.0e+06 text lines.
               1.)
               For the conversion to 1D NetCDF variables of type FLOAT the whole procedure
       :-)     took *** ~25min *** and ended up with 156 *.nc files with a total size of 1GB
               and each file having 7.2MB.
               2.)
               For the conversion to 2D NetCDF variables of type FLOAT
               into ONE MULTIVAR file the whole procedure
       :-(     took *** ~1:30min *** and ended up with one *.nc files with a total size of 1GB.
               3.)
               For the conversion to 1D NetCDF variables of type FLOAT
               into ONE MULTIVAR file the whole procedure
       :-((    took *** ~infinity *** and was aborted due to impatience... !?!
               (..for a smaller file everything went file also when having
                  several buffer fills)


 Useful Links :   REFERENCES on C-Programming
                  ===========================

               http://www.galileocomputing.de/katalog/openbook
               http://openbook.galileocomputing.de/c_von_a_bis_z/001_c_einstieg_in_c_001.htm

               http://publications.gbdirect.co.uk/c_book/

               http://www.cplusplus.com/reference/clibrary/

 ============================================================================
     <<<<<<<<<<    M O D I F I C A T I O N   H I S T O R Y    >>>>>>>>>>
 ----------------------------------------------------------------------------
   Ver.     Date      Author      Modification
 ----------------------------------------------------------------------------
  1.0.0   July 2010   P.Rix       Basic Draft with data splitting/conversion (from --> to)
                                     (MBDyn) TEXT  -->  (MBDyn) TEXT
                                     (MBDyn) TEXT  -->  binary NetCDF
 ============================================================================
 */



#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <math.h>
#include <string.h>  // for strlen(), strtok()

#include "lib.C_utils\sys_utils.h"
#include "lib.C_utils\str_utils.h"
//#include "lib.C_utils\strlist.h"

#include "netcdf\netcdf.h"




int main(int argc, char *argv[]) {


#include "mbdyn_bulk_buster.h"



time(&time1_TOTAL);

    sys_DateTimeToStr( &START_time_str,  sys_Now() );

    //..say "HELLO" to user
	printf("\n     Copyright (C)    2010    Patrick Rix  -  all rights reserved.\n\n");
	printf("  **************************************************************************** \n");
	printf("     Program      >>> %s <<<      ,      ver. %s\n", PRG_name, PRG_version);
	printf("  **************************************************************************** \n");
	printf("\n");
	printf("  This is FREE SOFTWARE and can freely be redistributed unter the terms of the\n");
	printf("        G P L - L I C E N C E .   It comes with ABSOLUTELY NO WARRANTY\n");
	printf("\n");

	//printf("..enter press return to continue..  ");   scanf("%c",&c);

	if(argc <= 1){ //..show HELP if called without any arguments

		printf("\n");
		printf("  #  -----------   L i c e n c e   &   D i s c l a i m e r   -----------  #\n");
		printf("  #    This program is free software; you can redistribute it and/or      #\n");
		printf("  #    modify it under the terms of the GNU General Public License as     #\n");
		printf("  #    published by the Free Software Foundation; either version 2 of     #\n");
		printf("  #    the License, or (at your option) any later version.                #\n");
		printf("  #                                                                       #\n");
		printf("  #    This program is distributed in the hope that it will be useful,    #\n");
		printf("  #    but WITHOUT ANY WARRANTY; without even the implied warranty of     #\n");
		printf("  #    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.               #\n");
		printf("  #    See the GNU General Public License for more details.               #\n");
		printf("  #                                                                       #\n");
		printf("  #    You should have received a copy of the GNU General Public License  #\n");
		printf("  #    along with this program; If not, you can obtain a copy of the GNU  #\n");
		printf("  #    GPL licence at the home page of the Free Software Foundation, Inc. #\n");
		printf("  #    at  <http://www.fsf.org/>  .                                       #\n");
		printf("  #  -------------------------------------------------------------------  #\n");
		printf("\n");
		printf("\n");
		printf("  PURPOSE\n");
		printf("  =======\n");
		printf("  Standard operation is to split (i.e. extract) time series data from a\n");
		printf("  (big) MBDyn bulk ascii text input file into a bunch of (smaller) files \n");
		printf("  (ASCII text or binary NetCDF format), giving one output file per each\n");
		printf("  entity (i.e. label) contained in the input file.\n");
		printf("  The output files will be named with the entity label automatically appended\n");
		printf("  as new file extension.\n");
		printf("  As alternative operation with NetCDF output enabled AND option\n");
		printf("  --netcdf-multivar-file  set, all data sets will go into one (big)\n");
		printf("  multiVAR file.\n");
		printf("  \n");
		printf("  To learn more about MBDyn and multibody dynamics and for downloading the\n");
		printf("  sortware & documentation please refer to:\n");
		printf("                              <http://www.aero.polimi.it/~mbdyn/>\n");
		printf("  To learn more about the binary NetCDF file format and for downloading the\n");
		printf("  sortware & documentation please refer to:\n");
		printf("                              <http://www.unidata.ucar.edu/software/netcdf/>\n");
		printf("  With the netcdf package included are also the two nice little helpers\n");
		printf("  called   ncdump  &  ncgen   providing ascii<->netcdf transformation.\n");
		printf("  At <http://www.unidata.ucar.edu/software/netcdf/software.html> is an\n");
		printf("  extensive list of 3rd party software as e.g. \n");
		printf("   + viewers/plotters [ncBrowse(a Java-based tool for Linux+Windows);\n");
		printf("                       IntelArrayView;IDE;ANDX;ParaView;Visit!;...]\n");
		printf("   + file & data manipulators [ANTS;NCO;...]\n");
		printf("   + interfaces for [Python;Java;Octave;MatLab;Ruby;R;...]\n");
		printf("  just to name some of the free ones.\n");
		printf("  \n");
		printf("  \n");
		printf("  \n");
		printf("  \n");
		printf("  INPUT   Any of MBDyn's bulk data ascii text output files containing\n");
		printf("  =====   simulation time series normally of several entities,\n");
		printf("          e.g.:  *.mov, *.jnt, *.ine, *aer, *.act, etc.\n");
		printf("  \n");
		printf("  OUTPUT  Several (singleVAR) files (ASCII text or binary NetCDF\n");
		printf("  ======  format) with the data of each entity separated into its own\n");
		printf("          file with the entity label as file extension with one \n");
		printf("          EXCEPTION: \n");
		printf("          with NetCDF output enabled AND option  --netcdf-multivar-file  set,\n");
		printf("          all data sets will go into one (big) multiVAR file.\n");
		printf("          If no output path & file basename have been specified the input\n");
		printf("          file name will be taken as outfile basename with all files being\n");
		printf("          created in the same directory as where the input file is located.\n");
		printf("  \n");
		printf("  \n");
		printf("  USAGE\n");
		printf("  =====\n");
		printf("  \n");
		printf("       %s  [OPTIONS]  <bulk_data_infile>  [outfile_basename]\n",PRG_name);
		printf("  \n");
		printf("  \n");
		printf("  <bulk_data_infile>  path & filename of the bulk data input file, i.e.\n");
		printf("                      any of MBDyn's text ouput files with extensions\n");
		printf("                      *.mov,*.jnt,*.ine,*.act,*.aer,... etc.   \n");
		printf("  \n");
		printf("  [outfile_basename]  optional path & file BASE(!)name for various entity\n");
		printf("                      specific output files with the entity label as file.\n");
		printf("                      extension.\n");
		printf("  \n");
		printf("  OPTIONS\n");
		printf("  =======\n");
		printf("  \n");
		printf("  --set-NLbuff=####  sets the number of lines read from input file\n");
		printf("                     per each buffer filling where #### is a (large)\n");
		printf("                     positive(!) value.\n");
		printf("                     As the program heavily performs file IO operations\n");
		printf("                     it is advantegeous to set the number of buffer lines\n");
		printf("                     as high as possible to obtain a good performance.\n");
		printf("                     The max. value depends on the available momory of the\n");
		printf("                     machine. \n");
		printf("                     Unless another value was specified a default value of\n");
		printf("                       %ld  lines will be taken.\n",Dflt_NL_buff);
		printf("  \n");
		printf("  \n");
		printf("  --skip-label       prevents the label to appear unnecessarily as a column\n");
		printf("                     of its own. The label information is captured in the\n");
		printf("                     file extension which should be sufficient.\n");
		printf("                     This option is mainly intended for saving some disk space.\n");
		printf("  \n");
		printf("  \n");
		printf("  --add-time[=\"timefile.out\"]\n");
		printf("                     adds the simulation time track from MBDyn's *.out file as\n");
		printf("                     1st column to each label output file.\n");
		printf("                     Per default the corresponding time file is assumed to be\n");
		printf("                     in the same directory as of the input file and having the\n");
		printf("                     same file name as the input file except for the extension.\n");
		printf("                     Optionally a special time track file can be explicitly\n");
		printf("                     specified.\n");
		printf("  \n");
		printf("  \n");
		printf("  --netcdf-1D-float\n");
		printf("  --netcdf-1D-double\n");
		printf("  --netcdf-2D-float\n");
		printf("  --netcdf-2D-double\n");
		printf("                     writes the simulation time series data in binary(!) NetCDF\n");
		printf("                     format as either\n");
		printf("                     1D NetCDF variables, i.e. each data column of an entity\n");
		printf("                        (e.g. a node, force, etc.) in an MBDyn output file\n");
		printf("                        becomes a NetCDF variable with time as the only\n");
		printf("                        dimension   OR\n");
		printf("                     2D NetCDF variables, i.e. all data columns of an entity\n");
		printf("                        (the whole line)in an MBDyn output file becomes a\n");
		printf("                        NetCDF variable with time as the 1st dimension and the\n");
		printf("                        column index as 2nd dimension.\n");
		printf("                     Numbers will be written as 4-byte FLOAT or 8-byte DOUBLE.\n");
		printf("                     As usually time series data are interested to be displayed\n");
		printf("                     over time the  --add-time  option should be given to have\n");
		printf("                     the information of the simulation time additionally\n");
		printf("                     available in the NetCDF file.\n");
		printf("                     It's supposed to also use  --skip-label  to suppress the\n");
		printf("                     output of the label column into the binary file as this\n");
		printf("                     would not add any useful information but only eating up\n");
		printf("                     disk space.\n");
		printf("                     \n");
		printf("  --netcdf-multivar-file\n");
		printf("                     additional flag which can be set in conjunction to one of\n");
		printf("                     the 4 flags above --netcdf-[1|2]D-[float|double] to control\n");
		printf("                     the number of created *.nc output files.\n");
		printf("                     If the flag is set by using this option ALL data sets of the\n");
		printf("                     input file will go into ONE *.nc output file.\n");
		printf("  \n");
		printf("  \n");
		printf("  EXAMPLES\n");
		printf("  ========\n");
		printf("  \n");
		printf("    %s --set-NLbuff=1000000  \\ \n",PRG_name);
		printf("                         ./rigidpendulum.mov  ./data/rigipendulum.mov\n");
		printf("  \n");
		printf("        sets the number of lines read per each buffer filling to\n");
		printf("        max. 1 million lines and\n");
		printf("        results in   A S C I I   T E X T  files (in MBDyn format),\n");
		printf("        e.g.: n");
		printf("                    ./data/rigidpenulum.mov.1000\n");
		printf("                    ./data/rigidpenulum.mov.2000\n");
		printf("                    ./data/rigidpenulum.mov.3000\n");
		printf("                          ... \n");
		printf("  \n");
		printf("  \n");
		printf("    %s --skip-label --add-time ./mymodel.mov ./data/mymodel.mov\n",PRG_name);
		printf("  \n");
		printf("        adds simulation time from time file  ./mymodel.out  as 1st column to\n");
		printf("        each output file and suppresses the output of the label column in all\n");
		printf("        output files.\n");
		printf("  \n");
		printf("  \n");
		printf("    %s --skip-label --add-time=\"./path/to/another/timefile.out\"\\\n",PRG_name);
		printf("                         ./mymodel.mov  ./data/mymodel.mov\n");
		printf("  \n");
		printf("        same as above but reads simulation time from file\n");
		printf("        ./path/to/another/timefile.out  .\n");
		printf("  \n");
		printf("  \n");
		printf("    %s  --netcdf-1D-float  --skip-label  --add-time  \\\n",PRG_name);
		printf("                         ./mymodel.mov ./data/mymodel.mov\n");
		printf("  \n");
		printf("        results in   b i n a r y   NetCDF files,\n");
		printf("        e.g.:\n");
		printf("                    ./data/mymodel.mov.1000.nc\n");
		printf("                    ./data/mymodel.mov.2000.nc\n");
		printf("                    ./data/mymodel.mov.3000.nc\n");
		printf("                          ... \n");
		printf("        with 1D-variables (i.e. with time as only dimension)\n");
		printf("        of type FLOAT.\n");
		printf("        To each *.nc output file the simulation time will be added from\n");
		printf("        the (default) time file   ./mymodel.out   and the output of the\n");
		printf("        label column will be suppressed\n");
		printf("        Having all three options together is supposed to be the standard\n");
		printf("        or usual case when converting to NetCDF format, i.e.\n");
		printf("        one of the --netcdf options plus --skip-label and and --add-time.\n");
		printf("  \n");
		printf("  \n");
		printf("    %s  --netcdf-multivar-file  --netcdf-2D-float  \\\n",PRG_name);
		printf("                         --skip-label  --add-time  \\\n");
		printf("                         ./mymodel.mov ./data/mymodel.mov\n");
		printf("  \n");
		printf("        results in ONE   b i n a r y   NetCDF file,\n");
		printf("        e.g.:\n");
		printf("                    ./data/mymodel.mov.nc\n");
		printf("                             \n");
		printf("        with 2D-variables of type FLOAT\n");
		printf("        Again as above with the simulation time added from the (default)\n");
		printf("        time file   ./mymodel.out   and with the output of the label\n");
		printf("        column suppressed\n");
		printf("\n");
		printf("\n");

		return EXIT_FAILURE;

	}else{ // argc > 1

		//..get COMMAND LINE ARGS
		for(i=1;i<argc;i++){

				  if( 0 <= str_pos(argv[i], str_OPTION_SkipLabel ,0,1)){

						printf("          OPTION  = \"%s\"\n", str_OPTION_SkipLabel);

						HAVE_OPTION_SkipLabel = 1;		OPTION = OPTION_SkipLabel;

			}else{if( 0 <= str_pos(argv[i], str_OPTION_AddTime ,0,1) ){

						printf("          OPTION  = \"%s\"\n", str_OPTION_AddTime);

						HAVE_OPTION_AddTime   = 1;		OPTION = OPTION_AddTime;

						p = str_pos(argv[i], "=" ,0,1);    L = str_len(argv[i]);
						if( 0 <= p ){
							time_filename = str_Ncpy(argv[i],  p+1, L-p);
							str_trimStr( &time_filename, &E );
							str_replaceStr( &time_filename, ALL , DQ, "", 0,0, &E ); // remove double quotes
							str_replaceStr( &time_filename, ALL , SQ, "", 0,0, &E ); // remove single quotes
						}
			}else{if( 0 <= str_pos(argv[i], str_OPTION_SetNLbuff ,0,1) ){

						printf("          OPTION  = \"%s\"\n", str_OPTION_SetNLbuff);

						HAVE_OPTION_SetNLbuff   = 1;		OPTION = OPTION_SetNLbuff;

						p = str_pos(argv[i], "=" ,0,1);    L = str_len(argv[i]);
						if( 0 <= p ){
							s1 = str_Ncpy(argv[i],  p+1, L-p);
							str_trimStr( &s1, &E );

							NL_buff = str_toLong( s1 , &E);

							if(E){
								printf("\n\n");
								printf("     !!! ERROR : invalid number for NL_buff :\n");
								printf("\n");
								printf("           -->   NL_buff = \"%s\" ?!\n", s1);
								printf("\n\n");

								return EXIT_FAILURE;
							}
							if(NL_buff <= 0){
								printf("\n\n");
								printf("     !!! ERROR : set  NL_buff > 0  !!! :\n");
								printf("\n\n");

								return EXIT_FAILURE;
							}
						}
			}else{if( 0 <= str_pos(argv[i], str_OPTION_NetCDF_1D_float ,0,1) ){
						printf("          OPTION  = \"%s\"\n", str_OPTION_NetCDF_1D_float);
						HAVE_OPTION_NetCDF = 1;
						HAVE_OPTION_NetCDF_1D = 1;
						HAVE_OPTION_NetCDF_1D_float = 1;	entity_TYPE_str = "float";
			}else{if( 0 <= str_pos(argv[i], str_OPTION_NetCDF_1D_double ,0,1) ){
						printf("          OPTION  = \"%s\"\n", str_OPTION_NetCDF_1D_double);
						HAVE_OPTION_NetCDF = 1;
						HAVE_OPTION_NetCDF_1D = 1;
						HAVE_OPTION_NetCDF_1D_double = 1;	entity_TYPE_str = "double";
			}else{if( 0 <= str_pos(argv[i], str_OPTION_NetCDF_2D_float ,0,1) ){
						printf("          OPTION  = \"%s\"\n", str_OPTION_NetCDF_2D_float);
						HAVE_OPTION_NetCDF = 1;
						HAVE_OPTION_NetCDF_2D_float = 1;	entity_TYPE_str = "float";
			}else{if( 0 <= str_pos(argv[i], str_OPTION_NetCDF_2D_double ,0,1) ){
						printf("          OPTION  = \"%s\"\n", str_OPTION_NetCDF_2D_double);
						HAVE_OPTION_NetCDF = 1;
						HAVE_OPTION_NetCDF_2D_double = 1;	entity_TYPE_str = "double";

			}else{if( 0 <= str_pos(argv[i], str_OPTION_NetCDF_multivar_file ,0,1) ){
						printf("          OPTION  = \"%s\"\n", str_OPTION_NetCDF_multivar_file);

						HAVE_OPTION_NetCDF_multivar_file = 1;

				// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
			}else{if( str_len(input_filename) > 0 ){ // get an optional output basename AFTER(!) an input filename was given

						output_basename = str_cpy( argv[i] ); // override default if an output basename was specified
			}else{
						input_filename  = str_cpy( argv[i] );  // get the INPUT FILE NAME
						output_basename = str_cpy( input_filename ); // default: initially set output basename identical to input filename

			}}}}}}}}} // if..elseif..elseif..else
		} // for(i=1;i<argc;i++)

	} // if(argc <= 0)..else..


	printf("  \n");
	printf("     INPUT  FILE  = \"%s\"\n", input_filename);

	str_GetFileExtStr( &input_file_extension, input_filename, &E);

	if( HAVE_OPTION_AddTime ){
		if( time_filename == NULL ){
			time_filename = str_cpy( input_filename );
			str_ChangeFileExtStr ( &time_filename, ".out", &E);
		}
		printf("  \n");
		printf("     TIME   FILE  = \"%s\"\n", time_filename);
	}
	printf("  \n");
	printf("  \n");
	if( HAVE_OPTION_NetCDF ){
		if( HAVE_OPTION_NetCDF_multivar_file ){
			printf("     OUTPUT FILES = \"%s.nc\"\n", output_basename);
		}else{
			printf("     OUTPUT FILES = \"%s.####.nc\"\n", output_basename);
		}
	}else{
		printf("     OUTPUT FILES = \"%s.####\"\n", output_basename);
	}
	printf("  \n");
	printf("     BUFFER SIZE currently set to   NL_buff = %ld\n", NL_buff);
	printf("  \n");
	printf("  \n");


	// perfom some SANITY CHECKS (..everything there what is expected to be existing, etc. ?)
	// =========================
	if( !sys_FileExists( input_filename ) ) {
		printf("\n\n");
		printf("     !!! ERROR : input file not found :\n");
		printf("\n");
		printf("           -->   \"%s\"\n", input_filename);
		printf("\n\n");

		return EXIT_FAILURE;
	}

	sys_DateTimeToStr( &input_file_timeID_str , sys_GetLastModifyTime( input_filename ) );

	if( HAVE_OPTION_AddTime ){
		if( !sys_FileExists( time_filename ) ) {
			printf("\n\n");
			printf("     !!! ERROR : time track file not found :\n");
			printf("\n");
			printf("           -->   \"%s\"\n", time_filename);
			printf("\n\n");

			return EXIT_FAILURE;
		}
	}

	if( input_filename != output_basename ){

		out_dir = str_GetFilePath(output_basename);

		out_dir = sys_MakeAbsolute( &out_dir, &E);

		if( !sys_DirExists( out_dir ) ) {
			sys_mkdir_forced ( out_dir ); //..try to create out_dir
		}

		if( !sys_DirExists( out_dir ) ) {
			printf("\n\n");
			printf("     !!! ERROR : output directory not existing :\n");
			printf("\n");
			printf("           -->   \"%s\"\n", out_dir);
			printf("\n\n");

			return EXIT_FAILURE;
		}
	}

// ###########################################################################################
//        ..now entering the   A C T I O N   P A R T
// ###########################################################################################

	if( HAVE_OPTION_AddTime ){

		// ======================================================================
		//    reading the TIME TRACK from TIME FILE (ASCII TEXT)
		// ======================================================================

		time_FILE = fopen( time_filename , "r+t" ); // open text file for reading

		if( (time_FILE == NULL) || ferror(time_FILE) ){
			printf("\n\n     !!! ERROR : could not open time track file for reading:\n\n\n");
			printf(    "           -->   \"%s\"\n", time_filename);
			return EXIT_FAILURE;
		}


		line_T = 0;
		NT_time = 0;
		while( (!feof(time_FILE))&&(!ferror(time_FILE)) ){

			line_T++;

			str_free( &line_str );    line_str = NULL;// remove old content
			str_Nini( &line_str, MAX_LINE_LENGTH );
			// READ TEXT LINE from time track input file
			// fgets reads the complete line INCLUSIVE the line feed at the end
			err = 0;
			if( !fgets( line_str , MAX_LINE_LENGTH, time_FILE ) ){ err = 1; }

			if( !feof(time_FILE) ){
				if(err){
						 printf("\n\n     !!! ERROR : could not read text line from time track file \n\n");
						 printf(    "          -->    line = %ld \n\n", line_T);
						 printf(    "          -->    line_str = %s \n\n", line_str);
						 return EXIT_FAILURE;
				}
			}

			if( !err && !ferror(time_FILE)) {
				str_trimStr( &line_str, &err); // remove the leading/trailing blanks & line feed from the string
				str_memtrim ( &line_str ); // trim memory size to current string length
				L = str_len( line_str );
			}

			// search for lines directly starting with keyword "Step" at pos.-index 0
			if( 0 == str_pos( line_str , "Step",0,1) ){

				NT_time++;

			/*
				if(iTsim_I == NULL){iTsim_I = (long*) malloc(sizeof(long) * NT_time);}
							 else{iTsim_I = (long*) realloc(iTsim_I, sizeof(long) * NT_time);}
				if(iTsim_I == NULL){ printf("\n\n     !!! ERROR : could not allocate memory for time step index iTsim:\n\n\n");
					   return EXIT_FAILURE;
				}
			*/
				if(iTsim_I == NULL){iTsim_I = (int*) malloc(sizeof(int) * NT_time);}
							   else{iTsim_I = (int*) realloc(iTsim_I, sizeof(int) * NT_time);}
				if(iTsim_I == NULL){ printf("\n\n     !!! ERROR : could not allocate memory for time step index iTsim:\n\n\n");
					   return EXIT_FAILURE;
				}

				if(Tsim_X == NULL){Tsim_X = (float*) malloc(sizeof(float) * NT_time);}
							 else{Tsim_X = (float*) realloc(Tsim_X, sizeof(float) * NT_time);}
				if(Tsim_X == NULL){ printf("\n\n     !!! ERROR : could not allocate memory for time data Tsim:\n\n\n");
					   return EXIT_FAILURE;
				}

				if(dTsim_X == NULL){dTsim_X = (float*) malloc(sizeof(float) * NT_time);}
							  else{dTsim_X = (float*) realloc(dTsim_X, sizeof(float) * NT_time);}
				if(dTsim_X == NULL){ printf("\n\n     !!! ERROR : could not allocate memory for time data dTsim:\n\n\n");
					   return EXIT_FAILURE;
				}

				if(Time_DATA_STR == NULL){Time_DATA_STR = (char**) malloc(sizeof(char*) * NT_time);}
									 else{Time_DATA_STR = (char**) realloc(Time_DATA_STR, sizeof(char*) * NT_time);}
				if(Time_DATA_STR == NULL){ printf("\n\n     !!! ERROR : could not allocate memory for time data read buffer:\n\n\n");
					   return EXIT_FAILURE;
				}

				jT = NT_time - 1;
				Time_DATA_STR[jT] = str_cpy( line_str );

				str_free(&s0);  s0=str_cpy( line_str );

	str_free(&s1);  s1=str_cpy(s0);  str_splitC( &s1, &s0, " \t\r\n",0,0,&e1);  str_trim(&s0);
	str_free(&s2);  s2=str_cpy(s0);  str_splitC( &s2, &s0, " \t\r\n",0,0,&e2);  str_trim(&s0);
	str_free(&s3);  s3=str_cpy(s0);  str_splitC( &s3, &s0, " \t\r\n",0,0,&e3);  str_trim(&s0);
	str_free(&s4);  s4=str_cpy(s0);  str_splitC( &s4, &s0, " \t\r\n",0,0,&e4);  str_trim(&s0);

				if(!e2){ iTsim_I[jT] = str_toLong( s2 ,&e2); }
				if(!e3){  Tsim_X[jT] = str_toFlt(  s3 ,&e3); }
				if(!e4){ dTsim_X[jT] = str_toFlt(  s4 ,&e4); }

				if( e3 || e4 ){
					printf("\n\n     !!! ERROR : could not read  Tsim[] , dTsim[]  from time track file \n\n");
					printf(    "          -->    line = %ld \n\n", line_T);
					printf(    "          -->    line_str = %s \n\n", line_str);
					return EXIT_FAILURE;
				}

				if( Tsim_X[jT] < Tsim_MIN ){ Tsim_MIN = Tsim_X[jT]; }
				if( Tsim_X[jT] > Tsim_MAX ){ Tsim_MAX = Tsim_X[jT]; }

			} // if( 0 == str_pos( line_str , "Step",0,1) )

		} // while( (!feof(time_FILE))&&(!ferror(time_FILE)) )

		fclose( time_FILE );

		printf("\n  %10ld  TIME STEPS found in TIME FILE with Tsim =  %.4f sec \n", NT_time, Tsim_MAX-Tsim_MIN);

	} // if( HAVE_OPTION_AddTime )

//-----------------------------------------------------------------------------------------
LABEL_PROGRAM_RESTART : // jump mark for RESTART in case of insufficient MAX_LINE_LENGTH
//-----------------------------------------------------------------------------------------

	if( HAVE_PROGRAM_RESTART ){

		/* in case of having a RESTART the program will be reset into the initial state,
		 * i.e. we have to :
		 *		+ close the input file containing the bulk text data
		 *		+ free memory --> destroy all arrays for buffered data
		 * */

		HAVE_PROGRAM_RESTART = 0;

		if( in_FILE != NULL ){ fclose(in_FILE); }

		for(i=0;i<NL_buff;i++){ // reset the input buffer and the number of buffered time steps per label
			if( Bulk_DATA[i] != NULL ){
				free( Bulk_DATA[i] );   Bulk_DATA[i] = NULL;
			}
		}

		for(iL=0;iL<N_Labels;iL++){ // reset the output buffer and the number of buffered time steps per label

			NTbuff = Labels_NTbuff[iL];

			for(jT=0;jT<NTbuff;jT++){ // free memory

				if( HAVE_OPTION_NetCDF ){

					if( Labels_entity_VAR_id[iL] != NULL ){
						free( Labels_entity_VAR_id[iL] );	Labels_entity_VAR_id[iL] = NULL;
					}

					if( HAVE_OPTION_NetCDF_1D_float ||
						HAVE_OPTION_NetCDF_2D_float ){

						if( Labels_DATA_X[iL][jT] != NULL ){
							free( Labels_DATA_X[iL][jT] );    Labels_DATA_X[iL][jT] = NULL;
						}
					}else{	// HAVE_OPTION_NetCDF_1D_double ||
							// HAVE_OPTION_NetCDF_2D_double

						if( Labels_DATA_XX[iL][jT] != NULL ){
							free( Labels_DATA_XX[iL][jT] );    Labels_DATA_XX[iL][jT] = NULL;
						}
					}

				}else{ // Buffer for ASCII TEXT

						if( Labels_DATA_STR[iL][jT] != NULL ){
							free( Labels_DATA_STR[iL][jT] );    Labels_DATA_STR[iL][jT] = NULL;
						}
				} // if( HAVE_OPTION_NetCDF )..else..

			} // for(jT=0;jT<NTbuff;jT++)


			if( HAVE_OPTION_NetCDF ){

				if( Labels_entity_VAR_id[iL] != NULL ){
					free( Labels_entity_VAR_id[iL] );	Labels_entity_VAR_id[iL] = NULL;
				}
				if( Labels_entity_VAR_id != NULL ){
					free( Labels_entity_VAR_id );	Labels_entity_VAR_id = NULL;
				}

				if( HAVE_OPTION_NetCDF_1D_float ||
					HAVE_OPTION_NetCDF_2D_float ){

					if( Labels_DATA_X[iL] != NULL ){
						free( Labels_DATA_X[iL] );    Labels_DATA_X[iL] = NULL;
					}
					if( Labels_DATA_X != NULL ){
						free( Labels_DATA_X );    Labels_DATA_X = NULL;
					}
				}else{	// HAVE_OPTION_NetCDF_1D_double ||
						// HAVE_OPTION_NetCDF_2D_double
					if( Labels_DATA_XX[iL] != NULL ){
						free( Labels_DATA_XX[iL] );    Labels_DATA_XX[iL] = NULL;
					}
					if( Labels_DATA_XX != NULL ){
						free( Labels_DATA_XX );    Labels_DATA_XX = NULL;
					}
				}

			} // if( HAVE_OPTION_NetCDF )


			Labels_DATA_sizeNT[iL] = 0; // re-initialize the buffer array size counter for the number of possible time steps per each label to zero
			Labels_NTbuff[iL] = 0; // re-initialize number of buffered time steps per each label to zero
			Labels_NToff[iL]  = 0; // re-initialize time step offset index per each label to zero
			Labels_NCols[iL]  = 0; // re-initialize number of data columns per each label to zero

		} // for(iL=0;iL<N_Labels;iL++)

	} // if( HAVE_PROGRAM_RESTART )


	Fsize = sys_GetFileSize( input_filename );

	//create string list object, i.e allocate memory
	//strlist_CreateStrList( &strList_BulkData, &E );
	//if(E){ printf("\n\n     !!! ERROR : could not create string list:\n\n\n");
	//	   return EXIT_FAILURE;
	//}
	if(Bulk_DATA == NULL){Bulk_DATA = (char**) malloc(sizeof(char*) * NL_buff);}
			         else{Bulk_DATA = (char**) realloc(Bulk_DATA, sizeof(char*) * NL_buff);}
	if(Bulk_DATA == NULL){ printf("\n\n     !!! ERROR : could not allocate memory for bulk data read buffer:\n\n\n");
		   return EXIT_FAILURE;
	}
	for(i=0;i<NL_buff;i++){ Bulk_DATA[i] = NULL; }


	// open the input file
	//strlist_OpenStrList( &strList_BulkData, input_filename, &E );
	//if(E){ printf("\n\n     !!! ERROR : could not open input file for reading string list:\n\n\n");
	//       printf(    "           -->   \"%s\"\n", input_filename);
	//	   return EXIT_FAILURE;
	//}

	in_FILE = fopen( input_filename , "r+t" ); // open text file for reading

	if( (in_FILE == NULL) || ferror(in_FILE) ){
		printf("\n\n     !!! ERROR : could not open input file for reading:\n\n\n");
		printf(    "           -->   \"%s\"\n", input_filename);
		return EXIT_FAILURE;
	}

	progress = 0;  old_progress = 0;
    buffer = 0;
    // current line indices (counting from 1);
	line_I = 0; // indicates the current position when READING the input file
	line_O = 0; // indicates the current position when WRITING the output file
	L_MAX_LEN = 0; // max. line length actually found
	Fpos = 0;   L0=0;   MaxSize=-1;   RL=NL_buff;   FIRST_BUFF=1;   SHOW_LABEL_MSG=1;

	while( (RL == NL_buff)&&(!feof(in_FILE)) ){ // LOOP OVER BUFFER FILLINGS

		buffer++; // counter for number of buffer fillings

		X=Fpos; Y=Fsize;   if( Y != 0){ Z = X/Y * 100.; }else{ Z =.0; }
		progress = round(Z);
		if( progress != old_progress ){
			printf("   %3i %s completed \n", progress, "%");
			old_progress = progress;
		}

	/*
		// remove old content from previous buffer filling, but do not close string list.
		strlist_ClearStrList( &strList_BulkData, &E );

		// fill buffer string list 'strList_BulkData' with next 'NL_buff' lines from
		// bulk data text input file
		Fpos = strlist_BlockReadFILE ( (*strList_BulkData).F,   &strList_BulkData,
										 Fpos,  L0, NL_buff, MaxSize,
										 &RL, &E );
		// #######################################################
		// !!!   IMPORTANT  NOTE  -->  R E S T R I C I T I O N    !!!
		// !!!   The function strlist_BlockReadFILE() only works reliably for files with a   MAXIMUM FILE SIZE  <=  2 GB   !!!
		// !!!   due to the limited number range of data type "long"  in functions fseek() and fSeekLine()  !!!
		// #######################################################

		Len_strList = strlist_GetLen( &strList_BulkData );

		if( RL != Len_strList ){
			// Normally the number of lines read from file in 'RL' and
			// the number of strings in 'strList_BulkData' (i.e. its length)
			// should be identical, so we should never come here.
			printf("\n\n     !!! ERROR : mismatching number of text lines read from file \n");
			printf(    "                 and length of buffer string list ?! \n\n");
			printf(    "                           RL = %ld\n", RL );
			printf(    "     Length(strList_BulkData) = %ld\n", Len_strList );

			return EXIT_FAILURE;
		}
	*/

		// ===============================================================
		//    R E A D I N G : FILL TEXT INPUT BUFFER ARRAY  Bulk_DATA[]
		// ===============================================================

time(&time1_READING);

		RL = 0;
		while( (RL < NL_buff)&&(!feof(in_FILE))&&(!ferror(in_FILE)) ){

			line_I++;
			RL++; // increase counter for lines read into buffer
			i = RL - 1;

		/*
			str_free( &line_str ); // remove old content
			err = str_Nini( &line_str, MAX_LINE_LENGTH+1 ); // get memory and initialize it with blanks
			// fgets reads the complete line INCLUSIVE the line feed at the end
			if( !fgets( line_str , MAX_LINE_LENGTH, in_FILE ) ) err = 1;
		*/
			if( Bulk_DATA[i] != NULL ){ free( Bulk_DATA[i]); Bulk_DATA[i]=NULL; }
			if( Bulk_DATA[i] == NULL ){Bulk_DATA[i] = (char*) malloc(sizeof(char) * (MAX_LINE_LENGTH+1));}
								  else{Bulk_DATA[i] = (char*) realloc(Bulk_DATA[i], sizeof(char) * (MAX_LINE_LENGTH+1));}
			for(j=0;j<(MAX_LINE_LENGTH+1);j++){
				Bulk_DATA[i][j] = '\0'; // initialize each with zeros
			}

			// READ TEXT LINE from input file  -->  setting of MAX_LINE_LENGTH is important: must be larger than longest text line !!
			// fgets reads the complete line INCLUSIVE the line feed at the end
			err = 0;
			if( !fgets( Bulk_DATA[i] , MAX_LINE_LENGTH, in_FILE ) ){ err = 1; }

			if( !feof(in_FILE) ){
				if(err){
						 printf("\n\n     !!! ERROR : could not read text line from input file \n\n");
						 printf(    "          -->    line = %ld \n\n", line_I);
						 printf(    "          -->    line_str = %s \n\n", Bulk_DATA[i]);
						 return EXIT_FAILURE;
				}

			/*	L = str_len( line_str );
				Fpos = Fpos + L;

				if( !err && !ferror(in_FILE)) {
					str_removeLF( &line_str, &err ); // remove the trailing line feed from the string
					L = str_len( line_str );
				}
				Bulk_DATA[iL] = str_cpy( line_str ); // put actual text line to buffer
			*/

				L = str_len( Bulk_DATA[i] );    if( L > L_MAX_LEN ){ L_MAX_LEN = L; }// max line length found
				Fpos = Fpos + L;
				if( L > 0 ){ LastCharacter = Bulk_DATA[i][L-1]; }else{ LastCharacter = '\0'; }

  //##################################################################################################
  //   CHECK if MAX_LINE_LENGTH was large enough to read the whole line, otherwise RESTART the program
if( (MAX_LINE_LENGTH <= L_MAX_LEN+1)&&(LastCharacter != '\n') ){

	MAX_LINE_LENGTH = 2 * MAX_LINE_LENGTH;

	printf("\n\n     !!! MESSAGE : insufficient MAX_LINE_LENGTH used in function fgets() !!!\n");
	printf(    "                   new maximum line length will be increased to \n");
	printf(  "\n             -->   MAX_LINE_LENGTH = %ld \n", MAX_LINE_LENGTH);
	printf(  "\n           ..now   R E S T A R T I N G   the program. \n\n");

	HAVE_PROGRAM_RESTART = 1;

	goto LABEL_PROGRAM_RESTART;
} //##################################################################################################

				if( !err && !ferror(in_FILE)) {
					str_removeLF( &Bulk_DATA[i], &err ); // remove the trailing line feed from the string
					str_memtrim ( &Bulk_DATA[i] ); // trim memory size to current string length
					L = str_len( Bulk_DATA[i] );
				}
			} // if( !feof(in_FILE) )

		} // while( (RL < NL_buff)&&(!feof(in_FILE))&&(!ferror(in_FILE)) )

time(&time2_READING);
time12_READING = difftime(time2_READING , time1_READING);
// ..show reading time below
//printf("                ..reading done in %2ld sec\n", time12_READING);



time(&time1_SORTING);

		for(i=0;i<RL;i++) { // LOOP OVER BUFFERED LINES

			line_O++; // current line index (absolute!) counting from 1

			//free( line_str ); line_str=NULL;
			str_free( &line_str );

			line_str = str_cpy( Bulk_DATA[i] );
			//strlist_GetString( &strList_BulkData , &line_str, i, &E);

			if( str_len( line_str ) > 0 ){ // IF  line_str  NOT EMPTY

				str_free( &data_str );
				data_str = str_cpy( line_str ); /* per default take the whole line as data string
												 * unless OPTION_SkipLabel was specified !
												 * (see next lines below)
												 */

				label=-1;
				str_free( &s1 );   s1=str_cpy(line_str);   str_trimStr(&s1, &E);
				str_free( &s2 );
				str_free( &label_str );
				// cut away the label ID from the string and save the rest of the text line in s2
				str_splitC( &s1, &s2, " ", 0, 0, &E);

				if( HAVE_OPTION_SkipLabel ){
					str_free( &data_str );   str_trimStr(&s2, &E);

					data_str = str_cpy(s2); // OPTION_SkipLabel !!
				}

				label_str = str_cpy(s1);
				if(!E){ label = str_toLong( label_str, &E); }
				if(E){ printf("\n\n     !!! ERROR : could not read label from line  %ld \n", line_O);
					   printf(    "          -->    line_str = %s \n\n", line_str);
					   return EXIT_FAILURE;
				}


				// check: do we have found a NEW LABEL ?
				IS_IN_LABELS = 0; // false
				if( N_Labels > 0 ){
					for(j=0;j<N_Labels;j++){
						if( label == Labels[j] ){
							iL = j; // save index, i.e. position of label in array Labels[]
							IS_IN_LABELS = 1; // set flag true
							break; // exit for loop
						}
					}
				}


				if( !(IS_IN_LABELS) ){

					/* if the current label is not in array Labels[0..N_Labels-1] this means we found a NEW LABEL (entity) and..
					 * ..now we have to :
					 *     + save NEW LABEL
					 *     + prepare arrays, (i.e. allocate memory and create a new entry in arrays: Labels[] , Labels_NTbuff[] , Labels_DATA[], etc.) */

					N_Labels++;

					iL = N_Labels - 1;

					if(Labels == NULL){Labels = (long*) malloc(sizeof(label) * N_Labels);}
								  else{Labels = (long*) realloc(Labels, sizeof(label) * N_Labels);}

					Labels[iL] = label; // save new label in list


					if(Labels_NTbuff == NULL){Labels_NTbuff = (long*) malloc(sizeof(long) * N_Labels);}
										 else{Labels_NTbuff = (long*) realloc(Labels_NTbuff, sizeof(long) * N_Labels);}

					Labels_NTbuff[iL] = 0; // initialize number of buffered time steps per each label to zero


					if(Labels_NToff == NULL){Labels_NToff = (long*) malloc(sizeof(long) * N_Labels);}
										else{Labels_NToff = (long*) realloc(Labels_NToff, sizeof(long) * N_Labels);}

					Labels_NToff[iL] = 0; // initialize time step offset index per each label to zero


					if(Labels_NCols == NULL){Labels_NCols = (long*) malloc(sizeof(long) * N_Labels);}
										else{Labels_NCols = (long*) realloc(Labels_NCols, sizeof(long) * N_Labels);}
					Labels_NCols[iL] = 0; // initialize time step offset index per each label to zero

					str_free( &s1 );   s1=str_cpy(data_str);
					str_free( &s2 );
					s2 = (char*)strtok (s1," \t");
					while (s2 != NULL){

						Labels_NCols[iL]++;   // count number of columns per each label

					    //printf ("%s\n",s2);
					    s2 = (char*)strtok (NULL, " \t");
					}
		//printf ("Labels[iL=%ld] = %ld   ,   Labels_NCols[iL=%ld] = %ld\n", iL,Labels[iL], iL,Labels_NCols[iL]);


					if( HAVE_OPTION_NetCDF ){
						// ..a 1D-array for the DIM-ids should be sufficient with its index running over the labels;
						// When writing 1D-NetCDF vars - which are only time-dependent(!) - a 2nd index counting over the data columns
						// of a label is not required as a 1D variable simply has no 2nd dimension (or implicitly equals 1).
						// When writing 2D-NetCDF vars we simply have to remember one dim-value
						if(Labels_entity_DIM_id == NULL){Labels_entity_DIM_id = (int*) malloc(sizeof(int) * N_Labels);}
													else{Labels_entity_DIM_id = (int*) realloc(Labels_entity_DIM_id, sizeof(int) * N_Labels);}
						if(Labels_entity_DIM_id == NULL){ printf("\n\n     !!! ERROR : could not allocate memory for entity variable IDs:\n\n\n");
							   return EXIT_FAILURE;
						}
						Labels_entity_DIM_id[iL] = -1;

						// ..we need a 2D-array for the VAR-ids as the 1st index runs over the labels
						// and the 2nd index runs over the data columns of a label when writing 1D-NetCDF vars (which are only time-dependent)
						if(Labels_entity_VAR_id == NULL){Labels_entity_VAR_id = (int**) malloc(sizeof(int) * N_Labels);}
													else{Labels_entity_VAR_id = (int**) realloc(Labels_entity_VAR_id, sizeof(int) * N_Labels);}
						if(Labels_entity_VAR_id == NULL){ printf("\n\n     !!! ERROR : could not allocate memory for entity variable IDs:\n\n\n");
							   return EXIT_FAILURE;
						}
						Labels_entity_VAR_id[iL] = NULL;

						if( HAVE_OPTION_NetCDF_1D_float ||
							HAVE_OPTION_NetCDF_2D_float ){

							if(Labels_DATA_X == NULL){Labels_DATA_X = (float***) malloc(sizeof(float**) * N_Labels);}
												 else{Labels_DATA_X = (float***) realloc(Labels_DATA_X, sizeof(float**) * N_Labels);}
							   Labels_DATA_X[iL] = NULL; // initialize pointer

						}else{	// HAVE_OPTION_NetCDF_1D_double ||
								// HAVE_OPTION_NetCDF_2D_double

							if(Labels_DATA_XX == NULL){Labels_DATA_XX = (double***) malloc(sizeof(double**) * N_Labels);}
												  else{Labels_DATA_XX = (double***) realloc(Labels_DATA_XX, sizeof(double**) * N_Labels);}
							   Labels_DATA_XX[iL] = NULL; // initialize pointer
						}

					}else{ // case: ASCII text output

						if(Labels_DATA_STR == NULL){Labels_DATA_STR = (char***) malloc(sizeof(char**) * N_Labels);}
											   else{Labels_DATA_STR = (char***) realloc(Labels_DATA_STR, sizeof(char**) * N_Labels);}

						Labels_DATA_STR[iL] = NULL; // initialize pointer
					}

					if(Labels_DATA_sizeNT == NULL){Labels_DATA_sizeNT = (long*) malloc(sizeof(long) * N_Labels);}
											  else{Labels_DATA_sizeNT = (long*) realloc(Labels_DATA_sizeNT, sizeof(long) * N_Labels);}

					Labels_DATA_sizeNT[iL] = 0;

				}else{ // case: label is already in label list Labels[]
					if( SHOW_LABEL_MSG ){ // as soon as the first time steps has been finished
						// show info message
						printf("\n  %10ld  LABELS DATA SETS found in INPUT FILE \n\n", N_Labels);
						SHOW_LABEL_MSG = 0;
					}
				} // if( !(IS_IN_LABELS) )..else..


				Labels_NTbuff[iL]++; // count number of buffered time steps per each label;

				NCols = Labels_NCols[iL];    // help var for less typing
				NTbuff = Labels_NTbuff[iL];  // help var for less typing
				jT = Labels_NTbuff[iL] - 1;  // help var for less typing

				sizeNT = Labels_DATA_sizeNT[iL];
				if( sizeNT < NTbuff ){ // only allocate new memory for new time step string
								       // if current memory size is too small
					if( HAVE_OPTION_NetCDF ){

						if( HAVE_OPTION_NetCDF_1D_float ||
							HAVE_OPTION_NetCDF_2D_float ){

							//============================
							//   F L O A T   DATA ARRAY
							//============================
							if(Labels_DATA_X[iL] == NULL){Labels_DATA_X[iL] = (float**) malloc(sizeof(float*) * NTbuff);}
													 else{Labels_DATA_X[iL] = (float**) realloc(Labels_DATA_X[iL], sizeof(float*) * NTbuff);}
							   Labels_DATA_X[iL][jT] = NULL; // initialize pointer

							if(Labels_DATA_X[iL][jT] == NULL){Labels_DATA_X[iL][jT] = (float*) malloc(sizeof(float) * NCols);}
														 else{Labels_DATA_X[iL][jT] = (float*) realloc(Labels_DATA_X[iL][jT], sizeof(float) * NCols);}
							for(k=0;k<NCols;k++){
							   Labels_DATA_X[iL][jT][k] = FLT_MAX; // initialize with unphysical value
							}

						}else{	// HAVE_OPTION_NetCDF_1D_double ||
								// HAVE_OPTION_NetCDF_2D_double

							//============================
							//   D O U B L E   DATA ARRAY
							//============================
							if(Labels_DATA_XX[iL] == NULL){Labels_DATA_XX[iL] = (double**) malloc(sizeof(double*) * NTbuff);}
													  else{Labels_DATA_XX[iL] = (double**) realloc(Labels_DATA_XX[iL], sizeof(double*) * NTbuff);}
							   Labels_DATA_XX[iL][jT] = NULL; // initialize pointer
							if(Labels_DATA_XX[iL][jT] == NULL){Labels_DATA_XX[iL][jT] = (double*) malloc(sizeof(double) * NCols);}
														  else{Labels_DATA_XX[iL][jT] = (double*) realloc(Labels_DATA_XX[iL][jT], sizeof(double) * NCols);}
							for(k=0;k<NCols;k++){
							   Labels_DATA_XX[iL][jT][k] = DBL_MAX; // initialize with unphysical value
							}
						}
					}else{
						//============================
						//   S T R I N G   DATA ARRAY
						//============================
						if(Labels_DATA_STR[iL] == NULL){Labels_DATA_STR[iL] = (char**) malloc(sizeof(char*) * NTbuff);}
												   else{Labels_DATA_STR[iL] = (char**) realloc(Labels_DATA_STR[iL], sizeof(char*) * NTbuff);}
						Labels_DATA_STR[iL][jT] = NULL;
					}

					Labels_DATA_sizeNT[iL] = NTbuff;
				} // if( sizeNT < NT )


				if( HAVE_OPTION_NetCDF ){

					str_free( &s1 );   s1=str_cpy(data_str);
					str_free( &s2 );
					s2 = (char*)strtok (s1," \t");
					k=-1;
					while (s2 != NULL){

						k++; // current data column index:  k = 0..NC-1;

					    //printf ("%s\n",s2);

					    if( s2 != NULL ){
							if( HAVE_OPTION_NetCDF_1D_float ||
								HAVE_OPTION_NetCDF_2D_float	){

								X = str_toFlt( s2, &E);

								if(E){ printf("\n\n     !!! ERROR : could not read float value from line  %ld \n", line_O);
									   printf(    "                        X = %s \n\n", s2);
									   printf(    "          -->    line_str = %s \n\n", line_str);
									   return EXIT_FAILURE;
								}

								if( k < NCols ){ // k < NCols = Labels_NCols[iL] = number of columns
									Labels_DATA_X[iL][jT][k] = X;
								}

							}else{	// HAVE_OPTION_NetCDF_1D_double ||
									// HAVE_OPTION_NetCDF_2D_double ||

								XX = str_toDbl( s2, &E);

								if(E){ printf("\n\n     !!! ERROR : could not read double value from line  %ld \n", line_O);
									   printf(    "                       XX = %s \n\n", s2);
									   printf(    "          -->    line_str = %s \n\n", line_str);
									   return EXIT_FAILURE;
								}

								if( k < NCols ){ // k < NCols = Labels_NCols[iL] = number of columns
									Labels_DATA_XX[iL][jT][k] = XX;
								}
							}
					    } // if( s2 != NULL )

					    s2 = (char*)strtok (NULL, " \t"); // get next sub-string (token)

					} // while (s2 != NULL)

					if( k != NCols-1 ){
						printf("\n\n     !!! ERROR : mismatching number of data columns in line  %ld \n", line_O);
						printf(    "                        k = %ld <> %ld -1 = NCols -1 \n\n", k , NCols );
						printf(    "          -->    line_str = %s \n\n", line_str);
						return EXIT_FAILURE;
					}

				}else{
					if( Labels_DATA_STR[iL][jT] != NULL ){
						// FREE OLD MEMORY allocated for strings from prev. buffer fillings
						free( Labels_DATA_STR[iL][jT] );    Labels_DATA_STR[iL][jT] = NULL;
					}

					// put data string of current time step to output buffer array
					if( HAVE_OPTION_SkipLabel ){
						Labels_DATA_STR[iL][jT] = str_cpy( data_str );
					}else{
						Labels_DATA_STR[iL][jT] = str_cpy( line_str );
					}
					// for debugging
					// printf("Labels_DATA_STR[iL=%i,jT=%i] = \"%s\"\n", iL, jT, Labels_DATA_STR[iL][jT]);

				} // if( HAVE_OPTION_NetCDF )..else..


			} // if( str_len( line_str ) > 0 ) // IF line_str NOT EMPTY

		} // for(i=0;i<RL;i++)..
		  // END LOOP OVER BUFFERED LINES

time(&time2_SORTING);
time12_SORTING = difftime(time2_SORTING , time1_SORTING);

printf("                ..reading done in %2ld sec\n", time12_READING);
printf("                ..sorting done in %2ld sec\n", time12_SORTING);

time(&time1_WRITING);

		for(iL=0;iL<N_Labels;iL++){ // LOOP OVER OUTPUT FILES

			str_free( &label_str );   str_Nini( &label_str, 50 );
			sprintf(label_str, "%ld", Labels[iL]);

			// set default TEXT output filename = basename + label extension
			output_filename = str_cat3( output_basename , "." , label_str );

			if( HAVE_OPTION_NetCDF ){

				/* ================================
				 *    N E T C D F   O U T P U T
				 * ================================ */

				if( HAVE_OPTION_NetCDF_multivar_file ){
					// set NetCDF output filename = basename + label extension + .nc
					output_filename = str_cat( output_basename , ".nc" );
				}else{
					// set NetCDF output filename = basename + label extension + .nc
					output_filename = str_cat4( output_basename , "." , label_str , ".nc" );
				}

				if( FIRST_BUFF ){
				// --------------------------------------------------------------------------------------
				//     EXECUTE THIS BLOCK ONLY   O N C E   AT THE BEGINNING OF THE 1st BUFFER FILLING
				// --------------------------------------------------------------------------------------

					EXECUTE_FOR_THIS_LABEL = 1; //DEFAULT: having (multiple) SINGLEVAR files
					zL_END=1; // default: run the zL-loops only ONCE for singlevar files..

					if( HAVE_OPTION_NetCDF_multivar_file ){	// with a MULTIVAR file override default setting
						if( iL == 0 ){
							// only true at 1st buffer (FIRST_BUFF) and 1st label (iL==0)
							EXECUTE_FOR_THIS_LABEL = 1;
						}else{
							EXECUTE_FOR_THIS_LABEL = 0;
						}

						zL_END = N_Labels; // ..run zL-loops over ALL LABELS for a multivar file
					}


					// MULTIVAR / SINGLEVAR SRTATEGY for defining dimensions, variables and attributes
					//   with one multivar file: define  ONCE  at the beginning (1st buffer, 1st label)
					//   with mulitple singlevar files: define  FOR EACH LABEL (i.e. FILE)
					if(EXECUTE_FOR_THIS_LABEL){


						/* CREATE(i.e. OVERWRITE) NetCDF output file. */
						E = nc_create( output_filename, NC_CLOBBER, &nc_FILE_id ); // with multivar file: open ONCE and leave the file open


						if(E){
							printf("\n\n");
							printf("     !!! ERROR : could not create NetCDF output file :\n");
							printf("\n");
							printf("           -->   \"%s\"\n", output_filename);
							printf("\n\n");

							if(E){ERR(E);}

							return EXIT_FAILURE;
						}


						/* ===========================
						 * DEFINE  D I M E N S I O N S
						 * =========================== */

						L_vecN = 9;
						if(vecN_DIMS_val == NULL){vecN_DIMS_val = (long*) malloc(sizeof(long) * L_vecN);}
										 else{vecN_DIMS_val = (long*) realloc(vecN_DIMS_val, sizeof(long) * L_vecN);}
						if(vecN_DIMS_id == NULL){vecN_DIMS_id = (long*) malloc(sizeof(long) * L_vecN);}
										 else{vecN_DIMS_id = (long*) realloc(vecN_DIMS_id, sizeof(long) * L_vecN);}


						// time dimension is defined to have unlimited length - it can grow as needed.
						E = nc_def_dim( nc_FILE_id, time_DIM_name, NC_UNLIMITED, &time_DIM_id);  if(E){ERR(E);}

						// defining a stockpile of dimensions (might be used for later re-grouping or splitting of data sets)
						k = 1;	E = nc_def_dim( nc_FILE_id, "vec1", k, &dummy_DIM_id);  if(E){ERR(E);}		vecN_DIMS_val[k-1] = k;		vecN_DIMS_id[k-1] = dummy_DIM_id;
						k = 2;	E = nc_def_dim( nc_FILE_id, "vec2", k, &dummy_DIM_id);  if(E){ERR(E);}		vecN_DIMS_val[k-1] = k;		vecN_DIMS_id[k-1] = dummy_DIM_id;
						k = 3;	E = nc_def_dim( nc_FILE_id, "vec3", k, &dummy_DIM_id);  if(E){ERR(E);}		vecN_DIMS_val[k-1] = k;		vecN_DIMS_id[k-1] = dummy_DIM_id;
						k = 4;	E = nc_def_dim( nc_FILE_id, "vec4", k, &dummy_DIM_id);  if(E){ERR(E);}		vecN_DIMS_val[k-1] = k;		vecN_DIMS_id[k-1] = dummy_DIM_id;
						k = 5;	E = nc_def_dim( nc_FILE_id, "vec5", k, &dummy_DIM_id);  if(E){ERR(E);}		vecN_DIMS_val[k-1] = k;		vecN_DIMS_id[k-1] = dummy_DIM_id;
						k = 6;	E = nc_def_dim( nc_FILE_id, "vec6", k, &dummy_DIM_id);  if(E){ERR(E);}		vecN_DIMS_val[k-1] = k;		vecN_DIMS_id[k-1] = dummy_DIM_id;
						k = 7;	E = nc_def_dim( nc_FILE_id, "vec7", k, &dummy_DIM_id);  if(E){ERR(E);}		vecN_DIMS_val[k-1] = k;		vecN_DIMS_id[k-1] = dummy_DIM_id;
						k = 8;	E = nc_def_dim( nc_FILE_id, "vec8", k, &dummy_DIM_id);  if(E){ERR(E);}		vecN_DIMS_val[k-1] = k;		vecN_DIMS_id[k-1] = dummy_DIM_id;
						k = 9;	E = nc_def_dim( nc_FILE_id, "vec9", k, &dummy_DIM_id);  if(E){ERR(E);}		vecN_DIMS_val[k-1] = k;		vecN_DIMS_id[k-1] = dummy_DIM_id;

						for(zL=0;zL<zL_END;zL++){ // for singlevar files: run once; for a multivar file: run N_Labels times

							if( HAVE_OPTION_NetCDF_multivar_file ){
								this_iL = zL; // zL=0..N_Labels-1;
							}else{
								this_iL = iL; // iL index from loop over SINGLEVAR output files
							}


							if( HAVE_OPTION_NetCDF_1D_float ||
								HAVE_OPTION_NetCDF_1D_double ){
								// if 1D NetCDF variables are desired we need no further dimensions
								// as time will be the only required one.

							}else{	// -------------------
									// 2D NetCDF variables
								    // -------------------

								// ..here we set the 2nd dimension counting over the data columns

									NCols = Labels_NCols[this_iL];

									str_free( &NCols_str );   str_Nini( &NCols_str, 50 );
									sprintf( NCols_str, "%ld", NCols );

									str_free( &entity_DIM_name );
									entity_DIM_name = str_cat( "vec", NCols_str );


									if( NCols > 9 ){ // here we define  vecN  dimensions with  N>=10  as dimensions
													 // vec1..vec9 have already been defined above in the stockpile
										if( HAVE_OPTION_NetCDF_multivar_file ){

											//check: Do have to define a NEW vecN DIMENSION ?
											DEFINE_NEW_DIM = 1;	for(k=0;k<L_vecN;k++){  if( vecN_DIMS_val[k] == NCols ){ DEFINE_NEW_DIM = 0; break;}  }

											if( DEFINE_NEW_DIM ){

												// define new a dimension
												E = nc_def_dim( nc_FILE_id, entity_DIM_name, NCols, &entity_DIM_id );  if(E){ERR(E);}


												L_vecN++;
												if(vecN_DIMS_val == NULL){vecN_DIMS_val = (long*) malloc(sizeof(long) * L_vecN);}
																 else{vecN_DIMS_val = (long*) realloc(vecN_DIMS_val, sizeof(long) * L_vecN);}
												if(vecN_DIMS_id == NULL){vecN_DIMS_id = (long*) malloc(sizeof(long) * L_vecN);}
																 else{vecN_DIMS_id = (long*) realloc(vecN_DIMS_id, sizeof(long) * L_vecN);}
												k = L_vecN-1;
												vecN_DIMS_val[k] = NCols;
												vecN_DIMS_id[k]  = entity_DIM_id;

											} // if( DEFINE_NEW_DIM )

										}else{ // (multiple) SINGLEVAR files

											E = nc_def_dim( nc_FILE_id, entity_DIM_name, NCols, &entity_DIM_id );  if(E){ERR(E);}
										}

									} // if( NCols > 9 )

							} // if( HAVE_OPTION_NetCDF_1D_* )..else..


							Labels_entity_DIM_id[this_iL] = -1; // initialize to invalid index

							// save for each label/entity its DIM-id :
							if( HAVE_OPTION_NetCDF_multivar_file ){
								// --> i.e. for a MULTIVAR file,
								// we have to find the DIM-id that is related
								// to the number current number of data columns.
								for(k=0;k<L_vecN;k++){
									if( vecN_DIMS_val[k] == NCols ){

										Labels_entity_DIM_id[this_iL] = vecN_DIMS_id[k];
										break;
									}
								}
							}else{ // (multiple) SINGLEVAR files

								if( HAVE_OPTION_NetCDF_1D_float ||
									HAVE_OPTION_NetCDF_1D_double ){

									// with 1D vars the only dimension is time !!!
									Labels_entity_DIM_id[this_iL] = -1; // set to invalid index

								}else{
									// -------------------
									// 2D NetCDF variables
									// -------------------

									// we have to find the DIM-id that is related
									// to the number current number of data columns.
									for(k=0;k<L_vecN;k++){
										if( vecN_DIMS_val[k] == NCols ){

											Labels_entity_DIM_id[this_iL] = vecN_DIMS_id[k];
											break;
										}
									}
								}
							}

						} // for(zL=0;zL<zL_END;zL++)




						/* =========================================
						 * DEFINE  G L O B A L   A T T R I B U T E S
						 * ========================================= */
						// global attributes:
						/*  :id = "01.01.2010 12:00:00" ;
							:category = "time series data" ;
							:title = "MBDyn simulation results" ;
							:project = "-" ;
							:institution = "-" ;
							:creator_name = "-" ;
							:summary = "-" ;
							:comment = "-" ;
							:model_title = "-" ;
							:model_description = "-" ;
							:simulation_title = "-" ;
							:simulation_description = "-" ;
							:license = "-" ;
							:history = "-" ; */
					//E = nc_put_att_text(nc_FILE_id, NC_GLOBAL, ATT_NAME, strLEN, str);
						E = nc_put_att_text(nc_FILE_id, NC_GLOBAL, "id", strlen(input_file_timeID_str), input_file_timeID_str);  if(E){ERR(E);}
						E = nc_put_att_text(nc_FILE_id, NC_GLOBAL, "category", strlen("time series data"), "time series data");  if(E){ERR(E);}
						E = nc_put_att_text(nc_FILE_id, NC_GLOBAL, "title", strlen("MBDyn simulation results"), "MBDyn simulation results");  if(E){ERR(E);}
						E = nc_put_att_text(nc_FILE_id, NC_GLOBAL, "project", strlen("-"), "-");  if(E){ERR(E);}
						E = nc_put_att_text(nc_FILE_id, NC_GLOBAL, "institution", strlen("-"), "-");  if(E){ERR(E);}
						E = nc_put_att_text(nc_FILE_id, NC_GLOBAL, "creator_name", strlen("-"), "-");  if(E){ERR(E);}
						E = nc_put_att_text(nc_FILE_id, NC_GLOBAL, "summary", strlen("-"), "-");  if(E){ERR(E);}
						E = nc_put_att_text(nc_FILE_id, NC_GLOBAL, "comment", strlen("-"), "-");  if(E){ERR(E);}
						E = nc_put_att_text(nc_FILE_id, NC_GLOBAL, "model_title", strlen("-"), "-");  if(E){ERR(E);}
						E = nc_put_att_text(nc_FILE_id, NC_GLOBAL, "model_description", strlen("-"), "-");  if(E){ERR(E);}
						E = nc_put_att_text(nc_FILE_id, NC_GLOBAL, "simulation_title", strlen("-"), "-");  if(E){ERR(E);}
						E = nc_put_att_text(nc_FILE_id, NC_GLOBAL, "simulation_description", strlen("-"), "-");  if(E){ERR(E);}
						E = nc_put_att_text(nc_FILE_id, NC_GLOBAL, "license", strlen("-"), "-");  if(E){ERR(E);}
						E = nc_put_att_text(nc_FILE_id, NC_GLOBAL, "history", strlen("-"), "-");  if(E){ERR(E);}


						/* =========================
						 * DEFINE  V A R I A B L E S
						 * ========================= */

						if( HAVE_OPTION_AddTime ){
							// ..we can only define a �time� variable if there was option
							//   �--add-time� specified and the simulation time data were
							//   successfully read from MBDyn's *.out file.

							// time variable is a 1D array
							E = nc_def_var(nc_FILE_id, time_VAR_name, NC_FLOAT, 1, &time_DIM_id,
											&time_VAR_id);  if(E){ERR(E);}
								// assign unit, type & description attributes
								E = nc_put_att_text(nc_FILE_id, time_VAR_id, UNITS_attname,
												strlen(time_UNITS_str), time_UNITS_str);  if(E){ERR(E);}
								E = nc_put_att_text(nc_FILE_id, time_VAR_id, TYPE_attname,
												strlen(time_TYPE_str), time_TYPE_str);  if(E){ERR(E);}
								E = nc_put_att_text(nc_FILE_id, time_VAR_id, DESCRIPTION_attname,
												strlen(time_DESCRIPTION_str), time_DESCRIPTION_str);  if(E){ERR(E);}

							// integration time step variable is a 1D array
							E = nc_def_var(nc_FILE_id, dTsim_VAR_name, NC_FLOAT, 1, &time_DIM_id,
											&dTsim_VAR_id);  if(E){ERR(E);}
								// assign unit, type & description attributes
								E = nc_put_att_text(nc_FILE_id, dTsim_VAR_id, UNITS_attname,
												strlen(dTsim_UNITS_str), dTsim_UNITS_str);  if(E){ERR(E);}
								E = nc_put_att_text(nc_FILE_id, dTsim_VAR_id, TYPE_attname,
												strlen(dTsim_TYPE_str), dTsim_TYPE_str);  if(E){ERR(E);}
								E = nc_put_att_text(nc_FILE_id, dTsim_VAR_id, DESCRIPTION_attname,
												strlen(dTsim_DESCRIPTION_str), dTsim_DESCRIPTION_str);  if(E){ERR(E);}

								// integration time step variable is a 1D array
								E = nc_def_var(nc_FILE_id, iTsim_VAR_name, NC_INT, 1, &time_DIM_id,
												&iTsim_VAR_id);  if(E){ERR(E);}
									// assign unit, type & description attributes
									E = nc_put_att_text(nc_FILE_id, iTsim_VAR_id, UNITS_attname,
													strlen(iTsim_UNITS_str), iTsim_UNITS_str);  if(E){ERR(E);}
									E = nc_put_att_text(nc_FILE_id, iTsim_VAR_id, TYPE_attname,
													strlen(iTsim_TYPE_str), iTsim_TYPE_str);  if(E){ERR(E);}
									E = nc_put_att_text(nc_FILE_id, iTsim_VAR_id, DESCRIPTION_attname,
													strlen(iTsim_DESCRIPTION_str), iTsim_DESCRIPTION_str);  if(E){ERR(E);}

						} // if( HAVE_OPTION_AddTime )


						for(zL=0;zL<zL_END;zL++){ // for singlevar files: run once; for a multivar file: run N_Labels times

							if( HAVE_OPTION_NetCDF_multivar_file ){
								this_iL = zL; // zL=0..N_Labels-1;
							}else{
								this_iL = iL; // iL index from loop over SINGLEVAR output files
							}

							str_free( &label_str );   str_Nini( &label_str, 50 );
							sprintf(label_str, "%ld", Labels[this_iL]);

							if( HAVE_OPTION_NetCDF_1D_float ||
								HAVE_OPTION_NetCDF_1D_double ){

								// =======================
								//   1D NetCDF variables
								// =======================

								// if 1D NetCDF variables are desired we need a variable
								// for each data column

								NCols = Labels_NCols[this_iL];

								if(Labels_entity_VAR_id[this_iL] == NULL){Labels_entity_VAR_id[this_iL] = (int*) malloc(sizeof(int) * NCols);}
																	 else{Labels_entity_VAR_id[this_iL] = (int*) realloc(Labels_entity_VAR_id[this_iL], sizeof(int) * NCols);}
								if(Labels_entity_VAR_id[this_iL] == NULL){ printf("\n\n     !!! ERROR : could not allocate memory for entity variable IDs:\n\n\n");
									   return EXIT_FAILURE;
								}

								for(k=0;k<NCols;k++){

										str_free( &iCol_str );   str_Nini( &iCol_str, 50 );
										sprintf( iCol_str, "%ld", k+1 );

										str_free( &entity_VAR_name );
										entity_VAR_name = str_cat10( "entity", input_file_extension, ".", label_str , "_" , iCol_str , " " , " " , " " , " " );
										str_trim( &entity_VAR_name );

										NDIMS = 1;

										if( HAVE_OPTION_NetCDF_1D_float ){

											// define a 1D NetCDF variable of type FLOAT for each column of the entity data.
											E = nc_def_var(nc_FILE_id, entity_VAR_name, NC_FLOAT, NDIMS,
														&time_DIM_id, &entity_VAR_id);  if(E){ERR(E);}

										}else{ // HAVE_OPTION_NetCDF_1D_double
											// define a 1D NetCDF variable of type DOUBLE for each column of the entity data.

											E = nc_def_var(nc_FILE_id, entity_VAR_name, NC_DOUBLE, NDIMS,
														&time_DIM_id, &entity_VAR_id);  if(E){ERR(E);}

										} // if( HAVE_OPTION_NetCDF_1D_float )..else..

										// while the content of the  F I R S T  B U F F E R  filling is being processed
										// we save the NetCDF variable ID of each entity (i.e. label) for later use when
										// appending the data of subsequent buffer fills.
										Labels_entity_VAR_id[this_iL][k] = entity_VAR_id;

										// Assign units, type & description attributes to the NetCDF variables.
										E = nc_put_att_text(nc_FILE_id, entity_VAR_id, UNITS_attname,
														strlen(entity_UNITS_str), entity_UNITS_str);  if(E){ERR(E);}
										E = nc_put_att_text(nc_FILE_id, entity_VAR_id, TYPE_attname,
														strlen(entity_TYPE_str), entity_TYPE_str);  if(E){ERR(E);}
										E = nc_put_att_text(nc_FILE_id, entity_VAR_id, DESCRIPTION_attname,
														strlen(entity_DESCRIPTION_str), entity_DESCRIPTION_str);  if(E){ERR(E);}

								} // for(k=1;k<=NCols;k++)

							}else{
									// =======================
									//   2D NetCDF variables
									// =======================

								if(Labels_entity_VAR_id[this_iL] == NULL){Labels_entity_VAR_id[this_iL] = (int*) malloc(sizeof(int) * 1);}
																     else{Labels_entity_VAR_id[this_iL] = (int*) realloc(Labels_entity_VAR_id[this_iL], sizeof(int) * 1);}
								if(Labels_entity_VAR_id[this_iL] == NULL){ printf("\n\n     !!! ERROR : could not allocate memory for entity variable IDs:\n\n\n");
									   return EXIT_FAILURE;
								}

								/* The DIM_ids array is used to pass the dimids of the dimensions of
								 * a netCDF variable.
								 * In C, the unlimited dimension (i.e. time) must come first on the list of dimids. */

									entity_DIM_id = Labels_entity_DIM_id[this_iL];

									NDIMS = 2;
									DIM2_ids[0] = time_DIM_id;
									DIM2_ids[1] = entity_DIM_id;


								str_free( &entity_VAR_name );
								entity_VAR_name = str_cat4( "entity", input_file_extension, ".", label_str );

								if( HAVE_OPTION_NetCDF_2D_float ){

									// define a 2D NetCDF variable of type FLOAT for the entity data.
									E = nc_def_var(nc_FILE_id, entity_VAR_name, NC_FLOAT, NDIMS,
												DIM2_ids, &entity_VAR_id);  if(E){ERR(E);}

								}else{ // HAVE_OPTION_NetCDF_2D_double

									// define a 2D NetCDF variable of type DOUBLE for the entity data.
									E = nc_def_var(nc_FILE_id, entity_VAR_name, NC_DOUBLE, NDIMS,
												DIM2_ids, &entity_VAR_id);  if(E){ERR(E);}

								} // if( HAVE_OPTION_NetCDF_2D_float )..else..


								// while the content of the  F I R S T  B U F F E R  filling is being processed
								// we save the NetCDF variable ID of the 2D entity (i.e. label) for later use when
								// appending the data of subsequent buffer fills.
								Labels_entity_VAR_id[this_iL][0] = entity_VAR_id;

								// Assign units, type & description attributes to the netCDF variables.
								E = nc_put_att_text(nc_FILE_id, entity_VAR_id, UNITS_attname,
												strlen(entity_UNITS_str), entity_UNITS_str);  if(E){ERR(E);}
								E = nc_put_att_text(nc_FILE_id, entity_VAR_id, TYPE_attname,
												strlen(entity_TYPE_str), entity_TYPE_str);  if(E){ERR(E);}
								E = nc_put_att_text(nc_FILE_id, entity_VAR_id, DESCRIPTION_attname,
												strlen(entity_DESCRIPTION_str), entity_DESCRIPTION_str);  if(E){ERR(E);}

							} // if( HAVE_OPTION_NetCDF_1D_* )..else..

						} // for(zL=0;zL<zL_END;zL++)


						/* END DEFINE MODE
						 * =============== */
						E = nc_enddef(nc_FILE_id);  if(E){ERR(E);}

						// ..now we have entered  DATA MODE  ,i.e. we can WRITE VARIABLE DATA


						if( HAVE_OPTION_AddTime ){
							// ..we can only write data of variable �time� if there was option
							//   �--add-time� specified and the simulation time data were
							//   successfully read from MBDyn's *.out file.

							D1start[0] = 0;
							D1count[0] = NT_time;

							/*----------------------------------------
							 * WRITE complete(!)   T I M E   D A T A  all at once to output file when FIRST_BUFF is true
							 *----------------------------------------*/

							E = nc_put_vara_float(nc_FILE_id, time_VAR_id, D1start, D1count,
											  &Tsim_X[0]);  if(E){ERR(E);}

							E = nc_put_vara_float(nc_FILE_id, dTsim_VAR_id, D1start, D1count,
											  &dTsim_X[0]);  if(E){ERR(E);}

							E = nc_put_vara_int(nc_FILE_id, iTsim_VAR_id, D1start, D1count,
											  &iTsim_I[0]);  if(E){ERR(E);}

						} // if( HAVE_OPTION_AddTime )

					} // if(EXECUTE_FOR_THIS_LABEL)
					  // END  MULTIVAR / SINGLEVAR STRATEGY


				}else{	// =====================================
						//   case: NOT FIRST_BUFF --> buff > 1
						// =====================================

					if( HAVE_OPTION_NetCDF_multivar_file ){
						// do nothing as the file should be already open and
						// remain opened during the whole process over all labels

					}else{	// with SINGLEVAR FILES we close & re-open each file
							// for every buffer filling in order not to have too
							// many files at the same time (only one entity ouput
							// file should be open at a time)

						// To   A P P E N D   ENTITY DATA to existing NetCDF variables we
						// RE-OPEN each NetCDF output file with NC_WRITE to get READ/WRITE ACCESS. */
						E = nc_open( output_filename, NC_WRITE, &nc_FILE_id);	if(E){ERR(E);}

						// ..having opened the file with flag  NC_WRITE
						//   we are directly in  DATA MODE  ,i.e. we can write variable data
						//   ------------------=============-------------------------------

						/* we could use  nc_redef()  to switch into DEFINE MODE, but it's not needed now */

						/* use  nc_inq()  to find out what is in it */
						E = nc_inq ( nc_FILE_id, &Ndims, &Nvars, &Ngatts, &time_VAR_id);

						/* we could use  nc_inq_dim() to get dimension names, lengths, */

						/* we could use  nc_inq_var() to get variable names, types, shapes, but..
						 * ..in array  Labels_entity_VAR_id[][]  we already saved all variable IDs
						 *             ====================
						 */

						/* if we used  nc_redef() to switch into DEFINE MODE
						 * we could use  nc_enddef()  to switch into DATA MODE
						 */

					} // if( HAVE_OPTION_netcdf_mulitvar_file )..else..end

				} // if( FIRST_BUFF )..else..end


				if( HAVE_OPTION_NetCDF_1D_float ||
					HAVE_OPTION_NetCDF_1D_double ){

					// =======================
					//   1D NetCDF variables :  WRITE DATA
					// =======================

					NToff  = Labels_NToff[iL];
					NTbuff = Labels_NTbuff[iL];
					NCols  = Labels_NCols[iL];


					float  X1_out[NTbuff];
					double XX1_out[NTbuff];


					for(k=0;k<NCols;k++){ // LOOP OVER a label's DATA COLUMNS

						D1start[0] = NToff;

						D1count[0] = NTbuff;

						for(j=0;j<NTbuff;j++){
							if( HAVE_OPTION_NetCDF_1D_float ){

								X1_out[j] = Labels_DATA_X[iL][j][k];

							}else{ // HAVE_OPTION_NetCDF_1D_double

								XX1_out[j] = Labels_DATA_XX[iL][j][k];
							}
						}

						entity_VAR_id = Labels_entity_VAR_id[iL][k];

						if( HAVE_OPTION_NetCDF_1D_float ){

							/* WRITE buffered   E N T I T Y   D A T A   in (multiple) 1D NetCDF variable of type FLOAT to output file*/
							E = nc_put_vara_float(nc_FILE_id, entity_VAR_id, D1start, D1count,
											  &X1_out[0]);  if(E){ERR(E);}

						}else{ // HAVE_OPTION_NetCDF_1D_double

							/* WRITE buffered   E N T I T Y   D A T A   in (multiple) 1D NetCDF variable of type DOUBLE to output file*/
							E = nc_put_vara_double(nc_FILE_id, entity_VAR_id, D1start, D1count,
											  &XX1_out[0]);  if(E){ERR(E);}
						}

					} // for(k=0;k<NCols;k++)

				}else{
					// =======================
					//   2D NetCDF variables :  WRITE DATA
					// =======================

					NToff  = Labels_NToff[iL];
					NTbuff = Labels_NTbuff[iL];
					NCols  = Labels_NCols[iL];

					D2start[0] = NToff;
					D2start[1] = 0;

					D2count[0] = NTbuff;
					D2count[1] = NCols;

					/* ..unfortunately the line below did not work..
					 * E = nc_put_vara_float(nc_FILE_id, entity_VAR_id, D2start, D2count,
					 *				  &Labels_DATA_X[iL][0][0]);  if(E){ERR(E);}
					 * ..so I had to use a local help array X_out as work-around :-(   */


					float  X2_out[NTbuff][NCols];
					double XX2_out[NTbuff][NCols];


					for(j=0;j<NTbuff;j++){
						for(k=0;k<NCols;k++){
							if( HAVE_OPTION_NetCDF_2D_float ){

								X2_out[j][k] = Labels_DATA_X[iL][j][k];

							}else{ // HAVE_OPTION_NetCDF_2D_double

								XX2_out[j][k] = Labels_DATA_XX[iL][j][k];
							}
						}
					}

					entity_VAR_id = Labels_entity_VAR_id[iL][0];

					if( HAVE_OPTION_NetCDF_2D_float ){

						/* WRITE buffered ENTITY DATA in one 2D NetCDF variable of type FLOAT to output file*/
						E = nc_put_vara_float(nc_FILE_id, entity_VAR_id, D2start, D2count,
										  &X2_out[0][0]);  if(E){ERR(E);}

					}else{ // HAVE_OPTION_NetCDF_2D_double

						/* WRITE buffered ENTITY DATA in one 2D NetCDF variable of type DOUBLE to output file*/
						E = nc_put_vara_double(nc_FILE_id, entity_VAR_id, D2start, D2count,
										  &XX2_out[0][0]);  if(E){ERR(E);}
					}

				} // if( HAVE_OPTION_NetCDF_1D_* )..else..


				if( HAVE_OPTION_NetCDF_multivar_file ){
					//if( iL == N_Labels-1 ){

						/* CLOSE NetCDF output file   L A T E R   !!!
						 * when the complete input file has been
						 * processed. */
						// E = nc_close(nc_FILE_id);  if(E){ERR(E);}
					//}
				}else{	// with SINGLEVAR FILES we close & re-open each file
						// for every buffer filling in order not to have too
						// many files at the same time (only one entity ouput
						// file should be open at a time)

					/* CLOSE NetCDF output file. */
					E = nc_close(nc_FILE_id);  if(E){ERR(E);}
				}

			}else{
				/* ========================================
				 *    A S C I I   T E X T    O U T P U T
				 * ======================================== */


				if( FIRST_BUFF ){
					out_FILE = fopen( output_filename , "w+t" ); // open text file for OVER(!)writing
				}else{
					out_FILE = fopen( output_filename , "a+t" ); // open text file for APPEND(!)writing
				}

				NTbuff = Labels_NTbuff[iL]; // number of buffered time steps per label

				if( (out_FILE != NULL)&&(!ferror(out_FILE)) ){

					for(jT=0;jT<NTbuff;jT++){

						// ==========================
						//    WRITE TO OUTPUT FILE
						// ==========================
						// write the buffered data (i.e. strings) of each label into a separate output file
						if( HAVE_OPTION_AddTime ){

							str_free( &out_data_str );
							out_data_str = str_cpy( Labels_DATA_STR[iL][jT] );

							iT_time = Labels_NToff[iL] + jT;
							if( iT_time < NT_time ){
								str_free( &time_str ); str_Nini( &time_str , 20 );
								sprintf( time_str , "%14.6f  ", Tsim_X[iT_time] );
								//time_str = Efmt( Tsim_[iT_time], 12, 2);
							}
							// prepend the simulation time
							//out_data_str = str_cat3( time_str, " ", out_data_str );
							fprintf( out_FILE , "%s%s\n" , time_str , out_data_str );

						}else{

							//fprintf( out_FILE , "%s\n" , out_data_str );
							fprintf( out_FILE , "%s\n" , Labels_DATA_STR[iL][jT] );
						}

					} // for(jT=0;jT<NT;jT++)

					fclose(out_FILE);

				}else{ // out_FILE == NULL !!!

					printf("\n\n");
					printf("   ..Ooops !?! ..seems something went wrong when processing last line !\n\n");
					printf("           -->   line     = %ld\n\n", line_O);
					printf("           -->   line_str = \"%s\"\n\n", line_str);
					printf("\n\n");
					printf("     !!! ERROR : could not create output file :\n");
					printf("\n");
					printf("           -->   \"%s\"\n", output_filename);
					printf("\n\n");

					return EXIT_FAILURE;
				} // if( (out_FILE != NULL)&&(!ferror(out_FILE)) )

			} // if( HAVE_OPTION_NetCDF )..else..

		} // for(iL=0;iL<N_Labels;iL++)..
		  // END LOOP OVER OUTPUT FILES


time(&time2_WRITING);
time12_WRITING = difftime(time2_WRITING , time1_WRITING);

printf("                ..writing done in %2ld sec\n", time12_WRITING);


		FIRST_BUFF = 0;

		for(i=0;i<NL_buff;i++){ // reset the input buffer and the number of buffered time steps per label
			if( Bulk_DATA[i] != NULL ){
				free( Bulk_DATA[i] );   Bulk_DATA[i] = NULL;
			}
		}

		for(iL=0;iL<N_Labels;iL++){ // reset the output buffer and the number of buffered time steps per label

			NTbuff = Labels_NTbuff[iL];
			for(jT=0;jT<NTbuff;jT++){ // free / initialize memory

				if( HAVE_OPTION_NetCDF ){

					NCols = Labels_NCols[iL];
					for(k=0;k<NCols;k++){
						if( HAVE_OPTION_NetCDF_1D_float ||
							HAVE_OPTION_NetCDF_2D_float	){

								Labels_DATA_X[iL][jT][k] = FLT_MAX; // initialize with unphysical value
						}else{
								Labels_DATA_XX[iL][jT][k] = DBL_MAX; // initialize with unphysical value
						}
					} // for(k=0;k<NCols;k++)
				}else{
					if( Labels_DATA_STR[iL][jT] != NULL ){
						free( Labels_DATA_STR[iL][jT] );    Labels_DATA_STR[iL][jT] = NULL;
					}
				}
			} // for(jT=0;jT<NTbuff;jT++)

			Labels_NToff[iL] = Labels_NToff[iL] + NTbuff;

			Labels_NTbuff[iL] = 0; // re-initialize number of buffered time steps per each label to zero
		}

	} // while( (RL == NL_buff)&&(!feof(in_FILE)) )
	  // END LOOP OVER BUFFER FILLINGS


	if( HAVE_OPTION_NetCDF ){
		if( HAVE_OPTION_NetCDF_multivar_file ){

			E = nc_close(nc_FILE_id);  if(E){ERR(E);}
		}
	}


/*
	printf("\n  final file position was  Fpos  = %lld\n", Fpos);
	printf("\n  while file size     was  Fsize = %lld\n\n", Fsize);

	printf("..enter press return to quit..  ");   scanf("%c",&c);
*/
	printf("\n  %10ld  LABEL DATA FILES written with \n", N_Labels);

	NTfile = line_O / N_Labels;
	printf("\n  %10ld  TIME STEPS per file \n\n", NTfile);

    sys_DateTimeToStr( &STOP_time_str,  sys_Now() );

time(&time2_TOTAL);
time12_TOTAL = difftime(time2_TOTAL , time1_TOTAL);
hours = floor( time12_TOTAL / 3600. );
minutes = floor( (time12_TOTAL - hours * 3600) / 60.);
seconds = time12_TOTAL - hours * 3600 - minutes * 60.;


	printf(  "    START time was :  %s \n", START_time_str);
	printf(  "    STOP  time was :  %s \n", STOP_time_str);
	printf(  "    TOTAL time elapsed :  %02ld:%02ld:%02ld \n", hours, minutes, seconds);

	printf("\n..program SUCCESSFULLY terminated :) \n\n");

	return EXIT_SUCCESS;

} // end main
