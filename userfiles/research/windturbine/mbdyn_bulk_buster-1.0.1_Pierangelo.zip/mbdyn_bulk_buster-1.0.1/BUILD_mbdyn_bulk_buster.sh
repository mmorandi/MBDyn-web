#!bash
#
#  ==============================================================
#    SHELL-SCRIPT  <<<  BUILD_mbdyn_bulk_buster . s h  >>>
#  ==============================================================
#  Author:  Patrick Rix
#
#  Script for building C-program   "mbdyn_bulk_buster.exe"  from within a simple
#  shell environment (i.e. without the Eclipse-IDE) on  Linux  AND/OR  Windows+Cygwin.
#


echo;
echo;
echo "    BUILD_mbdyn_bulk_buster.sh";
echo "    ==========================";
echo;
echo "..it is assumed that the current working directory is �/mbdyn_bulk_buster�";
echo "  which is the directory where this script should reside in.";
echo "  Further a compiled C-version of the NetCDF library (incl. header file)";
echo "  is expected to be found in   �/mbdyn_bulk_buster/src/netcdf�  ";
echo "  i.e.:  libnetcdf.a  &  netcdf.h";
echo;


# compile sources
# ---------------
echo;
echo "..compiling sources :";
echo;
echo "  -->  ./src/mbdyn_bulk_buster.c";
gcc -O0 -g3 -Wall -c  -o "./Debug/src/mbdyn_bulk_buster.o"      "./src/mbdyn_bulk_buster.c"
echo;
echo "  -->  ./src/lib.C_utils/sys_utils.c";
gcc -O0 -g3 -Wall -c  -o "./Debug/src/lib.C_utils/sys_utils.o"  "./src/lib.C_utils/sys_utils.c"  -Wno-char-subscripts
echo;
echo "  -->  ./src/lib.C_utils/str_utils.c";
gcc -O0 -g3 -Wall -c  -o "./Debug/src/lib.C_utils/str_utils.o"  "./src/lib.C_utils/str_utils.c"  -Wno-char-subscripts
echo;
echo "  -->  ./src/lib.C_utils/strlist.c";
gcc -O0 -g3 -Wall -c  -o "./Debug/src/lib.C_utils/strlist.o"    "./src/lib.C_utils/strlist.c"    -Wno-char-subscripts
echo;


# create binary: link object files & libs 
# ---------------------------------------
echo;
echo "..linking object files & libs";
echo;

gcc  -L "./src/netcdf" \
     "./Debug/src/mbdyn_bulk_buster.o" \
     "./Debug/src/lib.C_utils/sys_utils.o" \
     "./Debug/src/lib.C_utils/str_utils.o" \
     "./Debug/src/lib.C_utils/strlist.o" \
     -lnetcdf \
     -o "./Debug/mbdyn_bulk_buster.exe"

if [ -e "./Debug/mbdyn_bulk_buster.exe" ];
  then    
      echo;
      echo "  BINARY/EXECUTABLE at   ==>   ./Debug/mbdyn_bulk_buster.exe  ";
      echo;
      echo;
      echo "..COMPILATION   S U C E S S F U L   :-)";
      echo;
  else
      echo;
      echo;
      echo "..COMPILATION   F A I L E D   :-(";
      echo;
fi  
     