#!bash
#
#  ==============================================================
#    SHELL-SCRIPT  <<<  TEST_mbdyn_bulk_buster . s h  >>>
#  ==============================================================
#  Author:  Patrick Rix
#
#  Script for building C-program   "mbdyn_bulk_buster.exe"  from within a simple
#  shell environment (i.e. without the Eclipse-IDE) on  Linux  AND/OR  Windows+Cygwin.
#


echo;
echo;
echo "    TEST_mbdyn_bulk_buster.sh";
echo "    ==========================";
echo;
echo "..it is assumed that the current working directory is �/mbdyn_bulk_buster�";
echo "  which is the directory where this script should reside in.";
echo "  Further the binary is expected to be either in this directory or in";
echo "  �/mbdyn_bulk_buster/Debug� while the test data should reside in";
echo "  �/mbdyn_bulk_buster/test�. ";
echo;

MBDYN_BULK_BUSTER="";

TEST4_LOC_1_="./";   # current directory should be mbdyn_bulk_buster
TEST4_LOC_2_="./Debug/";

TEST4_EXE_0="mbdyn_bulk_buster";
TEST4_EXE_1="mbdyn_bulk_buster.exe";
TEST4_EXE_2="mbdyn_bulk_buster-1.0.1.exe";

if [ -e $TEST4_LOC_1_$TEST4_EXE_2 ]; then MBDYN_BULK_BUSTER=$TEST4_LOC_1_$TEST4_EXE_2; fi
if [ -e $TEST4_LOC_1_$TEST4_EXE_1 ]; then MBDYN_BULK_BUSTER=$TEST4_LOC_1_$TEST4_EXE_1; fi

if [ -e $TEST4_LOC_2_$TEST4_EXE_2 ]; then MBDYN_BULK_BUSTER=$TEST4_LOC_2_$TEST4_EXE_2; fi
if [ -e $TEST4_LOC_2_$TEST4_EXE_1 ]; then MBDYN_BULK_BUSTER=$TEST4_LOC_2_$TEST4_EXE_1; fi
if [ -e $TEST4_LOC_2_$TEST4_EXE_0 ]; then MBDYN_BULK_BUSTER=$TEST4_LOC_2_$TEST4_EXE_0; fi

if [ "$MBDYN_BULK_BUSTER" = "" ];then
    echo;
    echo;
    echo " !!! ERROR: no binary/executable found ?!";
    echo;
    echo;

    exit 1;
fi

echo;
echo "  =============";
echo "..showing HELP :";
echo "  =============";
echo;
      $MBDYN_BULK_BUSTER;
echo;
echo;
echo "  ========================";
echo "..splitting to ASCII text :";
echo "  ========================";
echo;
      $MBDYN_BULK_BUSTER  --skip-label  --add-time  "./test/test_data.mov"  "./test/data.asc/test_data.mov";
echo;
echo;
echo "  =============================";
echo "..splitting to NetCDF 1D float :";
echo "  =============================";
echo;
      $MBDYN_BULK_BUSTER  --netcdf-1D-float  --skip-label  --add-time  "./test/test_data.mov"  "./test/data.nc1/test_data.mov";
echo;
echo;
echo "  =============================";
echo "..splitting to NetCDF 2D float :";
echo "  =============================";
echo;
      $MBDYN_BULK_BUSTER  --netcdf-2D-float  --skip-label  --add-time  "./test/test_data.mov"  "./test/data.nc2/test_data.mov";
echo;
echo;
echo "  =============================";
echo "..transforming to NetCDF 1D float (MULTIVAR file):";
echo "  =============================";
echo;
      $MBDYN_BULK_BUSTER  --netcdf-multivar-file  --netcdf-1D-float  --skip-label  --add-time  "./test/test_data.mov"  "./test/data.multivar.nc/test_data.mov.1D-multi.";
echo;
echo;
echo "  =============================";
echo "..transforming to NetCDF 1D float (MULTIVAR file):";
echo "  =============================";
echo;
      $MBDYN_BULK_BUSTER  --netcdf-multivar-file  --netcdf-2D-float  --skip-label  --add-time  "./test/test_data.mov"  "./test/data.multivar.nc/test_data.mov.2D-multi.";
echo;
echo;
echo;

     